import SwiftUI

@MainActor
final class MessageReader: ObservableObject {
  @Published var metadata: MessageMetadata?
  @Published var text = ""
  @Published var page = 0
  @Published var pageCount = 0
  @Published var loading = false
  @Published var transfer: String?
  @Published var received: Int64 = 0
  @Published var cached = false
  @Published var receivingPreview = false
  @Published var htmlDocument: HTMLDocument?
  @Published var htmlNotice: String?
  @Published var error: String?
  @Published var invalidated = false
  @Published var mutating = false
  @Published var exportURL: URL?
  @Published var destinations: [MailFolder] = []
  private var pager: BodyPager?
  private var directories: [URL] = []
  private var task: Task<Void, Never>?
  private var generation = UUID()
  @Published private(set) var canMutate = true
  let identity: MessageIdentity
  init(identity: MessageIdentity) { self.identity = identity }

  func open(using store: MailStore) async {
    store.cancelPrefetch()
    stop(clear: true)
    guard let session = store.session else { return }
    let ticket = generation
    loading = true
    error = nil
    invalidated = false
    canMutate = false
    defer { if generation == ticket { loading = false } }
    if let snapshot = try? await store.cache.snapshot(identity, session: session) {
      guard ticket == generation, store.session?.token == session.token else {
        try? FileManager.default.removeItem(at: snapshot.directory)
        return
      }
      directories.append(snapshot.directory)
      metadata = snapshot.metadata
      if let flags = store.index.flags(identity) { metadata?.flags = flags }
      await prepareBody(at: snapshot.body)
      guard ticket == generation, store.session?.token == session.token else { return }
      cached = true
    }
    do {
      let meta = try await store.api.request(
        MessageMetadata.self, server: session.server,
        path: identity.path, token: session.token, query: identity.query)
      try Task.checkCancellation()
      guard ticket == generation, store.session?.token == session.token else { return }
      guard meta.uid == identity.uid, meta.uidValidity == identity.uidValidity else {
        throw ClientError.changed
      }
      if let previousType = metadata?.body?.contentType, previousType != meta.body?.contentType {
        pager = nil
        htmlDocument = nil
        htmlNotice = nil
        text = ""
        pageCount = 0
        cached = false
        await store.cache.remove(identity, session: session)
        guard ticket == generation, store.session?.token == session.token else { return }
      }
      metadata = meta
      canMutate = true
      if meta.body != nil && pager == nil { download(attachment: nil, using: store) }
    } catch {
      guard ticket == generation, store.session?.token == session.token else { return }
      handle(error, using: store)
      if cached && !invalidated { self.error = "暂时无法同步，正在显示本机保存的正文。" }
    }
  }
  func stop(clear: Bool) {
    generation = UUID()
    task?.cancel()
    task = nil
    transfer = nil
    loading = false
    if clear {
      cached = false
      receivingPreview = false
      htmlDocument = nil
      htmlNotice = nil
      metadata = nil
      pager = nil
      text = ""
      page = 0
      pageCount = 0
      exportURL = nil
      destinations = []
      for url in directories { try? FileManager.default.removeItem(at: url) }
      directories = []
    }
  }
  func cancelDownload() {
    if receivingPreview {
      text = ""
      receivingPreview = false
    }
    stop(clear: false)
    error = "下载已取消，可以重新下载。"
  }
  func download(attachment: MailAttachment?, using store: MailStore) {
    guard transfer == nil, !invalidated, let session = store.session else { return }
    let ticket = generation
    error = nil
    received = 0
    transfer = attachment?.filename ?? "正文"
    let identity = identity
    task = Task { [weak self] in
      guard let self else { return }
      var directory: URL?
      defer {
        if self.generation == ticket {
          self.transfer = nil
          self.task = nil
        }
      }
      do {
        let cacheTicket = await store.cache.ticket()
        let dir = try TransferFiles.createDirectory()
        directory = dir
        self.directories.append(dir)
        let filename = attachment.map { TransferFiles.safeFilename($0.filename) } ?? "body.txt"
        let file = dir.appendingPathComponent(filename)
        let suffix = attachment.map { ["attachments", String($0.id)] } ?? ["body"]
        var request = try store.api.makeRequest(
          server: session.server, path: identity.path + suffix,
          token: session.token, query: identity.query)
        request.timeoutInterval = 600
        let preview: (@Sendable (String) async -> Void)?
        if attachment == nil && self.metadata?.body?.contentType != "text/html" {
          preview = { [weak self] value in await self?.showPreview(value, ticket: ticket) }
        } else {
          preview = nil
        }
        let worker = Task.detached { [self, request] in
          try await TransferFiles.receive(request, at: file, preview: preview) { count in
            await self.updateProgress(count, ticket: ticket)
          }
        }
        try await withTaskCancellationHandler {
          try await worker.value
        } onCancel: {
          worker.cancel()
        }
        try Task.checkCancellation()
        // Recheck the device and mailbox authorization without opening IMAP again.
        _ = try await store.api.request(
          OperationResult.self, server: session.server,
          path: ["api", "accounts", identity.account, "access"], token: session.token)
        guard ticket == self.generation, store.session?.token == session.token else {
          try? FileManager.default.removeItem(at: dir)
          return
        }
        if attachment != nil {
          self.exportURL = file
        } else {
          await self.prepareBody(at: file)
          guard ticket == self.generation, store.session?.token == session.token else { return }
          self.receivingPreview = false
          if let metadata = self.metadata {
            try? await store.cache.save(
              identity, session: session, metadata: metadata,
              body: file, ticket: cacheTicket)
          }
        }
      } catch {
        if let directory { try? FileManager.default.removeItem(at: directory) }
        guard ticket == self.generation, store.session?.token == session.token else { return }
        if self.receivingPreview {
          self.text = ""
          self.receivingPreview = false
        }
        self.handle(error, using: store)
      }
    }
  }
  private func showPreview(_ text: String, ticket: UUID) {
    guard generation == ticket, pager == nil else { return }
    self.text = text
    receivingPreview = !text.isEmpty
  }
  private func prepareBody(at file: URL) async {
    let ticket = generation
    do {
      let pager = try BodyPager(url: file)
      self.pager = pager
      pageCount = pager.pageCount
      showPage(0)
      guard metadata?.body?.contentType == "text/html" else { return }
      guard pager.byteCount <= HTMLDocument.maximumBytes else {
        htmlNotice = "HTML 正文超过 2 MiB，已切换为分段源码；可继续阅读全部内容。"
        return
      }
      let attachments = metadata?.attachments ?? []
      let document = try await Task.detached {
        let source = try String(contentsOf: file, encoding: .utf8)
        return try HTMLDocument.parse(source, attachments: attachments)
      }.value
      guard ticket == generation else { return }
      htmlDocument = document
    } catch {
      guard ticket == generation else { return }
      htmlNotice = "无法排版此邮件，已切换为分段源码。"
    }
  }

  func inlineImage(_ id: Int, using store: MailStore) async throws -> Data {
    // A cached document may be visible before authorization refresh completes.
    // Its images are retried by the view when canMutate changes to true.
    guard canMutate else { throw CancellationError() }
    guard let session = store.session, !invalidated,
      htmlDocument?.inlineIDs.contains(id) == true,
      let attachment = metadata?.attachments.first(where: { $0.id == id }),
      InlineImagePolicy.types.contains(attachment.contentType.lowercased()),
      attachment.size <= InlineImagePolicy.maximumBytes
    else { throw ClientError.forbidden }
    let ticket = generation
    let directory = try TransferFiles.createDirectory()
    defer { try? FileManager.default.removeItem(at: directory) }
    let file = directory.appendingPathComponent("inline-image")
    let request = try store.api.makeRequest(
      server: session.server, path: identity.path + ["attachments", String(id)],
      token: session.token, query: identity.query)
    do {
      let worker = Task.detached {
        try await TransferFiles.receive(
          request, at: file, maximumBytes: InlineImagePolicy.maximumBytes
        ) { _ in }
        try Task.checkCancellation()
        return try InlineImageHandler.rasterData(at: file)
      }
      let data = try await withTaskCancellationHandler {
        try await worker.value
      } onCancel: {
        worker.cancel()
      }
      _ = try await store.api.request(
        OperationResult.self, server: session.server,
        path: ["api", "accounts", identity.account, "access"], token: session.token)
      try Task.checkCancellation()
      guard ticket == generation, store.session?.token == session.token else {
        throw CancellationError()
      }
      return data
    } catch {
      if ticket == generation, store.session?.token == session.token { handle(error, using: store) }
      throw error
    }
  }
  private func updateProgress(_ count: Int64, ticket: UUID) {
    if generation == ticket { received = count }
  }
  func showPage(_ number: Int) {
    guard let pager else { return }
    do {
      text = try pager.text(at: number)
      page = number
    } catch { self.error = "无法读取临时正文，请重新加载。" }
  }
  func quote() -> String {
    if let htmlDocument { return htmlDocument.plainText() }
    guard let pager, let first = try? pager.text(at: 0) else { return "（正文尚未下载）" }
    return first + (pager.pageCount > 1 ? "\n（仅引用正文开头）" : "")
  }
  func finishExport() {
    if let url = exportURL {
      try? FileManager.default.removeItem(at: url.deletingLastPathComponent())
    }
    exportURL = nil
  }
  func folders(using store: MailStore) async {
    guard let session = store.session else { return }
    let ticket = generation
    do {
      let folders = try await store.api.request(
        [MailFolder].self, server: session.server,
        path: ["api", "accounts", identity.account, "folders"], token: session.token
      )
      .filter { $0.path != identity.folder }
      guard ticket == generation, store.session?.token == session.token else { return }
      destinations = folders
      if folders.isEmpty { error = "没有可移动到的其他文件夹。" }
    } catch {
      guard ticket == generation, store.session?.token == session.token else { return }
      handle(error, using: store)
    }
  }
  /// Never retries mutations. A failed response may have followed a successful upstream action.
  func mutate(_ action: String, destination: String? = nil, using store: MailStore) async -> Bool {
    guard !mutating, transfer == nil, canMutate, !invalidated, let session = store.session else {
      return false
    }
    let ticket = generation
    mutating = true
    error = nil
    defer { mutating = false }
    var payload = ["action": action]
    if let destination { payload["destination"] = destination }
    do {
      let result = try await store.api.request(
        MailActionResult.self, server: session.server,
        path: identity.path + ["actions"], token: session.token, query: identity.query,
        body: JSONEncoder().encode(payload))
      guard store.session?.token == session.token, result.updated else { return false }
      if result.destination != nil {
        try store.index.update(identity, removed: true)
        store.removePreviews(
          account: identity.account, folder: identity.folder,
          validity: identity.uidValidity, removed: [identity.uid])
        store.mailboxChanged(identity.account)
        await store.cache.remove(identity, session: session)
        stop(clear: true)
        return true
      }
      // Reload actual flags and metadata rather than toggling the UI optimistically.
      let fresh = try await store.api.request(
        MessageMetadata.self, server: session.server,
        path: identity.path, token: session.token, query: identity.query)
      guard ticket == generation, store.session?.token == session.token else { return false }
      try store.index.update(identity, flags: fresh.flags ?? [])
      metadata = fresh
      store.mailboxChanged(identity.account)
      return false
    } catch {
      guard ticket == generation, store.session?.token == session.token else { return false }
      canMutate = false
      store.mailboxChanged(identity.account)
      handle(error, using: store)
      if !invalidated && store.session != nil {
        self.error = error.localizedDescription + " 操作结果可能不确定，请刷新核对；不会自动重试。"
      }
      return false
    }
  }
  func handle(_ failure: Error, using store: MailStore) {
    if failure is CancellationError || (failure as? URLError)?.code == .cancelled { return }
    switch failure {
    case ClientError.changed, ClientError.forbidden, ClientError.expired, ClientError.http(404):
      if let session = store.session {
        Task { await store.cache.remove(identity, session: session) }
      }
      stop(clear: true)
      invalidated = true
      store.mailboxChanged(identity.account)
    default: break
    }
    error = failure.localizedDescription
    store.handle(failure)
  }
}
