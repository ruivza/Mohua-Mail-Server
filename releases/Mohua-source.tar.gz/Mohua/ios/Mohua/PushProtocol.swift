import Foundation

struct PushState: Decodable { let pushStatus: String }

enum MailPush {
  static var appID: String {
    (Bundle.main.object(forInfoDictionaryKey: "MohuaGatewayAppID") as? String).flatMap {
      $0.isEmpty ? nil : $0
    } ?? "mohua"
  }

  static var isSimulator: Bool {
    #if targetEnvironment(simulator)
      true
    #else
      false
    #endif
  }

  static func trusts(_ gateway: URL, configured: String) -> Bool {
    guard let trusted = URL(string: configured), trusted.scheme == "https",
      trusted.host != nil, trusted.user == nil, trusted.password == nil,
      trusted.query == nil, trusted.fragment == nil,
      ["", "/"].contains(trusted.path), gateway.scheme == "https",
      gateway.user == nil, gateway.password == nil, gateway.query == nil,
      gateway.fragment == nil, ["", "/"].contains(gateway.path)
    else { return false }
    return gateway.host?.lowercased() == trusted.host?.lowercased()
      && (gateway.port ?? 443) == (trusted.port ?? 443)
  }

  /// A delayed notification for another login must never wake the current user's sync.
  static func accepts(_ payload: [AnyHashable: Any], device: String?) -> Bool {
    guard let device, let aps = payload["aps"] as? [String: Any],
      aps["content-available"] as? Int == 1,
      let hint = payload["mohua"] as? [String: Any], hint["version"] as? Int == 1,
      hint["deviceId"] as? String == device,
      (hint["appId"] as? String ?? "mohua") == appID
    else { return false }
    return true
  }
  static func description(_ status: String) -> String {
    switch status {
    case "device_disabled": return "本设备通知已关闭"
    case "server_disabled": return "服务器管理员已停用推送"
    case "ready": return "后台更新已登记"
    case "not_configured": return "服务器尚未配置推送"
    case "not_registered": return "设备尚未登记推送"
    case "retrying": return "推送暂时失败，服务器会重试"
    case "configuration_error": return "服务器推送认证需要检查"
    case "retry_exhausted", "rejected": return "推送发送失败，请检查服务器配置"
    default: return "推送状态暂不可用"
    }
  }
}

/// Completes exactly once; timeout and foreground entry also cancel outstanding network work.
@MainActor
final class BackgroundRun<Result> {
  private var work: Task<Void, Never>?
  private var timer: Task<Void, Never>?
  private var id: UUID?
  private var completion: ((Result) -> Void)?

  @discardableResult
  func start(
    timeout: Duration = .seconds(25), timeoutResult: Result,
    operation: @escaping @MainActor () async -> Result,
    completion: @escaping (Result) -> Void
  ) -> Bool {
    guard id == nil else { return false }
    let request = UUID()
    id = request
    self.completion = completion
    work = Task { [weak self] in
      guard !Task.isCancelled else { return }
      let result = await operation()
      self?.finish(request, result: result)
    }
    timer = Task { [weak self] in
      do { try await Task.sleep(for: timeout) } catch { return }
      self?.finish(request, result: timeoutResult)
    }
    return true
  }
  func cancel(result: Result) {
    if let id { finish(id, result: result) }
  }
  private func finish(_ request: UUID, result: Result) {
    guard id == request else { return }
    let callback = completion
    id = nil
    completion = nil
    work?.cancel()
    timer?.cancel()
    work = nil
    timer = nil
    callback?(result)
  }
}
