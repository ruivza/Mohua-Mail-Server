import SwiftUI

struct MessagesView: View {
  @EnvironmentObject private var store: MailStore
  @Environment(\.scenePhase) private var phase
  @StateObject private var model = MailListModel()
  @State private var search = ""
  @State private var filter = Filter.all
  @State private var composing: MailDraft?
  let account: Mailbox?
  let folder: MailFolder

  init(account: Mailbox, folder: MailFolder) {
    self.account = account
    self.folder = folder
  }

  init() {
    account = nil
    folder = MailFolder(path: "INBOX", name: "所有收件箱", specialUse: "\\Inbox")
  }

  private enum Filter: String, CaseIterable {
    case all = "全部"
    case unread = "未读"
    case flagged = "旗标"
  }
  private var accounts: [Mailbox] {
    store.accounts.filter { $0.mode == "proxy" && (account == nil || $0.id == account?.id) }
  }
  private var visible: [MailRow] {
    model.rows.filter { row in
      guard accounts.contains(where: { $0.id == row.account.id }) else { return false }
      let flags = row.summary.flags
      let matchesFilter =
        filter == .all || (filter == .unread && !flags.contains("\\Seen"))
        || (filter == .flagged && flags.contains("\\Flagged"))
      let haystack = [row.summary.sender, row.summary.subject, store.previews[row.identity] ?? ""]
        .joined(separator: " ")
      return matchesFilter && (search.isEmpty || haystack.localizedCaseInsensitiveContains(search))
    }
  }

  var body: some View {
    List {
      if accounts.isEmpty {
        ContentUnavailableView("暂无邮箱", systemImage: "tray", description: Text("请先添加一个邮箱。"))
      }
      if let error = model.error {
        VStack(alignment: .leading, spacing: 8) {
          Text(error).font(.subheadline).foregroundStyle(.secondary)
          Button("重新加载") { Task { await load(reset: true) } }.disabled(model.busy)
        }
      }
      if model.pendingNew && !model.busy {
        Button("继续同步新邮件") { Task { await load(reset: true) } }
      }
      ForEach(visible) { row in
        NavigationLink {
          MessageDetailView(identity: row.identity)
        } label: {
          MailRowView(row: row, preview: store.previews[row.identity], showAccount: account == nil)
        }
        .accessibilityIdentifier(
          account == nil
            ? "message-\(row.account.id)-\(row.summary.uid)" : "message-\(row.summary.uid)"
        )
        .listRowInsets(EdgeInsets(top: 11, leading: 12, bottom: 11, trailing: 16))
      }
      if model.busy {
        HStack {
          Spacer()
          ProgressView()
          Spacer()
        }.listRowSeparator(.hidden)
      } else if model.hasMore {
        Button("加载下一页") { Task { await load(reset: false) } }
          .frame(maxWidth: .infinity).listRowSeparator(.hidden)
      } else if visible.isEmpty && !accounts.isEmpty && model.error == nil {
        ContentUnavailableView(
          search.isEmpty && filter == .all ? "暂无邮件" : "没有匹配的邮件",
          systemImage: "tray",
          description: Text(search.isEmpty && filter == .all ? "下拉刷新以检查新邮件。" : "搜索和筛选仅包含已加载的邮件。"))
      }
      if !search.isEmpty || filter != .all {
        Text("搜索和筛选仅包含已加载的邮件。")
          .font(.footnote).foregroundStyle(.secondary).listRowSeparator(.hidden)
      }
    }
    .listStyle(.plain)
    .navigationTitle(folder.name)
    .searchable(
      text: $search, placement: .navigationBarDrawer(displayMode: .always), prompt: "搜索已加载的邮件"
    )
    .refreshable { await load(reset: true) }
    .toolbar {
      ToolbarItem(placement: .topBarTrailing) {
        Button {
          Task { await load(reset: true) }
        } label: {
          Image(systemName: "arrow.clockwise")
        }
        .accessibilityLabel("刷新").accessibilityIdentifier("refreshMessages").disabled(model.busy)
      }
      ToolbarItem(placement: .bottomBar) {
        Menu {
          Picker("显示", selection: $filter) {
            ForEach(Filter.allCases, id: \.self) { Text($0.rawValue).tag($0) }
          }
        } label: {
          Image(
            systemName: filter == .all
              ? "line.3.horizontal.decrease.circle" : "line.3.horizontal.decrease.circle.fill")
        }.accessibilityLabel("筛选邮件")
      }
      ToolbarItem(placement: .bottomBar) {
        VStack(spacing: 2) {
          Text("已加载 \(model.rows.count) 封邮件")
          if let updated = model.updated {
            Text("同步于 \(updated.formatted(date: .abbreviated, time: .shortened))").foregroundStyle(
              .secondary)
          }
        }.font(.caption)
      }
      ToolbarItem(placement: .bottomBar) {
        Button {
          composing = MailDraft(accountID: accounts.first?.id ?? "")
        } label: {
          Image(systemName: "square.and.pencil")
        }.accessibilityLabel("写邮件").accessibilityIdentifier("composeNew").disabled(accounts.isEmpty)
      }
    }
    .task(id: phase) {
      if phase == .active { await load(reset: true) } else { store.cancelPrefetch() }
    }
    .onChange(of: store.mailboxVersions) { _, _ in
      if phase == .active { Task { await load(reset: true) } }
    }
    .onChange(of: store.accounts) { _, _ in
      if phase == .active { Task { await load(reset: true) } }
    }
    .onDisappear { store.cancelPrefetch() }
    .sheet(item: $composing) { ComposeView(draft: $0) }
  }

  private func load(reset: Bool) async {
    await model.load(accounts: accounts, folder: folder.path, reset: reset, store: store)
  }
}

private struct MailRowView: View {
  let row: MailRow
  let preview: String?
  let showAccount: Bool
  var body: some View {
    HStack(alignment: .top, spacing: 8) {
      Circle().fill(row.summary.flags.contains("\\Seen") ? Color.clear : Color.accentColor)
        .frame(width: 8, height: 8).padding(.top, 6).accessibilityHidden(true)
      VStack(alignment: .leading, spacing: 4) {
        HStack(alignment: .firstTextBaseline) {
          Text(row.summary.sender).font(.headline).lineLimit(1)
          Spacer(minLength: 8)
          Text(MailDate.label(row.summary.date)).font(.caption).foregroundStyle(.secondary)
        }
        Text(row.summary.subject.isEmpty ? "（无主题）" : row.summary.subject)
          .font(.subheadline).lineLimit(1)
        if let preview, !preview.isEmpty {
          Text(preview).font(.subheadline).foregroundStyle(.secondary).lineLimit(2)
        }
        if showAccount || row.summary.flags.contains("\\Flagged") {
          HStack(spacing: 5) {
            if row.summary.flags.contains("\\Flagged") {
              Image(systemName: "flag.fill").foregroundStyle(.orange)
            }
            if showAccount { Text(row.account.email).foregroundStyle(.secondary) }
          }.font(.caption2)
        }
      }
    }.padding(.vertical, 2)
      .accessibilityElement(children: .combine)
      .accessibilityValue(
        (row.summary.flags.contains("\\Seen") ? "已读" : "未读")
          + (row.summary.flags.contains("\\Flagged") ? "，已加旗标" : ""))
  }
}
