import SwiftUI

@main
struct MohuaApp: App {
  @UIApplicationDelegateAdaptor(PushAppDelegate.self) private var delegate
  var body: some Scene {
    WindowGroup { MailRootView(store: delegate.store) }
  }
}

private struct MailRootView: View {
  @ObservedObject var store: MailStore
  @Environment(\.scenePhase) private var scenePhase
  var body: some View {
    Group {
      if store.session != nil { AccountsView() } else { LoginView() }
    }
    .environmentObject(store)
    .overlay {
      if scenePhase != .active {
        Color(.systemBackground).ignoresSafeArea().overlay(Text("Mohua").font(.title))
      }
    }
    .task(id: scenePhase) {
      if scenePhase == .active {
        store.restoreSession()
        await store.refresh()
        store.registerForPush()
      }
    }
    .onChange(of: store.session?.token) { _, _ in store.registerForPush() }
  }
}

struct AccountsView: View {
  @EnvironmentObject private var store: MailStore
  @State private var adding = false
  @State private var composing: MailDraft?
  private let inbox = MailFolder(path: "INBOX", name: "收件箱", specialUse: "\\Inbox")

  var body: some View {
    NavigationStack {
      List {
        if let notice = store.notice { Text(notice).font(.footnote).foregroundStyle(.secondary) }
        if store.accounts.isEmpty {
          ContentUnavailableView(
            "欢迎使用 Mohua", systemImage: "envelope.open",
            description: Text("添加邮箱后，你可以在这里查看所有来信。"))
          Button("添加第一个邮箱") { adding = true }
        } else {
          Section {
            NavigationLink {
              MessagesView()
            } label: {
              Label("所有收件箱", systemImage: "tray.2.fill")
            }.accessibilityIdentifier("allInboxes")
            ForEach(store.accounts.filter { $0.mode == "proxy" }) { account in
              NavigationLink {
                MessagesView(account: account, folder: inbox)
              } label: {
                Label {
                  VStack(alignment: .leading, spacing: 3) {
                    Text("收件箱")
                    Text(account.email).font(.caption).foregroundStyle(.secondary)
                  }
                } icon: {
                  Image(systemName: "tray")
                }
              }.accessibilityIdentifier("inbox-\(account.id)")
            }
          }
          Section("账户") {
            ForEach(store.accounts) { account in
              if account.mode == "proxy" {
                NavigationLink {
                  FoldersView(account: account)
                } label: {
                  Label(account.email, systemImage: "folder")
                }
              } else {
                Label {
                  VStack(alignment: .leading) {
                    Text(account.email)
                    Text("直连模式尚未支持").font(.caption).foregroundStyle(.secondary)
                  }
                } icon: {
                  Image(systemName: "envelope.badge")
                }
              }
            }
          }
        }
        Section {
          NavigationLink("草稿与发送记录") { DraftsView() }.accessibilityIdentifier("drafts")
        }
      }
      .navigationTitle("邮箱")
      .refreshable { await store.refresh() }
      .toolbar {
        ToolbarItem(placement: .topBarTrailing) {
          NavigationLink {
            ClientSettingsView()
          } label: {
            Image(systemName: "gearshape")
          }
          .accessibilityLabel("管理")
        }
        ToolbarItem(placement: .bottomBar) {
          Button {
            Task { await store.refresh() }
          } label: {
            Image(systemName: "arrow.clockwise")
          }
          .accessibilityLabel("刷新").accessibilityIdentifier("refreshAccounts")
        }
        ToolbarItem(placement: .bottomBar) {
          Text("\(store.accounts.count) 个邮箱").font(.caption).foregroundStyle(.secondary)
        }
        ToolbarItem(placement: .bottomBar) {
          Button {
            adding = true
          } label: {
            Image(systemName: "plus")
          }.accessibilityLabel("添加邮箱")
        }
        ToolbarItem(placement: .bottomBar) {
          Button {
            composing = MailDraft(
              accountID: store.accounts.first(where: { $0.mode == "proxy" })?.id ?? "")
          } label: {
            Image(systemName: "square.and.pencil")
          }.accessibilityLabel("写邮件").accessibilityIdentifier("composeNew")
            .disabled(!store.accounts.contains { $0.mode == "proxy" })
        }
      }
      .sheet(isPresented: $adding) { NavigationStack { MailboxSettingsView(account: nil) } }
      .sheet(item: $composing) { ComposeView(draft: $0) }
    }
  }
}

struct FoldersView: View {
  @EnvironmentObject private var store: MailStore
  let account: Mailbox
  @State private var folders: [MailFolder] = []
  @State private var error: String?
  @State private var busy = false
  @Environment(\.scenePhase) private var phase
  private var linked: Bool {
    store.accounts.contains(where: { $0.id == account.id && $0.mode == "proxy" })
  }
  var body: some View {
    List {
      if !linked {
        Text("邮箱已移除或不再使用代理模式。")
      } else {
        if let error { Text(error).foregroundStyle(.red) }
        if busy { ProgressView() }
        ForEach(folders) { folder in
          NavigationLink {
            MessagesView(account: account, folder: folder)
          } label: {
            Label(folder.name, systemImage: folder.icon)
          }
        }
      }
    }.navigationTitle(account.email)
      .toolbar {
        Button("刷新") { Task { await load() } }.disabled(busy).accessibilityIdentifier(
          "refreshFolders")
      }
      .task(id: phase) { if phase == .active { await load() } }
      .refreshable { await load() }
  }
  private func load() async {
    guard linked, !busy, let session = store.session else { return }
    folders = store.index.folders(account.id)
    busy = true
    error = nil
    defer { busy = false }
    do {
      let result = try await store.api.request(
        [MailFolder].self, server: session.server,
        path: ["api", "accounts", account.id, "folders"], token: session.token)
      guard store.session?.token == session.token, linked else { return }
      let removed = try store.index.saveFolders(result, account: account.id)
      folders = result
      for folder in removed {
        await store.cache.reconcile(account: account.id, folder: folder, session: session)
        store.removePreviews(account: account.id, folder: folder)
      }
    } catch {
      guard store.session?.token == session.token else { return }
      if error is CancellationError || (error as? URLError)?.code == .cancelled { return }
      switch error {
      case ClientError.expired, ClientError.forbidden, ClientError.http(404):
        folders = []
        store.discardAccount(account.id)
      default: break
      }
      self.error = "文件夹未能更新，保留本机目录。" + error.localizedDescription
      store.handle(error)
    }
  }
}

extension MailFolder {
  var icon: String {
    switch specialUse {
    case "\\Inbox": return "tray"
    case "\\Sent": return "paperplane"
    case "\\Drafts": return "doc"
    case "\\Trash": return "trash"
    case "\\Archive": return "archivebox"
    case "\\Junk": return "exclamationmark.shield"
    default: return path == "INBOX" ? "tray" : "folder"
    }
  }
}
