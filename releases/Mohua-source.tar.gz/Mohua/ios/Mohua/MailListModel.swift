import SwiftUI

struct MailRow: Identifiable {
  let identity: MessageIdentity
  let account: Mailbox
  let summary: MailSummary
  var id: MessageIdentity { identity }
}

@MainActor
final class MailListModel: ObservableObject {
  @Published private(set) var rows: [MailRow] = []
  @Published private(set) var busy = false
  @Published private(set) var hasMore = false
  @Published private(set) var pendingNew = false
  @Published private(set) var updated: Date?
  @Published private(set) var error: String?
  private var snapshots: [String: FolderSnapshot] = [:]
  private var refreshPending = false

  func load(
    accounts: [Mailbox], folder: String, reset: Bool, store: MailStore, prefetch: Bool = true
  ) async {
    if busy {
      refreshPending = refreshPending || reset
      return
    }
    guard let session = store.session else { return }
    busy = true
    error = nil
    store.cancelPrefetch()
    if reset {
      snapshots = Dictionary(
        uniqueKeysWithValues: accounts.compactMap { account in
          store.index.snapshot(account: account.id, folder: folder).map { (account.id, $0) }
        })
    }
    render(accounts: accounts)
    for account in accounts {
      if Task.isCancelled { break }
      guard store.accounts.contains(where: { $0.id == account.id && $0.mode == "proxy" }) else {
        continue
      }
      let ticket = store.index.generation
      do {
        var value: FolderSnapshot
        var removed: Set<Int> = []
        if reset, let saved = snapshots[account.id], saved.highWater != nil {
          (value, removed) = try await synchronize(saved, session: session, api: store.api)
        } else {
          let saved = snapshots[account.id]
          if !reset, saved != nil, saved?.nextBefore == nil { continue }
          value = try await page(
            account: account.id, folder: folder,
            previous: reset ? nil : saved, session: session, api: store.api)
        }
        try Task.checkCancellation()
        guard store.session?.token == session.token else { break }
        try store.index.save(value, ticket: ticket)
        snapshots[account.id] = value
        // Purge only confirmed missing messages; older, unloaded UIDs are not deletions.
        await store.cache.reconcile(
          account: account.id, folder: folder, session: session,
          validity: value.uidValidity, removed: removed)
        store.removePreviews(
          account: account.id, folder: folder,
          validity: value.uidValidity, removed: removed)
      } catch ClientError.changed {
        guard store.session?.token == session.token else { break }
        guard ticket == store.index.generation else {
          refreshPending = true
          continue
        }
        // A UID epoch change invalidates both the list and every body in this folder.
        store.index.removeFolder(account: account.id, folder: folder)
        snapshots.removeValue(forKey: account.id)
        await store.cache.reconcile(account: account.id, folder: folder, session: session)
        store.removePreviews(account: account.id, folder: folder)
        let replacementTicket = store.index.generation
        do {
          let fresh = try await page(
            account: account.id, folder: folder, previous: nil,
            session: session, api: store.api)
          try Task.checkCancellation()
          guard store.session?.token == session.token else { break }
          try store.index.save(fresh, ticket: replacementTicket)
          snapshots[account.id] = fresh
        } catch {
          if store.session?.token == session.token {
            record(error, account: account.id, folder: folder, store: store)
          }
        }
      } catch {
        guard store.session?.token == session.token else { break }
        if error is CancellationError, !Task.isCancelled, ticket != store.index.generation {
          refreshPending = true
        } else {
          record(error, account: account.id, folder: folder, store: store)
        }
      }
      if store.session == nil {
        snapshots = [:]
        break
      }
      render(accounts: accounts)
    }
    render(accounts: store.session == nil ? [] : accounts)
    busy = false
    if refreshPending && !Task.isCancelled {
      refreshPending = false
      let current = accounts.filter { account in
        store.accounts.contains { $0.id == account.id && $0.mode == "proxy" }
      }
      await load(accounts: current, folder: folder, reset: true, store: store, prefetch: prefetch)
    } else if prefetch && error == nil && !Task.isCancelled {
      store.prefetch(rows.map { ($0.identity, $0.summary.size) })
    }
  }

  private func page(
    account: String, folder: String, previous: FolderSnapshot?,
    session: DeviceSession, api: MailAPI
  ) async throws -> FolderSnapshot {
    var query = [
      URLQueryItem(name: "folder", value: folder), URLQueryItem(name: "limit", value: "25"),
    ]
    if let previous, let before = previous.nextBefore {
      query += [
        URLQueryItem(name: "uidValidity", value: previous.uidValidity),
        URLQueryItem(name: "before", value: String(before)),
      ]
    }
    let result = try await api.request(
      MailPage.self, server: session.server,
      path: ["api", "accounts", account, "messages"], token: session.token, query: query)
    if let previous, previous.uidValidity != result.uidValidity { throw ClientError.changed }
    var items = Dictionary(
      (previous?.items ?? []).map { ($0.uid, $0) }, uniquingKeysWith: { _, last in last })
    for item in result.items { items[item.uid] = item }
    return FolderSnapshot(
      account: account, folder: folder, uidValidity: result.uidValidity,
      highWater: previous?.highWater ?? result.highWater, nextBefore: result.nextBefore,
      items: items.values.sorted { $0.uid > $1.uid }, syncedAt: previous?.syncedAt ?? Date(),
      pendingNew: previous?.pendingNew ?? false)
  }

  private func synchronize(_ saved: FolderSnapshot, session: DeviceSession, api: MailAPI)
    async throws -> (FolderSnapshot, Set<Int>)
  {
    var value = saved
    let known = saved.items.map(\.uid)
    let chunks = stride(from: 0, to: known.count, by: 500).map {
      Array(known[$0..<min($0 + 500, known.count)])
    }
    var removed: Set<Int> = []
    // At most 5,000 new UIDs per refresh; expose continuation when a large backlog remains.
    for round in 0..<max(5, chunks.count) {
      try Task.checkCancellation()
      let batch = round < chunks.count ? chunks[round] : []
      let body = try JSONSerialization.data(withJSONObject: [
        "folder": value.folder, "uidValidity": value.uidValidity,
        "after": value.highWater!, "known": batch,
      ])
      let delta = try await api.request(
        MailDelta.self, server: session.server,
        path: ["api", "accounts", value.account, "sync"], token: session.token, body: body)
      removed.formUnion(try value.merge(delta, known: Set(batch)))
      if !delta.hasMore && round + 1 >= chunks.count { break }
    }
    return (value, removed)
  }

  private func record(_ failure: Error, account: String, folder: String, store: MailStore) {
    if failure is CancellationError || (failure as? URLError)?.code == .cancelled { return }
    switch failure {
    case ClientError.expired, ClientError.forbidden, ClientError.http(404):
      snapshots.removeValue(forKey: account)
      store.discardAccount(account)
      error = failure.localizedDescription
    default:
      error = "同步未完成，正在显示本机保存的列表。" + failure.localizedDescription
    }
    store.handle(failure)
  }

  private func render(accounts: [Mailbox]) {
    rows = accounts.flatMap { account in
      guard let value = snapshots[account.id] else { return [MailRow]() }
      return value.items.map { message in
        MailRow(
          identity: MessageIdentity(
            account: account.id, folder: value.folder,
            uidValidity: value.uidValidity, uid: message.uid), account: account, summary: message)
      }
    }
    rows.sort {
      if accounts.count == 1 { return $0.summary.uid > $1.summary.uid }
      let first = MailDate.parse($0.summary.date) ?? .distantPast
      let second = MailDate.parse($1.summary.date) ?? .distantPast
      if first != second { return first > second }
      if $0.summary.uid != $1.summary.uid { return $0.summary.uid > $1.summary.uid }
      return $0.account.id < $1.account.id
    }
    hasMore = snapshots.values.contains { $0.nextBefore != nil }
    pendingNew = snapshots.values.contains { $0.pendingNew }
    updated = snapshots.values.map(\.syncedAt).min()
  }
}

enum MailDate {
  static func parse(_ value: String?) -> Date? {
    guard let value else { return nil }
    let formatter = ISO8601DateFormatter()
    formatter.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
    return formatter.date(from: value) ?? ISO8601DateFormatter().date(from: value)
  }

  static func label(_ value: String?) -> String {
    guard let date = parse(value) else { return "" }
    if Calendar.current.isDateInToday(date) {
      return date.formatted(date: .omitted, time: .shortened)
    }
    if Calendar.current.isDateInYesterday(date) { return "昨天" }
    return date.formatted(.dateTime.month(.abbreviated).day())
  }
}
