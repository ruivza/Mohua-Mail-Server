import ImageIO
import SwiftUI
import WebKit

struct HTMLMessageView: UIViewRepresentable {
  let document: HTMLDocument
  let allowRemoteImages: Bool
  let loadInline: @MainActor (Int) async throws -> Data
  let openLink: (URL) -> Void
  let reportError: (String) -> Void

  func makeCoordinator() -> Coordinator { Coordinator(parent: self) }

  func makeUIView(context: Context) -> WKWebView {
    let configuration = WKWebViewConfiguration()
    configuration.websiteDataStore = .nonPersistent()
    configuration.defaultWebpagePreferences.allowsContentJavaScript = false
    configuration.preferences.javaScriptCanOpenWindowsAutomatically = false
    configuration.dataDetectorTypes = []
    configuration.setURLSchemeHandler(context.coordinator.images, forURLScheme: "mohua-image")
    let view = WKWebView(frame: .zero, configuration: configuration)
    view.navigationDelegate = context.coordinator
    view.allowsLinkPreview = false
    view.isOpaque = true
    view.backgroundColor = .white
    view.accessibilityIdentifier = "htmlBody"
    return view
  }

  func updateUIView(_ view: WKWebView, context: Context) {
    context.coordinator.parent = self
    context.coordinator.load(document, allowRemoteImages: allowRemoteImages, into: view)
  }

  static func dismantleUIView(_ view: WKWebView, coordinator: Coordinator) {
    coordinator.generation = UUID()
    coordinator.images.cancelAll()
    view.stopLoading()
    view.navigationDelegate = nil
  }

  @MainActor
  final class Coordinator: NSObject, WKNavigationDelegate {
    var parent: HTMLMessageView
    let images: InlineImageHandler
    var generation = UUID()
    private var loaded: String?

    init(parent: HTMLMessageView) {
      self.parent = parent
      images = InlineImageHandler(load: parent.loadInline, reportError: parent.reportError)
    }

    func load(_ document: HTMLDocument, allowRemoteImages: Bool, into view: WKWebView) {
      let page = document.page(allowRemoteImages: allowRemoteImages)
      guard page != loaded else { return }
      loaded = page
      generation = UUID()
      let ticket = generation
      view.stopLoading()
      // CSP is the main resource policy; a separate WebKit blocker also denies network requests.
      var rules: [[String: Any]] = [
        ["trigger": ["url-filter": "^https?://"], "action": ["type": "block"]]
      ]
      if allowRemoteImages {
        rules.append([
          "trigger": ["url-filter": "^https://", "resource-type": ["image"]],
          "action": ["type": "ignore-previous-rules"],
        ])
      }
      let encoded = String(
        data: try! JSONSerialization.data(withJSONObject: rules), encoding: .utf8)!
      WKContentRuleListStore.default().compileContentRuleList(
        forIdentifier: allowRemoteImages ? "mohua-images" : "mohua-private",
        encodedContentRuleList: encoded
      ) { [weak self, weak view] list, error in
        guard let self, let view, self.generation == ticket else { return }
        guard let list, error == nil else {
          self.parent.reportError("无法启用安全阅读策略，请重新打开邮件。")
          return
        }
        view.configuration.userContentController.removeAllContentRuleLists()
        view.configuration.userContentController.add(list)
        view.loadHTMLString(page, baseURL: nil)
      }
    }

    func webView(
      _ webView: WKWebView, decidePolicyFor action: WKNavigationAction,
      decisionHandler: @escaping (WKNavigationActionPolicy) -> Void
    ) {
      if action.navigationType == .linkActivated,
        let value = action.request.url?.absoluteString, let url = HTMLDocument.externalURL(value)
      {
        parent.openLink(url)
      }
      let initial =
        action.navigationType == .other && action.targetFrame?.isMainFrame == true
        && action.request.url?.absoluteString == "about:blank"
      decisionHandler(initial ? .allow : .cancel)
    }

    func webViewWebContentProcessDidTerminate(_ webView: WKWebView) {
      parent.reportError("邮件排版进程已停止，请刷新邮件重试。")
    }
  }
}

/// Only serves MIME attachment IDs selected by the sanitizer. Requests run serially to respect
/// the server's per-user read limit. No credential or server URL is exposed to the web document.
@MainActor
final class InlineImageHandler: NSObject, WKURLSchemeHandler {
  private let load: (Int) async throws -> Data
  private let reportError: (String) -> Void
  private var pending: [any WKURLSchemeTask] = []
  private var active: (any WKURLSchemeTask)?
  private var worker: Task<Void, Never>?
  private var cache: [Int: Data] = [:]
  private var attempts: Set<Int> = []
  private var totalBytes = 0

  init(load: @escaping (Int) async throws -> Data, reportError: @escaping (String) -> Void) {
    self.load = load
    self.reportError = reportError
  }

  func webView(_ webView: WKWebView, start urlSchemeTask: any WKURLSchemeTask) {
    pending.append(urlSchemeTask)
    next()
  }
  func webView(_ webView: WKWebView, stop urlSchemeTask: any WKURLSchemeTask) {
    pending.removeAll { $0 === urlSchemeTask }
    if active === urlSchemeTask {
      active = nil
      worker?.cancel()
      // The active worker starts the next request after its cancellation has completed.
    }
  }
  func cancelAll() {
    pending = []
    active = nil
    worker?.cancel()
    cache = [:]
  }
  private func next() {
    guard worker == nil, !pending.isEmpty else { return }
    let request = pending.removeFirst()
    active = request
    worker = Task { [weak self] in
      guard let self else { return }
      defer {
        self.active = nil
        self.worker = nil
        self.next()
      }
      do {
        guard let url = request.request.url, url.host == "inline", url.query == nil,
          url.fragment == nil, let id = Int(url.path.dropFirst())
        else { throw ClientError.invalidResponse }
        let data: Data
        if let saved = self.cache[id] {
          data = saved
        } else {
          guard !self.attempts.contains(id), self.attempts.count < InlineImagePolicy.maximumImages
          else {
            throw ClientError.rejected("内嵌图片超过自动加载限制，可通过附件查看。")
          }
          self.attempts.insert(id)
          data = try await self.load(id)
          try Task.checkCancellation()
          guard self.totalBytes + data.count <= InlineImagePolicy.maximumTotalBytes else {
            throw ClientError.rejected("内嵌图片超过自动加载限制，可通过附件查看。")
          }
          self.totalBytes += data.count
          self.cache[id] = data
        }
        try Task.checkCancellation()
        guard self.active === request else { return }
        request.didReceive(
          URLResponse(
            url: url, mimeType: "image/png", expectedContentLength: data.count,
            textEncodingName: nil))
        request.didReceive(data)
        request.didFinish()
      } catch {
        let cancelled =
          Task.isCancelled || error is CancellationError
          || (error as? URLError)?.code == .cancelled
        if cancelled, let path = request.request.url?.path, let id = Int(path.dropFirst()) {
          self.attempts.remove(id)
        }
        guard self.active === request else { return }
        request.didFailWithError(error)
        if !cancelled {
          self.reportError("部分内嵌图片未能加载，可刷新重试或从附件查看。")
        }
      }
    }
  }

  /// Decode a bounded thumbnail and re-encode as PNG; SVG, huge pixel canvases and animation
  /// are not handed through to the web view. The original is still available as an attachment.
  nonisolated static func rasterData(at url: URL) throws -> Data {
    guard let source = CGImageSourceCreateWithURL(url as CFURL, nil),
      let properties = CGImageSourceCopyPropertiesAtIndex(source, 0, nil) as? [CFString: Any],
      let width = properties[kCGImagePropertyPixelWidth] as? Int,
      let height = properties[kCGImagePropertyPixelHeight] as? Int,
      width > 0, height > 0, width <= 20000, height <= 20000,
      Int64(width) * Int64(height) <= 40_000_000,
      let image = CGImageSourceCreateThumbnailAtIndex(
        source, 0,
        [
          kCGImageSourceCreateThumbnailFromImageAlways: true,
          kCGImageSourceThumbnailMaxPixelSize: 2048,
          kCGImageSourceCreateThumbnailWithTransform: true,
        ] as CFDictionary),
      let data = UIImage(cgImage: image).pngData(),
      data.count <= Int(InlineImagePolicy.maximumBytes)
    else { throw ClientError.rejected("内嵌图片格式或尺寸不受支持。") }
    return data
  }
}
