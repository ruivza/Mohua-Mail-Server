import SwiftUI

struct MailboxSettingsView: View {
  @EnvironmentObject private var store: MailStore
  @Environment(\.dismiss) private var dismiss
  let account: Mailbox?
  @State private var email = ""
  @State private var imapHost = ""
  @State private var imapPort = "993"
  @State private var smtpHost = ""
  @State private var smtpPort = "465"
  @State private var credential = ""
  @State private var monitored = false
  @State private var busy = false
  @State private var message: String?
  @State private var confirmDelete = false

  var body: some View {
    Form {
      Section("邮箱连接") {
        TextField("邮箱地址", text: $email).keyboardType(.emailAddress)
          .accessibilityIdentifier("mailboxEmail")
        TextField("IMAP 主机", text: $imapHost).accessibilityIdentifier("imapHost")
        TextField("IMAP 端口", text: $imapPort).keyboardType(.numberPad)
        TextField("SMTP 主机", text: $smtpHost).accessibilityIdentifier("smtpHost")
        TextField("SMTP 端口", text: $smtpPort).keyboardType(.numberPad)
      }
      .textInputAutocapitalization(.never).autocorrectionDisabled()
      .disabled(account != nil || busy)
      Section {
        SecureField(account == nil ? "邮箱密码或应用专用密码" : "新的邮箱密码或应用专用密码", text: $credential)
          .accessibilityIdentifier("mailboxCredential")
        Button(account == nil ? "添加邮箱" : "更新密码") { save() }
          .disabled(
            busy || credential.isEmpty || email.isEmpty || imapHost.isEmpty || smtpHost.isEmpty
          )
          .accessibilityIdentifier("saveMailbox")
      } footer: {
        Text("邮箱配置属于你的用户账号，所有已登录设备均可访问。密码加密保存在服务器；删除配置不会删除邮箱服务商的邮件。")
      }
      if let account {
        Section("连接与监听") {
          Text("模式：\(account.mode == "proxy" ? "服务器代理" : "直连（客户端暂未支持）")")
          Button("测试 IMAP / SMTP 连接") {
            run {
              let result = try await store.manage(
                path: ["accounts", account.id, "verify"], method: "POST", values: [:])
              message = result.connectionStatus == "verified" ? "连接验证通过。" : "连接验证未通过，请检查邮箱配置。"
            }
          }.disabled(busy)
          Toggle("后台监听新邮件", isOn: $monitored).disabled(busy)
          Button("保存监听设置") {
            run {
              _ = try await store.manage(
                path: ["accounts", account.id, "monitor"], method: "POST",
                values: ["enabled": monitored])
              message = "监听设置已保存。"
              await store.refresh()
            }
          }.disabled(busy)
        }
        Section {
          Button("删除邮箱配置", role: .destructive) { confirmDelete = true }.disabled(busy)
        }
      }
      if busy { ProgressView() }
      if let message { Text(message).foregroundStyle(.secondary) }
    }
    .navigationTitle(account == nil ? "添加邮箱" : "邮箱设置")
    .toolbar { if account == nil { Button("取消") { dismiss() }.disabled(busy) } }
    .interactiveDismissDisabled(busy)
    .onAppear {
      guard let account else { return }
      email = account.email
      imapHost = account.imap_host ?? ""
      smtpHost = account.smtp_host ?? ""
      imapPort = String(account.imap_port ?? 993)
      smtpPort = String(account.smtp_port ?? 465)
      monitored = account.monitor_enabled == 1
    }
    .confirmationDialog(
      "从账号中删除此邮箱配置？所有设备都会失去访问权限。", isPresented: $confirmDelete, titleVisibility: .visible
    ) {
      Button("删除邮箱配置", role: .destructive) {
        guard let account else { return }
        run {
          _ = try await store.manage(path: ["accounts", account.id], method: "DELETE")
          await store.refresh()
          dismiss()
        }
      }
    }
  }

  private func save() {
    run {
      if let account {
        _ = try await store.manage(
          path: ["accounts", account.id], method: "PATCH", values: ["credential": credential])
        credential = ""
        message = "邮箱密码已更新。"
      } else {
        guard let imap = Int(imapPort), let smtp = Int(smtpPort),
          (1...65535).contains(imap), (1...65535).contains(smtp)
        else {
          message = "端口必须在 1–65535 之间。"
          return
        }
        _ = try await store.manage(
          path: ["accounts"], method: "POST",
          values: [
            "email": email, "mode": "proxy", "imapHost": imapHost, "imapPort": imap,
            "smtpHost": smtpHost, "smtpPort": smtp, "credential": credential,
          ])
        credential = ""
        await store.refresh()
        dismiss()
      }
    }
  }

  private func run(_ action: @escaping () async throws -> Void) {
    busy = true
    message = nil
    Task {
      defer { busy = false }
      do { try await action() } catch {
        message = error.localizedDescription
        store.handle(error)
      }
    }
  }
}
