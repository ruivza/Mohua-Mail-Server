import CryptoKit
import Foundation

/// Complete bodies only. Keys include server, installation, mailbox, folder, UIDVALIDITY and UID.
/// Cached content is protected while locked, excluded from backups, bounded and cleared on sign-out.
actor BodyCache {
  struct Record: Codable {
    let scope: String
    let identity: MessageIdentity
    let metadata: MessageMetadata
    let stored: Date
    let bytes: Int
    let preview: String
  }
  struct Snapshot {
    let metadata: MessageMetadata
    let body: URL
    let directory: URL
    let stored: Date
  }

  private let root: URL
  private let capacity: Int
  private let itemLimit: Int
  private let lifetime: TimeInterval
  private var generation = 0

  init(
    root: URL? = nil, capacity: Int = 50 * 1024 * 1024,
    itemLimit: Int = 5 * 1024 * 1024, lifetime: TimeInterval = 7 * 86400
  ) {
    self.root =
      root
      ?? FileManager.default.urls(for: .cachesDirectory, in: .userDomainMask)[0]
      .appendingPathComponent("MohuaBodies", isDirectory: true)
    self.capacity = capacity
    self.itemLimit = itemLimit
    self.lifetime = lifetime
  }

  private func digest(_ value: String) -> String {
    SHA256.hash(data: Data(value.utf8)).map { String(format: "%02x", $0) }.joined()
  }

  private func scope(_ session: DeviceSession) -> String {
    digest(session.server.absoluteString + "\n" + session.deviceId)
  }

  private func directory(_ identity: MessageIdentity, _ session: DeviceSession) -> URL {
    let key = [
      scope(session), identity.account, identity.folder, identity.uidValidity, String(identity.uid),
    ]
    // JSON encoding avoids delimiter collisions in folder names.
    let encoded = (try? JSONEncoder().encode(key)) ?? Data()
    return root.appendingPathComponent(digest(encoded.base64EncodedString()), isDirectory: true)
  }

  private func record(at directory: URL) -> Record? {
    guard let data = try? Data(contentsOf: directory.appendingPathComponent("record.json")),
      let record = try? JSONDecoder().decode(Record.self, from: data),
      Date().timeIntervalSince(record.stored) < lifetime
    else {
      try? FileManager.default.removeItem(at: directory)
      return nil
    }
    return record
  }

  func snapshot(_ identity: MessageIdentity, session: DeviceSession) throws -> Snapshot? {
    let directory = directory(identity, session)
    guard let record = record(at: directory), record.identity == identity,
      record.scope == scope(session)
    else { return nil }
    let working = try TransferFiles.createDirectory()
    do {
      let body = working.appendingPathComponent("body.txt")
      try FileManager.default.copyItem(at: directory.appendingPathComponent("body.txt"), to: body)
      try FileManager.default.setAttributes(
        [.protectionKey: FileProtectionType.complete], ofItemAtPath: body.path)
      try? FileManager.default.setAttributes(
        [.modificationDate: Date()], ofItemAtPath: directory.path)
      return Snapshot(
        metadata: record.metadata, body: body, directory: working, stored: record.stored)
    } catch {
      try? FileManager.default.removeItem(at: working)
      throw error
    }
  }

  func contains(_ identity: MessageIdentity, session: DeviceSession) -> Bool {
    record(at: directory(identity, session)) != nil
  }

  func preview(_ identity: MessageIdentity, session: DeviceSession) -> String? {
    record(at: directory(identity, session))?.preview
  }

  // The ticket prevents a late download from restoring content after a purge.
  func ticket() -> Int { generation }

  func save(
    _ identity: MessageIdentity, session: DeviceSession, metadata: MessageMetadata,
    body: URL, ticket: Int
  ) throws {
    guard ticket == generation else { return }
    guard metadata.uid == identity.uid, metadata.uidValidity == identity.uidValidity else {
      throw ClientError.invalidResponse
    }
    let bytes = try body.resourceValues(forKeys: [.fileSizeKey]).fileSize ?? 0
    guard bytes <= itemLimit, bytes <= capacity else { return }
    try FileManager.default.createDirectory(
      at: root, withIntermediateDirectories: true,
      attributes: [.protectionKey: FileProtectionType.complete])
    var excluded = root
    var values = URLResourceValues()
    values.isExcludedFromBackup = true
    try excluded.setResourceValues(values)
    let staging = root.appendingPathComponent(UUID().uuidString, isDirectory: true)
    try FileManager.default.createDirectory(
      at: staging, withIntermediateDirectories: true,
      attributes: [.protectionKey: FileProtectionType.complete])
    defer { try? FileManager.default.removeItem(at: staging) }
    let storedBody = staging.appendingPathComponent("body.txt")
    try FileManager.default.copyItem(at: body, to: storedBody)
    try FileManager.default.setAttributes(
      [.protectionKey: FileProtectionType.complete], ofItemAtPath: storedBody.path)
    let text = try BodyPager(url: storedBody).text(at: 0)
    let preview =
      metadata.body?.contentType == "text/plain"
      ? String(text.split(whereSeparator: \.isWhitespace).joined(separator: " ").prefix(140))
      : "HTML 邮件"
    let record = Record(
      scope: scope(session), identity: identity, metadata: metadata,
      stored: Date(), bytes: bytes, preview: preview)
    let encoded = try JSONEncoder().encode(record)
    guard encoded.count <= 512 * 1024 else { return }
    try encoded.write(
      to: staging.appendingPathComponent("record.json"),
      options: [.atomic, .completeFileProtection])
    let destination = directory(identity, session)
    try? FileManager.default.removeItem(at: destination)
    try FileManager.default.moveItem(at: staging, to: destination)
    trim()
  }

  func remove(_ identity: MessageIdentity, session: DeviceSession) {
    generation += 1
    try? FileManager.default.removeItem(at: directory(identity, session))
  }

  /// A nil validity removes the entire folder. Otherwise retain the current UID epoch
  /// and remove only UIDs that were explicitly checked and found missing.
  func reconcile(
    account: String, folder: String, session: DeviceSession,
    validity: String? = nil, removed: Set<Int> = []
  ) {
    generation += 1
    let owner = scope(session)
    for directory in entries() {
      guard let record = record(at: directory), record.scope == owner,
        record.identity.account == account, record.identity.folder == folder
      else { continue }
      if validity == nil || record.identity.uidValidity != validity
        || removed.contains(record.identity.uid)
      {
        try? FileManager.default.removeItem(at: directory)
      }
    }
  }

  func retainAccounts(_ accounts: Set<String>, session: DeviceSession) {
    generation += 1
    let owner = scope(session)
    for directory in entries() {
      guard let record = record(at: directory) else { continue }
      if record.scope != owner || !accounts.contains(record.identity.account) {
        generation += 1
        try? FileManager.default.removeItem(at: directory)
      }
    }
  }

  func clear() {
    generation += 1
    try? FileManager.default.removeItem(at: root)
  }

  private func entries() -> [URL] {
    (try? FileManager.default.contentsOfDirectory(
      at: root, includingPropertiesForKeys: [.contentModificationDateKey])) ?? []
  }

  private func trim() {
    let ordered = entries().sorted {
      let first =
        (try? $0.resourceValues(forKeys: [.contentModificationDateKey]).contentModificationDate)
        ?? .distantPast
      let second =
        (try? $1.resourceValues(forKeys: [.contentModificationDateKey]).contentModificationDate)
        ?? .distantPast
      return first > second
    }
    var total = 0
    for (index, directory) in ordered.enumerated() {
      guard let record = record(at: directory) else { continue }
      total += record.bytes
      if total > capacity || index >= 200 { try? FileManager.default.removeItem(at: directory) }
    }
  }
}
