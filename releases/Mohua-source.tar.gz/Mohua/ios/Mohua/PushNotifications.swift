import SwiftUI
import UIKit

@MainActor
final class PushAppDelegate: NSObject, UIApplicationDelegate {
  let store = MailStore()
  private let background = BackgroundRun<UIBackgroundFetchResult>()

  func application(
    _ application: UIApplication, didRegisterForRemoteNotificationsWithDeviceToken token: Data
  ) {
    store.pushToken = token.map { String(format: "%02x", $0) }.joined()
    Task { await store.registerPushToken() }
  }
  func application(
    _ application: UIApplication, didFailToRegisterForRemoteNotificationsWithError error: Error
  ) {
    if store.notificationsEnabled { store.pushStatus = "设备推送登记失败，回到前台时会重试" }
  }
  func applicationDidBecomeActive(_ application: UIApplication) {
    background.cancel(result: .noData)
  }
  func application(
    _ application: UIApplication, didReceiveRemoteNotification payload: [AnyHashable: Any],
    fetchCompletionHandler completion: @escaping (UIBackgroundFetchResult) -> Void
  ) {
    guard application.isProtectedDataAvailable, store.notificationsEnabled else {
      completion(.noData)
      return
    }
    if let challenge = payload["mohuaRegistration"] as? [String: String] {
      let started = background.start(
        timeoutResult: .failed,
        operation: { [store] in
          await store.confirmPush(challenge)
        }, completion: completion)
      if !started { completion(.noData) }
      return
    }
    guard MailPush.accepts(payload, device: store.session?.deviceId) else {
      completion(.noData)
      return
    }
    if application.applicationState == .active {
      for account in store.accounts { store.mailboxChanged(account.id) }
      completion(.noData)
      return
    }
    let started = background.start(
      timeoutResult: .failed, operation: { [store] in await store.refreshInboxes() },
      completion: completion)
    if !started { completion(.noData) }
  }
}

struct GatewayConfig: Decodable {
  let mode: String
  let gatewayUrl: URL?
  let revision: String
  let serverId: String
  let `protocol`: Int
  let pushStatus: String
}
struct GatewayGrant: Codable {
  let registrationId: String
  let credential: String
  let revokeToken: String
  let expiresAt: Double
}
struct SavedPush: Codable {
  var appId: String? = nil
  let gateway: URL
  let revision: String
  let serverId: String
  let deviceId: String
  let token: String
  let grant: GatewayGrant
}
struct PendingPush {
  let config: GatewayConfig
  let gateway: URL
  let session: DeviceSession
  let token: String
  let nonce: String
  let generation: UUID
}
private struct GatewayPending: Decodable { let registrationId: String }
private struct GatewayRevoked: Decodable { let revoked: Bool }

extension MailStore {
  private var preferenceKey: String? {
    session.map { "Mohua.notifications." + $0.server.absoluteString + "." + $0.deviceId }
  }
  func restorePushPreference() {
    notificationsEnabled =
      preferenceKey.flatMap { UserDefaults.standard.object(forKey: $0) as? Bool } ?? true
  }
  func setNotificationsEnabled(_ enabled: Bool) {
    notificationsEnabled = enabled
    if let preferenceKey { UserDefaults.standard.set(enabled, forKey: preferenceKey) }
    pushGeneration = UUID()
    pendingPush = nil
    if !enabled {
      UIApplication.shared.unregisterForRemoteNotifications()
      retirePush()
      pushStatus = "本设备通知已关闭"
    }
    registerForPush()
  }
  func retirePush() {
    do { try PushVault.retire() } catch { pushStatus = "无法更新安全存储，请解锁后重试" }
    Task { await revokeRetiredPush() }
  }
  private func revokeRetiredPush() async {
    guard let retired = try? PushVault.load().retired else { return }
    for entry in retired {
      do {
        _ = try await api.request(
          GatewayRevoked.self, server: entry.gateway,
          path: ["v1", "registrations", entry.grant.registrationId], token: entry.grant.revokeToken,
          method: "DELETE")
        try PushVault.removeRetired(entry.grant.registrationId)
      } catch { /* Retain the revocation credential securely for the next foreground retry. */  }
    }
  }
  func registerForPush() {
    Task { await registerPushToken() }
  }
  private func isCurrent(_ generation: UUID, _ current: DeviceSession) -> Bool {
    generation == pushGeneration && session?.token == current.token
  }
  func registerPushToken() async {
    guard let current = session, !registeringPush else { return }
    let generation = pushGeneration
    registeringPush = true
    defer {
      registeringPush = false
      if generation != pushGeneration, session != nil { registerForPush() }
    }
    await revokeRetiredPush()
    do {
      let enabled = notificationsEnabled
      _ = try await api.request(
        PushState.self, server: current.server,
        path: ["api", "client", "push"], token: current.token,
        body: JSONEncoder().encode(["enabled": enabled]))
      guard isCurrent(generation, current) else { return }
      if !enabled {
        pushStatus = "本设备通知已关闭"
        return
      }
      let config = try await api.request(
        GatewayConfig.self, server: current.server,
        path: ["api", "client", "push", "config"], token: current.token)
      guard isCurrent(generation, current) else { return }
      guard config.protocol == 1, let gateway = config.gatewayUrl else {
        retirePush()
        pushStatus = MailPush.description(config.pushStatus)
        return
      }
      // A server cannot redirect this app's APNs token to an arbitrary third party.
      guard let trusted = Bundle.main.object(forInfoDictionaryKey: "MohuaGatewayURL") as? String,
        MailPush.trusts(gateway, configured: trusted)
      else {
        retirePush()
        pushStatus = "此网关需要配置了相同网关地址的配套客户端"
        return
      }
      if MailPush.isSimulator {
        pushStatus = "模拟器使用手动同步；真实推送需真机验证"
        return
      }
      UIApplication.shared.registerForRemoteNotifications()
      guard let pushToken,
        let environment = Bundle.main.object(forInfoDictionaryKey: "MohuaPushEnvironment")
          as? String,
        ["sandbox", "production"].contains(environment)
      else { return }
      if let saved = try PushVault.load().current,
        (saved.appId ?? "mohua") == MailPush.appID,
        saved.gateway == gateway, saved.revision == config.revision,
        saved.deviceId == current.deviceId, saved.serverId == config.serverId,
        saved.token == pushToken,
        saved.grant.expiresAt > Date().timeIntervalSince1970 * 1000 + 86_400_000,
        config.pushStatus != "not_registered" || registeredPush == nil
      {
        do {
          try await uploadPush(saved, session: current)
          guard isCurrent(generation, current) else { return }
          registeredPush = saved.grant.registrationId
          pushStatus = "后台更新已登记"
          return
        } catch {
          guard isCurrent(generation, current) else { return }
          try PushVault.retire()
        }
      }
      if let pendingPush, pendingPush.generation == generation,
        pendingPush.config.revision == config.revision, pendingPush.token == pushToken,
        Date().timeIntervalSince(pendingPushStarted) < 300
      {
        pushStatus = "等待设备推送校验"
        return
      }
      try PushVault.retire()
      let nonce = UUID().uuidString + UUID().uuidString
      pendingPush = PendingPush(
        config: config, gateway: gateway, session: current,
        token: pushToken, nonce: nonce, generation: generation)
      pendingPushStarted = Date()
      _ = try await api.request(
        GatewayPending.self, server: gateway, path: ["v1", "registrations"],
        body: JSONEncoder().encode([
          "appId": MailPush.appID, "platform": "ios", "channel": "apns",
          "deviceId": current.deviceId, "serverId": config.serverId,
          "deviceToken": pushToken, "environment": environment, "nonce": nonce,
        ]))
      guard isCurrent(generation, current) else { return }
      if pendingPush != nil { pushStatus = "等待设备推送校验；系统可能延迟送达" }
    } catch {
      guard isCurrent(generation, current) else { return }
      pushStatus = "推送登记未完成，回到前台时会重试"
      pendingPush = nil
    }
  }
  private func uploadPush(_ saved: SavedPush, session: DeviceSession) async throws {
    _ = try await api.request(
      PushState.self, server: session.server,
      path: ["api", "client", "push"], token: session.token,
      body: JSONSerialization.data(withJSONObject: [
        "enabled": true,
        "credential": saved.grant.credential, "revision": saved.revision,
      ]))
  }
  func confirmPush(_ payload: [String: String]) async -> UIBackgroundFetchResult {
    guard let pending = pendingPush, notificationsEnabled,
      isCurrent(pending.generation, pending.session),
      (payload["appId"] ?? "mohua") == MailPush.appID,
      payload["nonce"] == pending.nonce, payload["deviceId"] == pending.session.deviceId,
      payload["serverId"] == pending.config.serverId,
      let id = payload["id"], let challenge = payload["challenge"]
    else { return .noData }
    do {
      let grant = try await api.request(
        GatewayGrant.self, server: pending.gateway,
        path: ["v1", "registrations", id, "confirm"],
        body: JSONEncoder().encode([
          "challenge": challenge, "nonce": pending.nonce, "appId": MailPush.appID,
        ]))
      let saved = SavedPush(
        appId: MailPush.appID, gateway: pending.gateway, revision: pending.config.revision,
        serverId: pending.config.serverId, deviceId: pending.session.deviceId, token: pending.token,
        grant: grant)
      guard notificationsEnabled, isCurrent(pending.generation, pending.session), !Task.isCancelled
      else {
        try PushVault.addRetired(saved)
        await revokeRetiredPush()
        return .noData
      }
      try PushVault.saveCurrent(saved)
      try await uploadPush(saved, session: pending.session)
      guard notificationsEnabled, isCurrent(pending.generation, pending.session) else {
        registerForPush()
        return .noData
      }
      registeredPush = grant.registrationId
      pendingPush = nil
      pushStatus = "后台更新已登记"
      return .noData
    } catch {
      if isCurrent(pending.generation, pending.session) { pushStatus = "设备校验未完成，回到前台时会重试" }
      return .failed
    }
  }

  /// Bounded to three inboxes, with a rotating start for users who have more mailboxes.
  /// Background work only updates headers and flags; it never downloads bodies or acknowledges
  /// an entire account revision after synchronizing a partial inbox.
  func refreshInboxes() async -> UIBackgroundFetchResult {
    guard !refreshingInboxes, UIApplication.shared.isProtectedDataAvailable,
      let current = session
    else { return .noData }
    refreshingInboxes = true
    defer { refreshingInboxes = false }
    await refresh()
    guard !Task.isCancelled, session?.token == current.token else { return .failed }
    let mailboxes = accounts.filter { $0.mode == "proxy" }.sorted { $0.id < $1.id }
    guard !mailboxes.isEmpty else { return .noData }
    let start = index.inboxOffset % mailboxes.count
    var succeeded = false
    var changed = false
    for offset in 0..<min(3, mailboxes.count) {
      guard !Task.isCancelled, UIApplication.shared.isProtectedDataAvailable,
        session?.token == current.token
      else { break }
      let account = mailboxes[(start + offset) % mailboxes.count]
      let previous = index.snapshot(account: account.id, folder: "INBOX")
      let model = MailListModel()
      await model.load(
        accounts: [account], folder: "INBOX", reset: true, store: self, prefetch: false)
      guard !Task.isCancelled, session?.token == current.token else { break }
      if model.error == nil, let fresh = index.snapshot(account: account.id, folder: "INBOX") {
        succeeded = true
        if previous?.uidValidity != fresh.uidValidity || previous?.items != fresh.items {
          changed = true
        }
      }
      try? index.advanceInboxes(to: (start + offset + 1) % mailboxes.count)
    }
    if Task.isCancelled || session?.token != current.token { return .failed }
    return changed ? .newData : succeeded ? .noData : .failed
  }
}
