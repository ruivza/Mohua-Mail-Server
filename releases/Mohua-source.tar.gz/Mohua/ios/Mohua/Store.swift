import SwiftUI

@MainActor
final class MailStore: ObservableObject {
  @Published private(set) var session: DeviceSession?
  @Published private(set) var accounts: [Mailbox] = []
  @Published var notice: String?
  @Published private(set) var mailboxVersions: [String: Int] = [:]
  let api = MailAPI()
  let cache = BodyCache()
  let drafts = DraftStore()
  let index = MailIndex()
  @Published private(set) var previews: [MessageIdentity: String] = [:]
  private var prefetchTask: Task<Void, Never>?

  @Published var pushStatus = "设备尚未登记推送"
  @Published var refreshingInboxes = false
  @Published var notificationsEnabled = true
  var pushGeneration = UUID()
  var pendingPush: PendingPush?
  var pendingPushStarted = Date.distantPast
  var pushToken: String?
  var registeredPush: String?
  var registeringPush = false
  private var refreshVersion = 0
  init() {
    TransferFiles.clearAll()
    restoreSession()
  }
  func restoreSession() {
    guard session == nil else { return }
    do {
      if let saved = try SessionKeychain.load() {
        _ = try MailAPI.serverURL(saved.server.absoluteString)
        guard saved.expires > Date().timeIntervalSince1970 * 1000 else {
          try SessionKeychain.clear()
          notice = ClientError.expired.localizedDescription
          Task { await cache.clear() }
          drafts.clear()
          index.clear()
          return
        }
        session = saved
        restorePushPreference()
        drafts.activate(saved)
        index.activate(saved)
        accounts = index.accounts
      }
    } catch { notice = error.localizedDescription }
  }
  func login(server: String, email: String, password: String, deviceName: String) async throws {
    let url = try MailAPI.serverURL(server)
    let previous = try SessionKeychain.deviceID(server: url, email: email)
    let value = try await api.login(
      server: url, email: email, password: password,
      deviceName: deviceName, deviceId: previous)
    do {
      try SessionKeychain.rememberDevice(value, email: email)
      try SessionKeychain.save(value)
    } catch {
      // Do not leave a usable server session behind if secure storage fails.
      _ = try? await api.request(
        OperationResult.self, server: url, path: ["api", "logout"],
        token: value.token, body: Data("{}".utf8))
      throw error
    }
    session = value
    restorePushPreference()
    drafts.activate(value)
    index.activate(value)
    accounts = index.accounts
    notice = nil
  }

  func register(server: String, email: String, password: String, invite: String) async throws {
    let data = try JSONEncoder().encode(["email": email, "password": password, "invite": invite])
    _ = try await api.request(
      OperationResult.self, server: MailAPI.serverURL(server),
      path: ["api", "register"], body: data)
  }

  func logout() async throws {
    guard let current = session else { return }
    do {
      _ = try await api.request(
        OperationResult.self, server: current.server,
        path: ["api", "logout"], token: current.token, body: Data("{}".utf8))
    } catch ClientError.expired {
      // A revoked or expired session is already signed out on the server.
    }
    guard session?.token == current.token else { return }
    disconnect()
  }

  func manage(path: [String], method: String, values: [String: Any]? = nil) async throws
    -> OperationResult
  {
    guard let current = session else { throw ClientError.expired }
    let data = try values.map { try JSONSerialization.data(withJSONObject: $0) }
    return try await api.request(
      OperationResult.self, server: current.server,
      path: ["api"] + path, token: current.token, body: data, method: method)
  }

  func disconnect() {
    pushGeneration = UUID()
    pendingPush = nil
    retirePush()
    drafts.clear()
    index.clear()
    registeredPush = nil
    pushStatus = "设备尚未登记推送"
    cancelPrefetch()
    previews = [:]
    Task { await cache.clear() }
    refreshVersion += 1
    session = nil
    accounts = []
    TransferFiles.clearAll()
    do {
      try SessionKeychain.clear()
      notice = nil
    } catch { notice = error.localizedDescription }
  }
  func cancelPrefetch() {
    prefetchTask?.cancel()
    prefetchTask = nil
  }

  /// Only a few small recent messages. Navigation cancels this work before foreground reading.
  func prefetch(_ candidates: [(identity: MessageIdentity, size: Int?)]) {
    cancelPrefetch()
    guard let current = session else { return }
    prefetchTask = Task {
      for candidate in candidates {
        guard !Task.isCancelled, session?.token == current.token else { return }
        if let preview = await cache.preview(candidate.identity, session: current) {
          guard !Task.isCancelled, session?.token == current.token else { return }
          previews[candidate.identity] = preview
        }
      }
      let recent = candidates.filter { ($0.size ?? Int.max) <= 128 * 1024 }.prefix(3)
      for candidate in recent {
        guard !Task.isCancelled, session?.token == current.token else { return }
        let identity = candidate.identity
        if await cache.contains(identity, session: current) { continue }
        var directory: URL?
        do {
          let ticket = await cache.ticket()
          let metadata = try await api.request(
            MessageMetadata.self, server: current.server,
            path: identity.path, token: current.token, query: identity.query)
          guard metadata.body != nil else { continue }
          try Task.checkCancellation()
          let working = try TransferFiles.createDirectory()
          directory = working
          let body = working.appendingPathComponent("body.txt")
          let request = try api.makeRequest(
            server: current.server, path: identity.path + ["body"],
            token: current.token, query: identity.query)
          let worker = Task.detached {
            try await TransferFiles.receive(request, at: body, maximumBytes: 128 * 1024) { _ in }
          }
          try await withTaskCancellationHandler {
            try await worker.value
          } onCancel: {
            worker.cancel()
          }
          _ = try await api.request(
            OperationResult.self, server: current.server,
            path: ["api", "accounts", identity.account, "access"], token: current.token)
          try Task.checkCancellation()
          guard session?.token == current.token else { throw CancellationError() }
          try await cache.save(
            identity, session: current, metadata: metadata, body: body, ticket: ticket)
          let preview = await cache.preview(identity, session: current)
          try Task.checkCancellation()
          guard session?.token == current.token else { throw CancellationError() }
          previews[identity] = preview
        } catch ClientError.expired {
          if session?.token == current.token { handle(ClientError.expired) }
        } catch {
          // Opportunistic work must not replace foreground errors or retry a failed request.
        }
        if let directory { try? FileManager.default.removeItem(at: directory) }
      }
    }
  }

  func discardAccount(_ account: String) {
    index.removeAccount(account)
    accounts.removeAll { $0.id == account }
    previews = previews.filter { $0.key.account != account }
    if let current = session {
      let retained = Set(accounts.filter { $0.mode == "proxy" }.map(\.id))
      Task { await cache.retainAccounts(retained, session: current) }
    }
  }

  func removePreviews(
    account: String, folder: String, validity: String? = nil, removed: Set<Int> = []
  ) {
    previews = previews.filter { identity, _ in
      identity.account != account || identity.folder != folder
        || (validity != nil && identity.uidValidity == validity && !removed.contains(identity.uid))
    }
  }

  func mailboxChanged(_ account: String) { mailboxVersions[account, default: 0] += 1 }
  func handle(_ error: Error) {
    if error is CancellationError || (error as? URLError)?.code == .cancelled { return }
    if case ClientError.expired = error {
      disconnect()
    }
    notice = error.localizedDescription
  }
  func refresh() async {
    guard let current = session else { return }
    refreshVersion += 1
    let version = refreshVersion
    guard current.expires > Date().timeIntervalSince1970 * 1000 else {
      handle(ClientError.expired)
      return
    }
    do {
      let values = try await api.request(
        [Mailbox].self, server: current.server, path: ["api", "accounts"], token: current.token)
      guard version == refreshVersion, session?.token == current.token else { return }
      try index.saveAccounts(values)
      accounts = values
      let owned = Set(values.filter { $0.mode == "proxy" }.map(\.id))
      previews = previews.filter { owned.contains($0.key.account) }
      await cache.retainAccounts(owned, session: current)
      notice = nil
    } catch {
      guard version == refreshVersion, session?.token == current.token else { return }
      if error is CancellationError || (error as? URLError)?.code == .cancelled { return }
      if case ClientError.forbidden = error {
        try? index.saveAccounts([])
        accounts = []
        previews = [:]
        await cache.clear()
      }
      handle(error)
    }
  }
}
