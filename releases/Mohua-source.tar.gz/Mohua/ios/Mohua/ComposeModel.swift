import SwiftUI

@MainActor
final class ComposeModel: ObservableObject {
  @Published var draft: MailDraft
  @Published private(set) var busy = false
  @Published var error: String?
  @Published private(set) var saved = false
  private var session: DeviceSession?
  private var autosave: Task<Void, Never>?
  private var discarded = false

  init(draft: MailDraft) { self.draft = draft }
  func attach(_ store: MailStore) {
    guard session == nil else { return }
    session = store.session
    _ = save(store)
  }
  private func current(_ store: MailStore) throws -> DeviceSession {
    guard !discarded, let session, store.session?.token == session.token else {
      throw ClientError.expired
    }
    return session
  }
  @discardableResult
  func save(_ store: MailStore) -> Bool {
    autosave?.cancel()
    do {
      try store.drafts.save(draft, session: current(store))
      saved = true
      return true
    } catch {
      self.error = error.localizedDescription
      saved = false
      return false
    }
  }
  func queueSave(_ store: MailStore) {
    saved = false
    autosave?.cancel()
    autosave = Task { [weak self] in
      do { try await Task.sleep(for: .milliseconds(400)) } catch { return }
      guard let self, !Task.isCancelled else { return }
      self.save(store)
    }
  }
  func discard(_ store: MailStore) -> Bool {
    do {
      let session = try current(store)
      autosave?.cancel()
      try store.drafts.remove(draft, session: session)
      discarded = true
      return true
    } catch {
      self.error = error.localizedDescription
      return false
    }
  }

  func addFiles(_ urls: [URL], store: MailStore) async {
    guard !busy, draft.editable else { return }
    busy = true
    error = nil
    defer { busy = false }
    do {
      let session = try current(store)
      for url in urls {
        guard draft.attachments.count < 20 else { throw ClientError.rejected("最多添加 20 个附件。") }
        let granted = url.startAccessingSecurityScopedResource()
        defer { if granted { url.stopAccessingSecurityScopedResource() } }
        guard try url.resourceValues(forKeys: [.isRegularFileKey]).isRegularFile == true else {
          throw ClientError.rejected("请选择普通文件，不支持文件夹。")
        }
        let directory = try TransferFiles.createDirectory()
        defer { try? FileManager.default.removeItem(at: directory) }
        let staged = directory.appendingPathComponent("attachment")
        let remaining = 25 * 1024 * 1024 - draft.attachments.reduce(Int64(0)) { $0 + $1.size }
        let size = try await Task.detached {
          try DraftStore.copyFile(url, to: staged, maximum: remaining)
        }.value
        _ = try current(store)
        let attachment = DraftAttachment(
          filename: TransferFiles.safeFilename(url.lastPathComponent), size: size)
        try store.drafts.keepAttachment(
          staged, attachment: attachment, draft: draft, session: session)
        draft.attachments.append(attachment)
        guard save(store) else { return }
      }
    } catch { self.error = error.localizedDescription }
  }
  func removeFile(_ attachment: DraftAttachment, store: MailStore) {
    guard draft.editable, !busy else { return }
    do {
      let session = try current(store)
      // Save the changed manifest first; a failed disk write must not leave a dangling entry.
      var changed = draft
      changed.attachments.removeAll { $0.id == attachment.id }
      try store.drafts.save(changed, session: session)
      try? store.drafts.removeAttachment(attachment, draft: draft, session: session)
      draft = changed
    } catch { self.error = error.localizedDescription }
  }

  func send(_ store: MailStore) async {
    guard !busy else { return }
    busy = true
    error = nil
    defer { busy = false }
    do {
      let session = try current(store)
      guard store.accounts.contains(where: { $0.id == draft.accountID && $0.mode == "proxy" })
      else {
        throw ClientError.rejected("发件邮箱已不可用，请检查邮箱配置。")
      }
      let payload = try JSONEncoder().encode(draft.payload())
      guard payload.count <= 390000 else { throw ClientError.rejected("正文编码后过大，请缩短正文后发送。") }
      if draft.attempt == nil {
        draft.attempt = SendAttempt()
        // Persist the key before even preparing a request. A crash can recover the same operation.
        guard save(store) else { return }
        let result = try await prepare(store, session: session)
        try record(result, store: store)
      } else {
        let result = try await fetchStatus(store, session: session)
        try record(result, store: store)
      }
      guard draft.attempt?.status?.state == "prepared", let id = draft.attempt?.status?.id else {
        return
      }
      let directory = try TransferFiles.createDirectory()
      defer { try? FileManager.default.removeItem(at: directory) }
      let file = try await store.drafts.uploadFile(draft, session: session, directory: directory)
      _ = try current(store)
      draft.attempt?.uploadStarted = true
      guard save(store) else { return }
      let result = try await store.api.uploadMail(session: session, id: id, file: file)
      try record(result, store: store)
      store.mailboxChanged(draft.accountID)
    } catch {
      guard (try? current(store)) != nil else { return }
      self.error =
        draft.attempt == nil
        ? error.localizedDescription
        : "请求未完成。请查询发送状态；不会自动重发。\n" + error.localizedDescription
      store.handle(error)
    }
  }

  func refreshStatus(_ store: MailStore) async {
    guard !busy, draft.attempt != nil else { return }
    busy = true
    error = nil
    defer { busy = false }
    do {
      let result = try await fetchStatus(store, session: current(store))
      try record(result, store: store)
    } catch {
      guard (try? current(store)) != nil else { return }
      self.error = "暂时无法查询，已保留原发送记录。" + error.localizedDescription
      store.handle(error)
    }
  }
  private func prepare(_ store: MailStore, session: DeviceSession) async throws -> SendStatus {
    guard let attempt = draft.attempt else { throw ClientError.invalidResponse }
    return try await store.api.request(
      SendStatus.self, server: session.server,
      path: ["api", "accounts", draft.accountID, "outbox"], token: session.token,
      body: JSONEncoder().encode(draft.payload()), headers: ["Idempotency-Key": attempt.key])
  }
  private func fetchStatus(_ store: MailStore, session: DeviceSession) async throws -> SendStatus {
    if let id = draft.attempt?.status?.id {
      return try await store.api.request(
        SendStatus.self, server: session.server,
        path: ["api", "outbox", id], token: session.token)
    }
    // An interrupted preparation is recovered with the original key and frozen payload.
    return try await prepare(store, session: session)
  }
  private func record(_ status: SendStatus, store: MailStore) throws {
    _ = try current(store)
    draft.attempt?.status = status
    guard save(store) else { throw ClientError.rejected("发送记录保存失败，请保留此页面并查询状态。") }
  }
  func resumeEditing(_ store: MailStore) {
    guard let state = draft.attempt?.status?.state, ["failed", "expired"].contains(state), !busy
    else { return }
    draft.attempt = nil
    error = nil
    save(store)
  }
}
