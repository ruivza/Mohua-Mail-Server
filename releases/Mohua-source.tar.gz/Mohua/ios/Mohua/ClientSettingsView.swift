import SwiftUI

struct ClientSettingsView: View {
  @EnvironmentObject private var store: MailStore
  @State private var syncResult: String?
  @State private var devices: [ClientDevice] = []
  @State private var busy = false
  @State private var error: String?
  @State private var revoking: ClientDevice?
  @State private var renaming: ClientDevice?
  @State private var name = ""
  @State private var confirmLogout = false
  @State private var confirmLocalClear = false

  var body: some View {
    List {
      Section("邮箱管理") {
        ForEach(store.accounts) { account in
          NavigationLink(account.email) { MailboxSettingsView(account: account) }
        }
        NavigationLink("添加邮箱") { MailboxSettingsView(account: nil) }
      }
      Section {
        Toggle(
          "允许本设备通知",
          isOn: Binding(
            get: { store.notificationsEnabled }, set: { store.setNotificationsEnabled($0) }
          )
        ).accessibilityIdentifier("deviceNotifications")
        Text(store.pushStatus).font(.subheadline).foregroundStyle(.secondary)
        Button("检查推送登记") { store.registerForPush() }
        Button("同步收件箱") {
          Task {
            let result = await store.refreshInboxes()
            syncResult = result == .failed ? "同步未完成，请稍后重试。" : "本轮收件箱同步完成。"
          }
        }.disabled(store.refreshingInboxes).accessibilityIdentifier("syncInboxes")
        if store.refreshingInboxes { ProgressView() }
        if let syncResult { Text(syncResult).font(.footnote) }
      } header: {
        Text("后台更新")
      } footer: {
        Text("开启邮箱监听后，服务器会发送更新提示。系统可能延迟后台更新；锁定时保持本机数据保护，解锁后可刷新。每轮最多同步三个收件箱，不预取正文。")
      }
      Section("登录设备") {
        ForEach(devices) { device in
          VStack(alignment: .leading, spacing: 8) {
            Text(device.name).font(.headline)
            Text(
              device.id == store.session?.deviceId ? "当前设备" : device.sessionActive ? "已登录" : "登录已到期"
            )
            .font(.caption).foregroundStyle(.secondary)
            HStack {
              Button("重命名") {
                name = device.name
                renaming = device
              }
              Spacer()
              Button("撤销", role: .destructive) { revoking = device }
            }.buttonStyle(.borderless).disabled(busy)
          }
        }
      }
      Section {
        Button("退出登录", role: .destructive) { confirmLogout = true }.disabled(busy)
        Button("仅清除本机登录") { confirmLocalClear = true }.disabled(busy)
      } footer: {
        Text("退出登录会撤销当前设备会话。其他设备仍可使用你的邮箱。")
      }
      if let error { Text(error).foregroundStyle(.red) }
    }
    .navigationTitle("账号管理")
    .task { await loadDevices() }
    .refreshable {
      await store.refresh()
      await loadDevices()
    }
    .alert(
      "设备名称", isPresented: Binding(get: { renaming != nil }, set: { if !$0 { renaming = nil } })
    ) {
      TextField("名称", text: $name)
      Button("取消", role: .cancel) { renaming = nil }
      Button("保存") {
        guard let device = renaming else { return }
        run {
          _ = try await store.manage(
            path: ["client-devices", device.id], method: "PATCH", values: ["name": name])
          await loadDevices()
        }
      }
    }
    .confirmationDialog(
      "撤销这台设备的登录？",
      isPresented: Binding(get: { revoking != nil }, set: { if !$0 { revoking = nil } }),
      titleVisibility: .visible
    ) {
      if let device = revoking {
        Button("撤销设备", role: .destructive) {
          run {
            _ = try await store.manage(path: ["client-devices", device.id], method: "DELETE")
            if device.id == store.session?.deviceId {
              store.disconnect()
            } else {
              await loadDevices()
            }
          }
        }
      }
    }
    .confirmationDialog(
      "仅清除本机登录？服务器会话不会撤销，可稍后从其他设备撤销。", isPresented: $confirmLocalClear, titleVisibility: .visible
    ) {
      Button("清除本机登录", role: .destructive) { store.disconnect() }
    }
    .confirmationDialog("退出当前设备？", isPresented: $confirmLogout, titleVisibility: .visible) {
      Button("退出登录", role: .destructive) { run { try await store.logout() } }
    }
  }

  private func loadDevices() async {
    guard let session = store.session else { return }
    do {
      let result = try await store.api.request(
        [ClientDevice].self, server: session.server,
        path: ["api", "client-devices"], token: session.token)
      guard store.session?.token == session.token else { return }
      devices = result
    } catch {
      self.error = error.localizedDescription
      store.handle(error)
    }
  }

  private func run(_ action: @escaping () async throws -> Void) {
    busy = true
    error = nil
    Task {
      defer { busy = false }
      do { try await action() } catch {
        self.error = error.localizedDescription
        store.handle(error)
      }
    }
  }
}
