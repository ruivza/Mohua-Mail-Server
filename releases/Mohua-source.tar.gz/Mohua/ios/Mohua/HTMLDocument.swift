import Foundation

/// Parse inertly with the system HTML parser, then emit only presentation markup.
/// Original markup is never handed to WebKit. CSP and disabled JavaScript add independent barriers.
struct HTMLDocument: Equatable, Sendable {
  static let maximumBytes = 2 * 1024 * 1024
  let markup: String
  let hasRemoteImages: Bool
  let inlineIDs: Set<Int>

  func plainText() -> String {
    let document = markup.withCString {
      htmlReadMemory(
        $0, Int32(markup.utf8.count), nil, "UTF-8",
        Int32(
          HTML_PARSE_NONET.rawValue | HTML_PARSE_NOERROR.rawValue | HTML_PARSE_NOWARNING.rawValue))
    }
    guard let document else { return "" }
    defer { xmlFreeDoc(document) }
    guard let content = xmlNodeGetContent(xmlDocGetRootElement(document)) else { return "" }
    defer { xmlFree(content) }
    return String(cString: content)
  }

  static func parse(_ source: String, attachments: [MailAttachment]) throws -> HTMLDocument {
    guard source.utf8.count <= maximumBytes else {
      throw ClientError.rejected("HTML 正文较大，已切换为分段源码。")
    }
    let options = Int32(
      HTML_PARSE_RECOVER.rawValue | HTML_PARSE_NONET.rawValue
        | HTML_PARSE_NOERROR.rawValue | HTML_PARSE_NOWARNING.rawValue)
    let document = source.withCString {
      htmlReadMemory($0, Int32(source.utf8.count), nil, "UTF-8", options)
    }
    guard let document else { throw ClientError.rejected("无法排版此邮件，已切换为源码。") }
    defer { xmlFreeDoc(document) }
    var renderer = Renderer(attachments: attachments)
    let markup = try renderer.render(xmlDocGetRootElement(document))
    return HTMLDocument(
      markup: markup, hasRemoteImages: renderer.remote, inlineIDs: renderer.inlineIDs)
  }

  func page(allowRemoteImages: Bool) -> String {
    let images = allowRemoteImages ? "mohua-image: https:" : "mohua-image:"
    return """
      <!doctype html><html><head><meta charset="utf-8">
      <meta http-equiv="Content-Security-Policy" content="default-src 'none'; script-src 'none'; style-src 'unsafe-inline'; img-src \(images); font-src 'none'; connect-src 'none'; frame-src 'none'; object-src 'none'; base-uri 'none'; form-action 'none'">
      <meta name="referrer" content="no-referrer">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <style>body{margin:8px;color:#202124;background:#fff;font:17px -apple-system;overflow-wrap:anywhere}img{max-width:100%;height:auto}table{max-width:100%}pre{white-space:pre-wrap}blockquote{margin-left:12px;padding-left:12px;border-left:2px solid #ccc}a{color:#007aff}</style>
      </head><body>\(markup)</body></html>
      """
  }

  static func externalURL(_ value: String) -> URL? {
    guard !value.unicodeScalars.contains(where: { CharacterSet.controlCharacters.contains($0) }),
      let url = URL(string: value), ["http", "https"].contains(url.scheme?.lowercased() ?? ""),
      let host = url.host, !host.isEmpty, url.user == nil, url.password == nil
    else { return nil }
    return url
  }

  static func contentID(_ value: String) -> String {
    value.trimmingCharacters(in: .whitespacesAndNewlines)
      .trimmingCharacters(in: CharacterSet(charactersIn: "<>"))
  }

  private struct Renderer {
    let attachments: [MailAttachment]
    var remote = false
    var inlineIDs: Set<Int> = []
    var visited = 0
    let tags: Set<String> = [
      "p", "div", "span", "br", "hr", "a", "img", "b", "strong", "i", "em", "u", "s", "strike",
      "small", "big", "sub", "sup", "h1", "h2", "h3", "h4", "h5", "h6", "ul", "ol", "li",
      "dl", "dt", "dd", "blockquote", "pre", "code", "table", "thead", "tbody", "tfoot", "tr",
      "td", "th", "caption", "colgroup", "col", "center", "font", "section", "article", "header",
      "footer",
    ]
    let drop: Set<String> = [
      "script", "style", "iframe", "frame", "frameset", "object", "embed", "svg", "math",
      "form", "input", "button", "textarea", "select", "option", "video", "audio", "source",
      "link", "meta", "base", "template", "noscript",
    ]
    let attributes: Set<String> = [
      "title", "alt", "width", "height", "align", "valign", "bgcolor", "color", "face", "size",
      "colspan", "rowspan", "cellpadding", "cellspacing", "border", "dir", "lang",
    ]
    // CSS is deliberately limited to inline presentation. No URL, positioning, animation or imports.
    let styles: Set<String> = [
      "color", "background-color", "font-family", "font-size", "font-weight", "font-style",
      "text-align", "text-decoration", "text-indent", "line-height", "letter-spacing",
      "white-space", "word-break", "overflow-wrap", "vertical-align", "border", "border-color",
      "border-width", "border-style", "border-collapse", "border-spacing", "border-radius",
      "padding", "padding-top", "padding-bottom", "padding-left", "padding-right",
      "margin", "margin-top", "margin-bottom", "margin-left", "margin-right", "width", "max-width",
      "height",
    ]

    mutating func render(_ first: xmlNodePtr?, depth: Int = 0) throws -> String {
      guard depth < 100 else { throw ClientError.rejected("HTML 层级过深，已切换为源码。") }
      var result = ""
      var next = first
      while let node = next {
        next = node.pointee.next
        visited += 1
        guard visited <= 30000 else { throw ClientError.rejected("HTML 结构过于复杂，已切换为源码。") }
        if node.pointee.type == XML_TEXT_NODE {
          if let content = node.pointee.content { result += escape(String(cString: content)) }
          continue
        }
        guard node.pointee.type == XML_ELEMENT_NODE, let name = node.pointee.name else { continue }
        let tag = String(cString: name).lowercased()
        if drop.contains(tag) { continue }
        if !tags.contains(tag) {
          result += try render(node.pointee.children, depth: depth + 1)
          continue
        }
        var attrs = ""
        var property = node.pointee.properties
        while let attr = property {
          property = attr.pointee.next
          let key = String(cString: attr.pointee.name).lowercased()
          guard let bytes = xmlNodeListGetString(node.pointee.doc, attr.pointee.children, 1) else {
            continue
          }
          let value = String(cString: bytes)
          xmlFree(bytes)
          var allowed: String?
          if attributes.contains(key) { allowed = value }
          if key == "style" { allowed = cleanStyle(value) }
          if tag == "a", key == "href" { allowed = HTMLDocument.externalURL(value)?.absoluteString }
          if tag == "img", key == "src" { allowed = imageURL(value) }
          if let allowed { attrs += " \(key)=\"\(escape(allowed))\"" }
        }
        result += "<\(tag)\(attrs)>"
        if !["img", "br", "hr", "col"].contains(tag) {
          result += try render(node.pointee.children, depth: depth + 1)
          result += "</\(tag)>"
        }
      }
      return result
    }

    mutating func imageURL(_ value: String) -> String? {
      if value.lowercased().hasPrefix("cid:") {
        let cid = HTMLDocument.contentID(
          String(value.dropFirst(4)).removingPercentEncoding ?? String(value.dropFirst(4)))
        let matches = attachments.filter {
          $0.contentId.map(HTMLDocument.contentID) == cid
            && InlineImagePolicy.types.contains($0.contentType.lowercased())
        }
        guard matches.count == 1, let attachment = matches.first else { return nil }
        inlineIDs.insert(attachment.id)
        return "mohua-image://inline/\(attachment.id)"
      }
      guard let url = HTMLDocument.externalURL(value), url.scheme?.lowercased() == "https" else {
        return nil
      }
      remote = true
      return url.absoluteString
    }

    func cleanStyle(_ input: String) -> String {
      input.split(separator: ";").compactMap { declaration -> String? in
        let pieces = declaration.split(separator: ":", maxSplits: 1)
        guard pieces.count == 2 else { return nil }
        let key = pieces[0].trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        let value = pieces[1].trimmingCharacters(in: .whitespacesAndNewlines)
        guard styles.contains(key), value.count <= 200,
          value.unicodeScalars.allSatisfy({
            CharacterSet(
              charactersIn:
                "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 #.,%-'\""
            ).contains($0)
          })
        else { return nil }
        return "\(key):\(value)"
      }.joined(separator: ";")
    }

    func escape(_ text: String) -> String {
      text.replacingOccurrences(of: "&", with: "&amp;")
        .replacingOccurrences(of: "<", with: "&lt;").replacingOccurrences(of: ">", with: "&gt;")
        .replacingOccurrences(of: "\"", with: "&quot;")
    }
  }
}

enum InlineImagePolicy {
  static let types: Set<String> = ["image/png", "image/jpeg", "image/gif", "image/webp"]
  static let maximumBytes: Int64 = 5 * 1024 * 1024
  static let maximumTotalBytes = 15 * 1024 * 1024
  static let maximumImages = 12
}
