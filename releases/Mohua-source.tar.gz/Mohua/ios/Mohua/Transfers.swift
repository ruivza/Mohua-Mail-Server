import Foundation

/// Every reader is scoped by the full IMAP identity; UIDs are never global identifiers.
struct MessageIdentity: Hashable, Codable, Sendable {
  let account: String
  let folder: String
  let uidValidity: String
  let uid: Int
  var path: [String] { ["api", "accounts", account, "messages", String(uid)] }
  var query: [URLQueryItem] {
    [
      URLQueryItem(name: "folder", value: folder),
      URLQueryItem(name: "uidValidity", value: uidValidity),
    ]
  }
}
struct MessageMetadata: Codable, Sendable {
  struct Body: Codable, Sendable { let contentType: String }
  let uid: Int
  let uidValidity: String
  let subject: String
  let from: String
  let to: String
  let date: String?
  var flags: [String]?
  let body: Body?
  let attachments: [MailAttachment]
  var replyTo: [MailAddress]? = nil
  var toAddresses: [MailAddress]? = nil
  var ccAddresses: [MailAddress]? = nil
}
struct MailAttachment: Codable, Identifiable, Sendable {
  let id: Int
  let filename: String
  let size: Int64
  let contentType: String
  var contentId: String? = nil
}
struct MailActionResult: Decodable {
  let updated: Bool
  let destination: String?
}

/// Temporary files are never indexed or backed up. Their names contain no mail identifiers.
enum TransferFiles {
  static let root = FileManager.default.temporaryDirectory.appendingPathComponent(
    "MohuaTransfers", isDirectory: true)
  static func clearAll() { try? FileManager.default.removeItem(at: root) }
  static func createDirectory() throws -> URL {
    let url = root.appendingPathComponent(UUID().uuidString, isDirectory: true)
    try FileManager.default.createDirectory(
      at: url, withIntermediateDirectories: true,
      attributes: [.protectionKey: FileProtectionType.complete])
    var resource = url
    var values = URLResourceValues()
    values.isExcludedFromBackup = true
    try resource.setResourceValues(values)
    return url
  }
  static func completeUTF8Prefix(_ data: Data) -> String {
    for trailing in 0...min(3, data.count) {
      if let text = String(data: data.dropLast(trailing), encoding: .utf8) { return text }
    }
    return String(decoding: data, as: UTF8.self)
  }
  static func safeFilename(_ filename: String) -> String {
    let clean = filename.unicodeScalars.map { scalar -> String in
      if CharacterSet.controlCharacters.contains(scalar) || "/\\:".unicodeScalars.contains(scalar) {
        return "_"
      }
      return String(scalar)
    }.joined()
    let trimmed = String(clean.prefix(100)).trimmingCharacters(in: .whitespacesAndNewlines)
    return trimmed.isEmpty || trimmed == "." || trimmed == ".." ? "attachment" : trimmed
  }

  /// Called off the main actor. Writes bounded chunks into a protected file, never a whole-body Data buffer.
  static func receive(
    _ request: URLRequest, at destination: URL,
    maximumBytes: Int64? = nil,
    preview: (@Sendable (String) async -> Void)? = nil,
    progress: @escaping @Sendable (Int64) async -> Void
  ) async throws {
    let config = URLSessionConfiguration.ephemeral
    config.urlCache = nil
    config.httpCookieStorage = nil
    config.timeoutIntervalForRequest = 60
    config.timeoutIntervalForResource = 600
    let delegate = MailAPI()
    let transport = URLSession(configuration: config, delegate: delegate, delegateQueue: nil)
    defer { transport.invalidateAndCancel() }
    try await withTaskCancellationHandler {
      try Task.checkCancellation()
      let (bytes, response) = try await transport.bytes(for: request)
      try MailAPI.check(response)
      try Task.checkCancellation()
      guard
        FileManager.default.createFile(
          atPath: destination.path, contents: nil,
          attributes: [.protectionKey: FileProtectionType.complete])
      else {
        throw CocoaError(.fileWriteUnknown)
      }
      let file = try FileHandle(forWritingTo: destination)
      var complete = false
      defer {
        try? file.close()
        if !complete { try? FileManager.default.removeItem(at: destination) }
      }
      var chunk = Data()
      chunk.reserveCapacity(32768)
      var total: Int64 = 0
      var prefix = Data()
      var nextFlush = 4096
      for try await byte in bytes {
        chunk.append(byte)
        if let maximumBytes, total + Int64(chunk.count) > maximumBytes {
          throw ClientError.rejected("正文超过预取大小限制。")
        }
        if chunk.count == nextFlush {
          try Task.checkCancellation()
          try file.write(contentsOf: chunk)
          total += Int64(chunk.count)
          if preview != nil && prefix.count < BodyPager.pageSize {
            prefix.append(chunk.prefix(BodyPager.pageSize - prefix.count))
            await preview?(completeUTF8Prefix(prefix))
          }
          chunk.removeAll(keepingCapacity: true)
          nextFlush = 32768
          await progress(total)
        }
      }
      try Task.checkCancellation()
      try file.write(contentsOf: chunk)
      total += Int64(chunk.count)
      if preview != nil && prefix.count < BodyPager.pageSize {
        prefix.append(chunk.prefix(BodyPager.pageSize - prefix.count))
        await preview?(completeUTF8Prefix(prefix))
      }
      try file.synchronize()
      await progress(total)
      complete = true
    } onCancel: {
      transport.invalidateAndCancel()
    }
  }
}

struct BodyPager {
  static let pageSize = 65536
  let url: URL
  let byteCount: Int
  init(url: URL) throws {
    self.url = url
    byteCount = try url.resourceValues(forKeys: [.fileSizeKey]).fileSize ?? 0
  }
  var pageCount: Int { max(1, (byteCount + Self.pageSize - 1) / Self.pageSize) }
  func text(at page: Int) throws -> String {
    guard page >= 0, page < pageCount else { throw ClientError.invalidResponse }
    let file = try FileHandle(forReadingFrom: url)
    defer { try? file.close() }
    try file.seek(toOffset: UInt64(page * Self.pageSize))
    let bytes = [UInt8](try file.read(upToCount: Self.pageSize + 4) ?? Data())
    var start = 0
    var end = min(Self.pageSize, bytes.count)
    // Extend a UTF-8 character straddling the end, skip it at the next page's start.
    if page > 0 { while start < bytes.count && bytes[start] & 0xC0 == 0x80 { start += 1 } }
    while end < bytes.count && bytes[end] & 0xC0 == 0x80 { end += 1 }
    return String(decoding: bytes[start..<max(start, end)], as: UTF8.self)
  }
}
