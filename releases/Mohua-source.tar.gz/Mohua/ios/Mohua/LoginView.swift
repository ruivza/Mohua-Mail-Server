import SwiftUI

struct LoginView: View {
  @EnvironmentObject private var store: MailStore
  @State private var server = ""
  @State private var email = ""
  @State private var password = ""
  @State private var invitation = ""
  @State private var deviceName = UIDevice.current.name
  @State private var registering = false
  @State private var busy = false
  @State private var message: String?
  @FocusState private var focusedField: Field?
  private enum Field: Hashable { case server, email, password, invitation, device }

  var body: some View {
    NavigationStack {
      Form {
        Section {
          HStack(spacing: 16) {
            Image("MohuaMark").resizable().scaledToFit().frame(width: 64, height: 64).clipShape(RoundedRectangle(cornerRadius: 16))
            VStack(alignment: .leading, spacing: 4) {
              Text("Mohua").font(.title2.bold())
              Text("私人邮件，自主掌控。").font(.subheadline).foregroundStyle(.secondary)
            }
          }.padding(.vertical, 8)
        }
        Section("服务器与用户账号") {
          TextField("https://mail.example.com", text: $server)
            .keyboardType(.URL).textInputAutocapitalization(.never).autocorrectionDisabled()
            .accessibilityIdentifier("serverAddress")
            .focused($focusedField, equals: .server)
          TextField("账号邮箱", text: $email)
            .keyboardType(.emailAddress).textContentType(.username)
            .textInputAutocapitalization(.never).autocorrectionDisabled()
            .accessibilityIdentifier("loginEmail")
            .focused($focusedField, equals: .email)
          SecureField("密码", text: $password)
            .textContentType(registering ? .newPassword : .password)
            .accessibilityIdentifier("loginPassword")
            .focused($focusedField, equals: .password)
          if registering {
            TextField("管理员提供的注册邀请码", text: $invitation)
              .textInputAutocapitalization(.never).autocorrectionDisabled()
              .accessibilityIdentifier("registrationInvite")
              .focused($focusedField, equals: .invitation)
          } else {
            TextField("设备名称", text: $deviceName).accessibilityIdentifier("deviceName")
              .focused($focusedField, equals: .device)
          }
        }
        Section {
          Button(busy ? "请稍候…" : registering ? "创建用户账号" : "登录") { submit() }
            .disabled(
              busy || server.isEmpty || email.isEmpty || password.isEmpty
                || (registering && (invitation.isEmpty || password.count < 12))
            )
            .accessibilityIdentifier("submitLogin")
          Button(registering ? "已有账号，返回登录" : "使用邀请注册") {
            registering.toggle()
            message = nil
          }.disabled(busy)
        } footer: {
          Text(registering ? "邀请码只能使用一次，密码至少 12 个字符。注册成功后使用账号登录。" : "使用邀请注册的用户账号登录。服务器管理员请在管理后台登录。")
        }
        if let message { Section { Text(message).foregroundStyle(.secondary) } }
        if let notice = store.notice { Section { Text(notice).foregroundStyle(.red) } }
      }
      .navigationTitle(registering ? "邀请注册" : "Mohua")
    }
  }

  private func submit() {
    focusedField = nil
    busy = true
    store.notice = nil
    message = nil
    Task {
      defer { busy = false }
      do {
        if registering {
          try await store.register(
            server: server, email: email, password: password, invite: invitation)
          invitation = ""
          registering = false
          message = "账号已创建，请登录。"
        } else {
          try await store.login(
            server: server, email: email, password: password, deviceName: deviceName)
          password = ""
          await store.refresh()
        }
      } catch ClientError.expired {
        message = "账号或密码不正确，或用户已被停用。"
      } catch {
        message = error.localizedDescription
      }
    }
  }
}
