import SwiftUI
import UniformTypeIdentifiers

struct ComposeView: View {
  @EnvironmentObject private var store: MailStore
  @Environment(\.dismiss) private var dismiss
  @Environment(\.scenePhase) private var phase
  @StateObject private var model: ComposeModel
  @State private var importing = false
  @State private var showClose = false
  @State private var showSend = false
  @FocusState private var field: String?

  init(draft: MailDraft) { _model = StateObject(wrappedValue: ComposeModel(draft: draft)) }
  private var mailboxes: [Mailbox] { store.accounts.filter { $0.mode == "proxy" } }
  private var canSend: Bool {
    !model.busy && (model.draft.editable || model.draft.attempt?.status?.state == "prepared")
      && mailboxes.contains { $0.id == model.draft.accountID }
  }

  var body: some View {
    NavigationStack {
      ScrollViewReader { proxy in
        Form {
          if let error = model.error {
            Text(error).font(.footnote).foregroundStyle(.red).id("composeError")
          }
          if let attempt = model.draft.attempt { sendState(attempt).id("composeStatus") }
          Section {
            Picker("发件人", selection: $model.draft.accountID) {
              if !mailboxes.contains(where: { $0.id == model.draft.accountID }) {
                Text("请选择可用邮箱").tag(model.draft.accountID)
              }
              ForEach(mailboxes) { Text($0.email).tag($0.id) }
            }.disabled(model.draft.source != nil)
            address("收件人", text: $model.draft.to, id: "composeTo")
            address("抄送", text: $model.draft.cc, id: "composeCc")
            address("密送", text: $model.draft.bcc, id: "composeBcc")
            TextField("主题", text: $model.draft.subject).accessibilityIdentifier("composeSubject")
              .focused($field, equals: "subject")
          }.disabled(!model.draft.editable || model.busy)
          Section {
            TextEditor(text: $model.draft.text).frame(minHeight: 230)
              .accessibilityLabel("邮件正文").accessibilityIdentifier("composeBody").focused(
                $field, equals: "body"
              )
              .disabled(!model.draft.editable || model.busy)
          } footer: {
            Text(model.saved ? "已保存到本机" : "正在保存草稿…")
          }
          Section("附件") {
            if model.draft.source?.kind == "forward" {
              Label("原邮件将作为 original.eml 附件转发，包含原附件。", systemImage: "envelope")
                .font(.footnote)
            }
            ForEach(model.draft.attachments) { attachment in
              HStack {
                VStack(alignment: .leading) {
                  Text(attachment.filename)
                  Text(ByteCountFormatter.string(fromByteCount: attachment.size, countStyle: .file))
                    .font(.caption).foregroundStyle(.secondary)
                }
                Spacer()
                if model.draft.editable {
                  Button(role: .destructive) {
                    model.removeFile(attachment, store: store)
                  } label: {
                    Image(systemName: "minus.circle")
                  }.accessibilityLabel("移除 \(attachment.filename)").disabled(model.busy)
                }
              }
            }
            if model.draft.editable {
              Button {
                importing = true
              } label: {
                Label("添加附件", systemImage: "paperclip")
              }
              .disabled(model.busy).accessibilityIdentifier("composeAttachment")
            }
          }
          Section {
            Picker("已发送副本", selection: $model.draft.sentCopy) {
              Text("由邮箱服务商保存").tag("provider")
              Text("由 Mohua 保存到已发送").tag("append")
            }.disabled(!model.draft.editable || model.busy)
          } footer: {
            Text("如果服务商不会自动保存发出的邮件，请选择由 Mohua 保存。请勿同时开启两种保存方式，以免出现重复副本。")
          }
          if model.draft.source != nil && model.draft.editable {
            Button("改为新邮件") { model.draft.source = nil }.disabled(model.busy)
          }
        }
        .scrollDismissesKeyboard(.interactively)
        .onChange(of: model.draft.attempt?.status) { _, _ in
          proxy.scrollTo("composeStatus", anchor: .top)
        }
        .onChange(of: model.error) { _, value in
          if value != nil { proxy.scrollTo("composeError", anchor: .top) }
        }
        .navigationTitle(model.draft.editable ? "写邮件" : "发送记录")
        .navigationBarTitleDisplayMode(.inline)
        .toolbar {
          ToolbarItem(placement: .cancellationAction) {
            Button("关闭") {
              if model.draft.editable && !model.busy {
                showClose = true
              } else if model.save(store) {
                dismiss()
              }
            }.accessibilityIdentifier("closeCompose")
          }
          ToolbarItem(placement: .confirmationAction) {
            if model.busy {
              ProgressView()
            } else if model.draft.editable || model.draft.attempt?.status?.state == "prepared" {
              Button {
                showSend = true
              } label: {
                Image(systemName: "arrow.up.circle.fill").font(.title2)
              }
              .accessibilityLabel("发送邮件").accessibilityIdentifier("sendCompose").disabled(!canSend)
            }
          }
        }
        .task { model.attach(store) }
        .onChange(of: model.draft) { _, _ in model.queueSave(store) }
        .onChange(of: phase) { _, value in if value != .active { model.save(store) } }
        .onDisappear { model.save(store) }
        .interactiveDismissDisabled()
        .confirmationDialog("保留这封邮件？", isPresented: $showClose, titleVisibility: .visible) {
          Button("保存草稿") { if model.save(store) { dismiss() } }
          Button("删除草稿", role: .destructive) { if model.discard(store) { dismiss() } }
          Button("继续编辑", role: .cancel) {}
        }
        .alert("发送这封邮件？", isPresented: $showSend) {
          Button("发送", role: .none) { Task { await model.send(store) } }.accessibilityIdentifier(
            "confirmSend")
          Button("取消", role: .cancel) {}
        } message: {
          Text("将从所选邮箱发送给填写的收件人、抄送和密送地址。")
        }
        .fileImporter(
          isPresented: $importing, allowedContentTypes: [.item], allowsMultipleSelection: true
        ) { result in
          switch result {
          case .success(let urls): Task { await model.addFiles(urls, store: store) }
          case .failure(let error): model.error = error.localizedDescription
          }
        }
      }
    }
    .presentationDetents([.large])
  }

  private func address(_ title: String, text: Binding<String>, id: String) -> some View {
    HStack {
      Text(title).foregroundStyle(.secondary).frame(width: 52, alignment: .leading)
      TextField("邮箱地址，多个用逗号分隔", text: text).keyboardType(.emailAddress)
        .textInputAutocapitalization(.never).autocorrectionDisabled().accessibilityIdentifier(id)
        .focused($field, equals: id)
    }
  }
  @ViewBuilder private func sendState(_ attempt: SendAttempt) -> some View {
    Section("发送状态") {
      Text(
        attempt.uploadStarted && attempt.status?.state == "prepared"
          ? "上传已开始，发送结果尚未确认。请先查询状态。"
          : attempt.status?.explanation ?? "发送准备的结果尚未确认，请查询状态。"
      )
      .accessibilityIdentifier("sendState")
      if let copy = attempt.status?.sentCopy,
        ["failed", "failed_or_unknown", "pending"].contains(copy)
      {
        Text("邮件可能已送达，但已发送副本未确认保存。请勿因此重发邮件。")
          .font(.footnote).foregroundStyle(.orange)
      }
      Button("查询发送状态") { Task { await model.refreshStatus(store) } }
        .disabled(model.busy).accessibilityIdentifier("refreshSendStatus")
      if let state = attempt.status?.state, ["failed", "expired"].contains(state) {
        Button("返回编辑") { model.resumeEditing(store) }
      }
      if model.busy { Text("关闭页面不会撤回已交给服务器的邮件。稍后可在发送记录中查询。") }
    }
  }
}

struct DraftsView: View {
  @EnvironmentObject private var store: MailStore
  @State private var drafts: [MailDraft] = []
  @State private var selected: MailDraft?
  @State private var deleting: MailDraft?
  @State private var error: String?
  var body: some View {
    List {
      if let error { Text(error).foregroundStyle(.red) }
      if drafts.isEmpty { ContentUnavailableView("暂无草稿或发送记录", systemImage: "doc") }
      ForEach(drafts) { draft in
        Button {
          selected = draft
        } label: {
          VStack(alignment: .leading, spacing: 5) {
            Text(draft.title).foregroundStyle(.primary)
            Text(draft.to.isEmpty ? "未填写收件人" : draft.to).font(.subheadline).foregroundStyle(
              .secondary)
            Text(draft.stateLabel).font(.caption).foregroundStyle(.secondary)
          }
        }.swipeActions {
          Button("删除", role: .destructive) { deleting = draft }
        }
      }
      Text("仅保存在此设备，退出登录会清除。删除本机记录不会撤回服务器已经接收的邮件。")
        .font(.footnote).foregroundStyle(.secondary)
    }
    .navigationTitle("草稿与发送记录")
    .toolbar { Button("刷新") { load() } }
    .task { load() }
    .sheet(item: $selected, onDismiss: load) { ComposeView(draft: $0) }
    .confirmationDialog(
      "删除本机草稿或记录？",
      isPresented: Binding(
        get: { deleting != nil }, set: { if !$0 { deleting = nil } }), titleVisibility: .visible
    ) {
      Button("删除本机记录", role: .destructive) {
        do {
          if let draft = deleting, let session = store.session {
            try store.drafts.remove(draft, session: session)
          }
          deleting = nil
          load()
        } catch { self.error = error.localizedDescription }
      }
    }
  }
  private func load() {
    do {
      guard let session = store.session else {
        drafts = []
        return
      }
      drafts = try store.drafts.list(session: session)
      error = nil
    } catch { self.error = error.localizedDescription }
  }
}
