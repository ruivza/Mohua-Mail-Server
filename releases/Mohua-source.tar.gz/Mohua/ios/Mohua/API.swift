import Foundation

struct DeviceSession: Codable {
  let server: URL
  let token: String
  let deviceId: String
  let expires: Double
}
struct LoginResult: Decodable {
  let token: String
  let deviceId: String
  let expires: Double
}
struct Mailbox: Codable, Identifiable, Hashable {
  let id: String
  let email: String
  let mode: String
  let imap_host: String?
  let imap_port: Int?
  let smtp_host: String?
  let smtp_port: Int?
  let monitor_enabled: Int?
  let connectionStatus: String?
}
struct MailFolder: Codable, Identifiable, Hashable {
  let path: String
  let name: String
  let specialUse: String?
  var id: String { path }
}
struct MailAddress: Codable, Sendable, Equatable {
  let name: String?
  let address: String?
}
struct MailSummary: Codable, Identifiable, Equatable {
  let uid: Int
  let size: Int?
  let subject: String
  let from: [MailAddress]
  let date: String?
  var flags: [String]
  var id: Int { uid }
  var sender: String { from.map { $0.name ?? $0.address ?? "未知发件人" }.joined(separator: ", ") }
}
struct MailPage: Decodable {
  let uidValidity: String
  let items: [MailSummary]
  let nextBefore: Int?
  var highWater: Int? = nil
}
struct MailDelta: Decodable {
  struct State: Decodable {
    let uid: Int
    let flags: [String]
  }
  let uidValidity: String
  let highWater: Int
  let hasMore: Bool
  let items: [MailSummary]
  let existing: [State]
}
enum ClientError: LocalizedError {
  case invalidServer, expired, forbidden, changed, actionConflict
  case http(Int)
  case invalidResponse
  case rejected(String)
  var errorDescription: String? {
    switch self {
    case .rejected(let message): return message
    case .invalidServer: return "请输入不含路径、用户名或查询参数的 HTTPS 服务器地址。调试版可使用本地 HTTP。"
    case .expired: return "设备已失效或被撤销，请重新登录。"
    case .forbidden: return "账号没有此操作权限，或注册邀请已失效。"
    case .changed: return "邮箱状态已改变，请重新加载列表。"
    case .actionConflict: return "无法执行此操作。请刷新核对状态，或手动选择目标文件夹。"
    case .http(let status): return "服务器请求失败（\(status)），请稍后重试。"
    case .invalidResponse: return "服务器返回了无法识别的数据。"
    }
  }
}
final class MailAPI: NSObject, URLSessionTaskDelegate {
  private lazy var transport: URLSession = {
    let config = URLSessionConfiguration.ephemeral
    config.urlCache = nil
    config.httpCookieStorage = nil
    config.timeoutIntervalForRequest = 40
    return URLSession(configuration: config, delegate: self, delegateQueue: nil)
  }()
  // A redirect must never carry a device credential to another endpoint.
  func urlSession(
    _ session: URLSession, task: URLSessionTask,
    willPerformHTTPRedirection response: HTTPURLResponse,
    newRequest request: URLRequest,
    completionHandler: @escaping (URLRequest?) -> Void
  ) { completionHandler(nil) }

  static func serverURL(_ input: String) throws -> URL {
    guard let c = URLComponents(string: input.trimmingCharacters(in: .whitespacesAndNewlines)),
      let scheme = c.scheme?.lowercased(), let host = c.host, !host.isEmpty,
      c.user == nil, c.password == nil, c.query == nil, c.fragment == nil,
      c.path.isEmpty || c.path == "/", let url = c.url
    else { throw ClientError.invalidServer }
    if scheme == "https" { return url }
    #if DEBUG
      if scheme == "http"
        && (host == "localhost" || host == "127.0.0.1" || host.hasSuffix(".local"))
      {
        return url
      }
    #endif
    throw ClientError.invalidServer
  }
  func request<T: Decodable>(
    _ type: T.Type, server: URL, path: [String], token: String? = nil,
    query: [URLQueryItem] = [], body: Data? = nil, method: String? = nil,
    headers: [String: String] = [:]
  ) async throws -> T {
    var request = try makeRequest(server: server, path: path, token: token, query: query)
    request.httpMethod = method ?? (body == nil ? "GET" : "POST")
    request.httpBody = body
    request.setValue("application/json", forHTTPHeaderField: "Accept")
    if body != nil { request.setValue("application/json", forHTTPHeaderField: "Content-Type") }
    for (name, value) in headers { request.setValue(value, forHTTPHeaderField: name) }
    let (data, response) = try await transport.data(for: request)
    if (response as? HTTPURLResponse)?.statusCode == 409, path.last == "actions",
      let payload = try? JSONDecoder().decode([String: String].self, from: data),
      payload["error"] != "Mailbox changed; reload message list"
    {
      throw ClientError.actionConflict
    }
    if let status = (response as? HTTPURLResponse)?.statusCode, status >= 400,
      let payload = try? JSONDecoder().decode([String: String].self, from: data),
      let reason = payload["error"], let message = Self.validationMessages[reason]
    {
      throw ClientError.rejected(message)
    }
    try Self.check(response)
    do { return try JSONDecoder().decode(type, from: data) } catch {
      throw ClientError.invalidResponse
    }
  }
  private static let validationMessages = [
    "No unique Sent folder; configure provider copy or mailbox folders":
      "无法确定已发送文件夹，请检查邮箱或选择由服务商保存副本。",
    "Another send is running": "此账号正在发送另一封邮件，请稍后查询并继续。",
    "Key already used for a different message": "此发送记录对应其他内容，请保留记录并核对状态。",
    "Invalid email": "请输入有效的邮箱地址。",
    "Password must contain 12–128 characters when creating an account": "注册密码应为 12–128 个字符。",
    "Invalid or expired invite": "注册邀请无效或已过期，请向管理员获取新邀请。",
    "Account already exists": "该用户账号已存在，请直接登录。",
    "Mailbox already added": "这个邮箱已添加，请在邮箱管理中查看。",
    "Invalid device name": "设备名称应为 1–80 个字符，且不能包含控制字符。",
    "Maximum 20 devices; revoke an existing device first": "已达到 20 台设备上限，请先在其他设备中撤销不再使用的设备。",
  ]

  func uploadMail(session: DeviceSession, id: String, file: URL) async throws -> SendStatus {
    var request = try makeRequest(
      server: session.server, path: ["api", "outbox", id], token: session.token, query: [])
    request.httpMethod = "PUT"
    request.timeoutInterval = 600
    request.setValue("application/octet-stream", forHTTPHeaderField: "Content-Type")
    let (data, response) = try await transport.upload(for: request, fromFile: file)
    try Self.check(response)
    return try JSONDecoder().decode(SendStatus.self, from: data)
  }

  static func check(_ response: URLResponse) throws {
    guard let response = response as? HTTPURLResponse else { throw ClientError.invalidResponse }
    switch response.statusCode {
    case 200..<300: return
    case 401: throw ClientError.expired
    case 403: throw ClientError.forbidden
    case 409: throw ClientError.changed
    default: throw ClientError.http(response.statusCode)
    }
  }
  func makeRequest(server: URL, path: [String], token: String?, query: [URLQueryItem]) throws
    -> URLRequest
  {
    var url = try Self.serverURL(server.absoluteString)
    for component in path { url.appendPathComponent(component) }
    guard var components = URLComponents(url: url, resolvingAgainstBaseURL: false) else {
      throw ClientError.invalidServer
    }
    components.queryItems = query.isEmpty ? nil : query
    // Node's URLSearchParams treats a literal '+' as a space.
    components.percentEncodedQuery = components.percentEncodedQuery?.replacingOccurrences(
      of: "+", with: "%2B")
    guard let endpoint = components.url else { throw ClientError.invalidServer }
    var request = URLRequest(url: endpoint)
    if let token { request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization") }
    return request
  }
  func login(
    server: URL, email: String, password: String, deviceName: String,
    deviceId: String?
  ) async throws -> DeviceSession {
    var values = ["email": email, "password": password, "deviceName": deviceName]
    values["deviceId"] = deviceId
    let body = try JSONEncoder().encode(values)
    let result = try await request(
      LoginResult.self, server: server, path: ["api", "client", "login"], body: body)
    return DeviceSession(
      server: server, token: result.token, deviceId: result.deviceId, expires: result.expires)
  }
}

struct OperationResult: Decodable {
  let id: String?
  let created: Bool?
  let updated: Bool?
  let removed: Bool?
  let revoked: Bool?
  let connectionStatus: String?
}

struct ClientDevice: Decodable, Identifiable {
  let id: String
  let name: String
  let platform: String
  let created: Double
  let sessionActive: Bool
}
