import CryptoKit
import Foundation

/// Drafts and send receipts live on this device only. Every write requires the active scope,
/// so a late import or network callback cannot recreate data after logout.
@MainActor
final class DraftStore {
  private let root: URL
  private var scope: String?
  private var deleted: Set<UUID> = []

  init(root: URL? = nil) {
    self.root =
      root
      ?? FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
      .appendingPathComponent("MohuaDrafts", isDirectory: true)
  }
  func activate(_ session: DeviceSession) { scope = Self.scope(session) }
  func clear() {
    scope = nil
    try? FileManager.default.removeItem(at: root)
  }
  private static func scope(_ session: DeviceSession) -> String {
    SHA256.hash(data: Data((session.server.absoluteString + "\n" + session.deviceId).utf8))
      .map { String(format: "%02x", $0) }.joined()
  }
  private func directory(_ session: DeviceSession, id: UUID? = nil) throws -> URL {
    guard scope == Self.scope(session) else { throw ClientError.expired }
    if let id, deleted.contains(id) { throw ClientError.rejected("这份本机草稿或记录已删除。") }
    let directory = root.appendingPathComponent(Self.scope(session), isDirectory: true)
    return id.map { directory.appendingPathComponent($0.uuidString, isDirectory: true) }
      ?? directory
  }
  private func create(_ directory: URL) throws {
    try FileManager.default.createDirectory(
      at: directory, withIntermediateDirectories: true,
      attributes: [.protectionKey: FileProtectionType.complete])
    var url = root
    var values = URLResourceValues()
    values.isExcludedFromBackup = true
    try url.setResourceValues(values)
  }
  func list(session: DeviceSession) throws -> [MailDraft] {
    let directory = try directory(session)
    guard FileManager.default.fileExists(atPath: directory.path) else { return [] }
    return try FileManager.default.contentsOfDirectory(
      at: directory, includingPropertiesForKeys: nil
    )
    .compactMap {
      try? JSONDecoder().decode(
        MailDraft.self, from: Data(contentsOf: $0.appendingPathComponent("draft.json")))
    }
    .sorted { $0.updated > $1.updated }
  }
  func save(_ draft: MailDraft, session: DeviceSession) throws {
    let directory = try directory(session, id: draft.id)
    if !FileManager.default.fileExists(atPath: directory.path),
      try list(session: session).count >= 100
    {
      throw ClientError.rejected("本机草稿与发送记录已达 100 条，请先整理。")
    }
    guard draft.text.utf8.count <= 512 * 1024,
      draft.to.utf8.count + draft.cc.utf8.count + draft.bcc.utf8.count <= 100 * 1024,
      draft.subject.utf8.count <= 8192
    else { throw ClientError.rejected("草稿内容过大，无法保存。") }
    try create(directory)
    var saved = draft
    saved.updated = Date()
    try JSONEncoder().encode(saved).write(
      to: directory.appendingPathComponent("draft.json"),
      options: [.atomic, .completeFileProtection])
  }
  func remove(_ draft: MailDraft, session: DeviceSession) throws {
    let directory = try directory(session, id: draft.id)
    if FileManager.default.fileExists(atPath: directory.path) {
      try FileManager.default.removeItem(at: directory)
    }
    deleted.insert(draft.id)
  }
  func attachmentURL(_ attachment: DraftAttachment, draft: MailDraft, session: DeviceSession) throws
    -> URL
  {
    try directory(session, id: draft.id).appendingPathComponent(attachment.id.uuidString)
  }
  func keepAttachment(
    _ staged: URL, attachment: DraftAttachment, draft: MailDraft, session: DeviceSession
  ) throws {
    let existing = try list(session: session).flatMap(\.attachments).reduce(Int64(0)) {
      $0 + $1.size
    }
    guard existing + attachment.size <= 250 * 1024 * 1024 else {
      throw ClientError.rejected("本机草稿附件已达 250 MiB，请先整理。")
    }
    let destination = try attachmentURL(attachment, draft: draft, session: session)
    try create(destination.deletingLastPathComponent())
    try FileManager.default.moveItem(at: staged, to: destination)
  }
  func removeAttachment(_ attachment: DraftAttachment, draft: MailDraft, session: DeviceSession)
    throws
  {
    let url = try attachmentURL(attachment, draft: draft, session: session)
    try FileManager.default.removeItem(at: url)
  }

  nonisolated static func copyFile(_ source: URL, to destination: URL, maximum: Int64) throws
    -> Int64
  {
    let input = try FileHandle(forReadingFrom: source)
    defer { try? input.close() }
    guard
      FileManager.default.createFile(
        atPath: destination.path, contents: nil,
        attributes: [.protectionKey: FileProtectionType.complete])
    else { throw CocoaError(.fileWriteUnknown) }
    let output = try FileHandle(forWritingTo: destination)
    defer { try? output.close() }
    var total: Int64 = 0
    while let chunk = try input.read(upToCount: 65536), !chunk.isEmpty {
      try Task.checkCancellation()
      total += Int64(chunk.count)
      guard total <= maximum else { throw ClientError.rejected("附件合计不能超过 25 MiB。") }
      try output.write(contentsOf: chunk)
    }
    try output.synchronize()
    return total
  }

  func uploadFile(_ draft: MailDraft, session: DeviceSession, directory: URL) async throws -> URL {
    let sources = try draft.attachments.map {
      (try attachmentURL($0, draft: draft, session: session), $0.size)
    }
    let destination = directory.appendingPathComponent("upload.bin")
    let worker = Task.detached {
      guard
        FileManager.default.createFile(
          atPath: destination.path, contents: nil,
          attributes: [.protectionKey: FileProtectionType.complete])
      else { throw CocoaError(.fileWriteUnknown) }
      let output = try FileHandle(forWritingTo: destination)
      defer { try? output.close() }
      for (url, expected) in sources {
        let input = try FileHandle(forReadingFrom: url)
        defer { try? input.close() }
        var size: Int64 = 0
        while let bytes = try input.read(upToCount: 65536), !bytes.isEmpty {
          try Task.checkCancellation()
          size += Int64(bytes.count)
          guard size <= expected else { throw ClientError.rejected("附件已改变，请重新添加。") }
          try output.write(contentsOf: bytes)
        }
        guard size == expected else { throw ClientError.rejected("附件不完整，请重新添加。") }
      }
      try output.synchronize()
      return destination
    }
    return try await withTaskCancellationHandler {
      try await worker.value
    } onCancel: {
      worker.cancel()
    }
  }
}
