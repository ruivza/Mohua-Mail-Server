import CryptoKit
import Foundation
import Security

enum SessionKeychain {
  private static var query: [String: Any] {
    [
      kSecClass as String: kSecClassGenericPassword,
      kSecAttrService as String: "Mohua.device-session",
      kSecAttrAccount as String: "current",
    ]
  }
  static func load() throws -> DeviceSession? {
    var q = query
    q[kSecReturnData as String] = true
    q[kSecMatchLimit as String] = kSecMatchLimitOne
    var result: CFTypeRef?
    let status = SecItemCopyMatching(q as CFDictionary, &result)
    if status == errSecItemNotFound { return nil }
    guard status == errSecSuccess, let data = result as? Data else { throw failure(status) }
    return try JSONDecoder().decode(DeviceSession.self, from: data)
  }
  static func save(_ session: DeviceSession) throws {
    let values: [String: Any] = [
      kSecValueData as String: try JSONEncoder().encode(session),
      kSecAttrAccessible as String: kSecAttrAccessibleWhenUnlockedThisDeviceOnly,
    ]
    let status = SecItemUpdate(query as CFDictionary, values as CFDictionary)
    if status == errSecItemNotFound {
      let added = SecItemAdd(query.merging(values) { _, new in new } as CFDictionary, nil)
      guard added == errSecSuccess else { throw failure(added) }
    } else if status != errSecSuccess {
      throw failure(status)
    }
  }
  static func clear() throws {
    let status = SecItemDelete(query as CFDictionary)
    guard status == errSecSuccess || status == errSecItemNotFound else { throw failure(status) }
  }
  // Keep the installation's logical ID across token expiry. This is not an authentication secret.
  private static func identityQuery(server: URL, email: String) -> [String: Any] {
    let address = server.absoluteString.trimmingCharacters(in: CharacterSet(charactersIn: "/"))
    let owner = email.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
    let digest = SHA256.hash(data: Data("\(address)\n\(owner)".utf8)).map {
      String(format: "%02x", $0)
    }.joined()
    return [
      kSecClass as String: kSecClassGenericPassword,
      kSecAttrService as String: "Mohua.device-identity", kSecAttrAccount as String: digest,
    ]
  }

  static func deviceID(server: URL, email: String) throws -> String? {
    var q = identityQuery(server: server, email: email)
    q[kSecReturnData as String] = true
    q[kSecMatchLimit as String] = kSecMatchLimitOne
    var result: CFTypeRef?
    let status = SecItemCopyMatching(q as CFDictionary, &result)
    if status == errSecItemNotFound { return nil }
    guard status == errSecSuccess, let data = result as? Data else { throw failure(status) }
    return String(data: data, encoding: .utf8)
  }

  static func rememberDevice(_ session: DeviceSession, email: String) throws {
    let q = identityQuery(server: session.server, email: email)
    let values: [String: Any] = [
      kSecValueData as String: Data(session.deviceId.utf8),
      kSecAttrAccessible as String: kSecAttrAccessibleWhenUnlockedThisDeviceOnly,
    ]
    let status = SecItemUpdate(q as CFDictionary, values as CFDictionary)
    if status == errSecItemNotFound {
      let added = SecItemAdd(q.merging(values) { _, new in new } as CFDictionary, nil)
      guard added == errSecSuccess else { throw failure(added) }
    } else if status != errSecSuccess {
      throw failure(status)
    }
  }

  private static func failure(_ status: OSStatus) -> NSError {
    NSError(
      domain: "Mohua.Keychain", code: Int(status),
      userInfo: [NSLocalizedDescriptionKey: "无法访问安全存储，请解锁设备后重试。"])
  }
}

/// Delivery and revocation secrets stay in device-only Keychain storage.
enum PushVault {
  struct State: Codable {
    var current: SavedPush?
    var retired: [SavedPush] = []
  }
  private static var query: [String: Any] {
    [
      kSecClass as String: kSecClassGenericPassword,
      kSecAttrService as String: "Mohua.push-grants", kSecAttrAccount as String: "current",
    ]
  }
  static func load() throws -> State {
    var q = query
    q[kSecReturnData as String] = true
    q[kSecMatchLimit as String] = kSecMatchLimitOne
    var result: CFTypeRef?
    let status = SecItemCopyMatching(q as CFDictionary, &result)
    if status == errSecItemNotFound { return State() }
    guard status == errSecSuccess, let data = result as? Data else { throw failure(status) }
    return try JSONDecoder().decode(State.self, from: data)
  }
  private static func save(_ state: State) throws {
    let values: [String: Any] = [
      kSecValueData as String: try JSONEncoder().encode(state),
      kSecAttrAccessible as String: kSecAttrAccessibleWhenUnlockedThisDeviceOnly,
    ]
    let status = SecItemUpdate(query as CFDictionary, values as CFDictionary)
    if status == errSecItemNotFound {
      let added = SecItemAdd(query.merging(values) { _, new in new } as CFDictionary, nil)
      guard added == errSecSuccess else { throw failure(added) }
    } else if status != errSecSuccess {
      throw failure(status)
    }
  }
  static func saveCurrent(_ current: SavedPush) throws {
    var state = try load()
    state.current = current
    try save(state)
  }
  static func retire() throws {
    var state = try load()
    if let current = state.current,
      !state.retired.contains(where: { $0.grant.registrationId == current.grant.registrationId })
    {
      state.retired.append(current)
    }
    state.current = nil
    try save(state)
  }
  static func addRetired(_ entry: SavedPush) throws {
    var state = try load()
    if !state.retired.contains(where: { $0.grant.registrationId == entry.grant.registrationId }) {
      state.retired.append(entry)
    }
    try save(state)
  }
  static func removeRetired(_ id: String) throws {
    var state = try load()
    state.retired.removeAll { $0.grant.registrationId == id }
    try save(state)
  }
  private static func failure(_ status: OSStatus) -> NSError {
    NSError(
      domain: "Mohua.PushVault", code: Int(status),
      userInfo: [NSLocalizedDescriptionKey: "无法访问推送安全存储，请解锁后重试。"])
  }
}
