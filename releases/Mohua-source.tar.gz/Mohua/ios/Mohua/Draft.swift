import Foundation

struct DraftAttachment: Codable, Identifiable, Equatable, Sendable {
  var id = UUID()
  let filename: String
  let size: Int64
}

struct ComposeSource: Codable, Equatable, Sendable {
  let kind: String
  let uid: Int
  let folder: String
  let uidValidity: String
}

struct SendStatus: Codable, Equatable, Sendable {
  let id: String
  let state: String
  var accepted: Int? = nil
  var rejected: Int? = nil
  var sentCopy: String? = nil
  var error: String? = nil

  var explanation: String {
    switch state {
    case "prepared": return "邮件已准备好，尚未确认发送。"
    case "sending": return "服务器正在发送，可稍后查询结果。"
    case "sent": return "邮件已发送。"
    case "partial": return "部分收件人已接受（\(accepted ?? 0) 人），部分被拒绝（\(rejected ?? 0) 人）。请勿整封重发。"
    case "failed": return "发送前失败，可以修改草稿后重试。请检查邮箱连接和原邮件是否仍可访问。"
    case "expired": return "发送准备已过期，可以修改草稿后重新发送。"
    default: return "发送结果不确定。请到邮箱的已发送文件夹核对；不会自动重发。"
    }
  }
}

struct SendAttempt: Codable, Equatable, Sendable {
  var key = UUID().uuidString
  var status: SendStatus? = nil
  var uploadStarted = false
}

struct MailDraft: Codable, Identifiable, Equatable, Sendable {
  var id = UUID()
  var accountID: String
  var to = ""
  var cc = ""
  var bcc = ""
  var subject = ""
  var text = ""
  var sentCopy = "provider"
  var source: ComposeSource? = nil
  var attachments: [DraftAttachment] = []
  var attempt: SendAttempt? = nil
  var updated = Date()

  var editable: Bool { attempt == nil }
  var title: String { subject.isEmpty ? "（无主题）" : subject }
  var stateLabel: String {
    guard let attempt else { return "草稿" }
    switch attempt.status?.state {
    case "sent": return "已发送"
    case "partial": return "部分发送"
    case "failed": return "发送失败"
    case "expired": return "准备过期"
    case "prepared": return "待发送"
    case "sending": return "发送中"
    case "unknown": return "结果待核对"
    default: return "待查询"
    }
  }

  static func recipients(_ input: String) throws -> [String] {
    let values = input.components(separatedBy: CharacterSet(charactersIn: ",;，；\n"))
      .map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }.filter { !$0.isEmpty }
    var seen: Set<String> = []
    return try values.filter { value in
      guard value.utf16.count <= 254,
        !value.unicodeScalars.contains(where: { CharacterSet.controlCharacters.contains($0) }),
        value.range(of: #"^[^\s<>@,;]+@[^\s<>@,;]+\.[^\s<>@,;]+$"#, options: .regularExpression)
          != nil
      else { throw ClientError.rejected("请输入有效的邮箱地址，多个地址用逗号分隔。") }
      return seen.insert(value.lowercased()).inserted
    }
  }

  func payload() throws -> SendPayload {
    let to = try Self.recipients(to)
    let cc = try Self.recipients(cc)
    let bcc = try Self.recipients(bcc)
    guard (1...100).contains(to.count + cc.count + bcc.count) else {
      throw ClientError.rejected("请填写 1–100 个收件人。")
    }
    guard subject.utf16.count <= 998,
      !subject.contains(where: { $0 == "\r" || $0 == "\n" || $0 == "\0" }),
      text.utf8.count <= 256 * 1024
    else { throw ClientError.rejected("主题过长或正文超过 256 KiB。") }
    guard attachments.count <= 20,
      attachments.reduce(Int64(0), { $0 + $1.size }) <= 25 * 1024 * 1024
    else {
      throw ClientError.rejected("最多添加 20 个附件，合计不超过 25 MiB。")
    }
    return SendPayload(
      to: to, cc: cc, bcc: bcc, subject: subject, text: text,
      sentCopy: sentCopy,
      attachments: attachments.map { .init(filename: $0.filename, size: $0.size) }, source: source)
  }

  static func response(
    kind: String, identity: MessageIdentity, metadata: MessageMetadata,
    quote: String, ownAddresses: [String]
  ) -> MailDraft {
    var draft = MailDraft(accountID: identity.account)
    draft.source = ComposeSource(
      kind: kind, uid: identity.uid, folder: identity.folder, uidValidity: identity.uidValidity)
    let prefix = kind == "forward" ? "Fwd:" : "Re:"
    draft.subject =
      metadata.subject.lowercased().hasPrefix(prefix.lowercased())
      ? metadata.subject : "\(prefix) \(metadata.subject)"
    if kind != "forward" {
      let own = Set(ownAddresses.map { $0.lowercased() })
      var used = own
      func unique(_ values: [MailAddress]) -> [String] {
        values.compactMap { entry in
          guard let address = entry.address, (try? recipients(address))?.count == 1,
            used.insert(address.lowercased()).inserted
          else { return nil }
          return address
        }
      }
      let reply = unique(metadata.replyTo ?? [])
      let targets = reply.isEmpty ? unique(metadata.toAddresses ?? []) : reply
      let additional = kind == "replyAll" ? unique(metadata.toAddresses ?? []) : []
      draft.to = (targets + additional).joined(separator: ", ")
      if kind == "replyAll" {
        draft.cc = unique(metadata.ccAddresses ?? []).joined(separator: ", ")
      }
    }
    let excerpt = String(quote.prefix(16000))
    draft.text =
      "\n\n—— 原邮件 ——\n发件人：\(metadata.from)\n主题：\(metadata.subject)\n"
      + excerpt.components(separatedBy: .newlines).map { "> " + $0 }.joined(separator: "\n")
      + (quote.count > 16000 ? "\n（引用已截短）" : "")
    return draft
  }
}

struct SendPayload: Encodable {
  struct Attachment: Encodable {
    let filename: String
    let size: Int64
  }
  let to: [String]
  let cc: [String]
  let bcc: [String]
  let subject: String
  let text: String
  let sentCopy: String
  let attachments: [Attachment]
  let source: ComposeSource?
}
