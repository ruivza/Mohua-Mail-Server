import CryptoKit
import Foundation

struct FolderSnapshot: Codable {
  let account: String
  let folder: String
  let uidValidity: String
  var highWater: Int?
  var nextBefore: Int?
  var items: [MailSummary]
  var syncedAt: Date
  var pendingNew = false

  /// Only the explicitly queried UIDs can be removed by a delta response.
  mutating func merge(_ delta: MailDelta, known: Set<Int>) throws -> Set<Int> {
    guard delta.uidValidity == uidValidity, let previous = highWater,
      delta.highWater >= previous,
      delta.items.allSatisfy({ $0.uid > previous && $0.uid <= delta.highWater }),
      delta.existing.allSatisfy({ known.contains($0.uid) })
    else { throw ClientError.invalidResponse }
    var flags: [Int: [String]] = [:]
    for state in delta.existing { flags[state.uid] = state.flags }
    let removed = known.subtracting(flags.keys)
    items.removeAll { removed.contains($0.uid) }
    for position in items.indices {
      if let value = flags[items[position].uid] { items[position].flags = value }
    }
    var messages = Dictionary(items.map { ($0.uid, $0) }, uniquingKeysWith: { _, last in last })
    for item in delta.items { messages[item.uid] = item }
    items = messages.values.sorted { $0.uid > $1.uid }
    highWater = delta.highWater
    pendingNew = delta.hasMore
    syncedAt = Date()
    return removed
  }
}

/// Small, atomic folder snapshots. The checkpoint and rows are always written together.
/// Scope and generation checks reject callbacks from a removed account or an old session.
@MainActor
final class MailIndex {
  private struct Catalog: Codable {
    var accounts: [Mailbox] = []
    var folders: [String: [MailFolder]] = [:]
    var inboxOffset: Int? = nil
  }
  private let root: URL
  private var scope: String?
  private var catalog = Catalog()
  private(set) var generation = 0
  private let itemLimit: Int
  private let capacity: Int

  init(root: URL? = nil, itemLimit: Int = 1000, capacity: Int = 50 * 1024 * 1024) {
    self.root =
      root
      ?? FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask)[0]
      .appendingPathComponent("MohuaIndex", isDirectory: true)
    self.itemLimit = itemLimit
    self.capacity = capacity
  }
  private func hash(_ value: String) -> String {
    SHA256.hash(data: Data(value.utf8)).map { String(format: "%02x", $0) }.joined()
  }
  private var directory: URL? { scope.map { root.appendingPathComponent($0, isDirectory: true) } }
  private func file(_ account: String, _ folder: String) -> URL? {
    let key = (try? JSONEncoder().encode([account, folder])) ?? Data()
    return directory?.appendingPathComponent(hash(key.base64EncodedString()) + ".json")
  }
  private func read<T: Decodable>(_ type: T.Type, from url: URL?) -> T? {
    guard let url, let data = try? Data(contentsOf: url) else { return nil }
    return try? JSONDecoder().decode(type, from: data)
  }
  func activate(_ session: DeviceSession) {
    generation += 1
    scope = hash(session.server.absoluteString + "\n" + session.deviceId)
    catalog =
      read(Catalog.self, from: directory?.appendingPathComponent("catalog.json")) ?? Catalog()
  }
  var accounts: [Mailbox] { catalog.accounts }
  var inboxOffset: Int { max(0, catalog.inboxOffset ?? 0) }
  func advanceInboxes(to offset: Int) throws {
    catalog.inboxOffset = max(0, offset)
    try write(catalog, to: directory?.appendingPathComponent("catalog.json"))
  }
  func folders(_ account: String) -> [MailFolder] { catalog.folders[account] ?? [] }
  private func allowed(_ account: String) -> Bool {
    catalog.accounts.contains { $0.id == account && $0.mode == "proxy" }
  }
  private func write<T: Encodable>(_ value: T, to url: URL?) throws {
    guard let url, let directory else { throw CancellationError() }
    try FileManager.default.createDirectory(
      at: directory, withIntermediateDirectories: true,
      attributes: [.protectionKey: FileProtectionType.complete])
    var excluded = root
    var values = URLResourceValues()
    values.isExcludedFromBackup = true
    try excluded.setResourceValues(values)
    try JSONEncoder().encode(value).write(to: url, options: [.atomic, .completeFileProtection])
  }
  func saveAccounts(_ values: [Mailbox]) throws {
    let retained = Set(values.filter { $0.mode == "proxy" }.map(\.id))
    if Set(catalog.accounts.filter { $0.mode == "proxy" }.map(\.id)) != retained { generation += 1 }
    catalog.accounts = values
    catalog.folders = catalog.folders.filter { retained.contains($0.key) }
    for (url, snapshot) in snapshots() where !retained.contains(snapshot.account) {
      try? FileManager.default.removeItem(at: url)
    }
    try write(catalog, to: directory?.appendingPathComponent("catalog.json"))
  }
  func saveFolders(_ values: [MailFolder], account: String) throws -> Set<String> {
    guard allowed(account) else { throw CancellationError() }
    let retained = Set(values.map(\.path))
    var removed = Set(folders(account).map(\.path)).subtracting(retained)
    for (url, snapshot) in snapshots()
    where snapshot.account == account && !retained.contains(snapshot.folder) {
      removed.insert(snapshot.folder)
      try? FileManager.default.removeItem(at: url)
    }
    if !removed.isEmpty { generation += 1 }
    catalog.folders[account] = values
    try write(catalog, to: directory?.appendingPathComponent("catalog.json"))
    return removed
  }
  func snapshot(account: String, folder: String) -> FolderSnapshot? {
    guard allowed(account), let value = read(FolderSnapshot.self, from: file(account, folder)),
      value.account == account, value.folder == folder
    else { return nil }
    return value
  }
  func save(_ snapshot: FolderSnapshot, ticket: Int) throws {
    guard ticket == generation, allowed(snapshot.account) else { throw CancellationError() }
    var bounded = snapshot
    bounded.items.sort { $0.uid > $1.uid }
    if bounded.items.count > itemLimit {
      bounded.items = Array(bounded.items.prefix(itemLimit))
      bounded.nextBefore = bounded.items.last?.uid
    }
    try write(bounded, to: file(snapshot.account, snapshot.folder))
    trim()
  }
  func removeAccount(_ account: String) {
    generation += 1
    catalog.accounts.removeAll { $0.id == account }
    catalog.folders.removeValue(forKey: account)
    for (url, value) in snapshots() where value.account == account {
      try? FileManager.default.removeItem(at: url)
    }
    try? write(catalog, to: directory?.appendingPathComponent("catalog.json"))
  }
  func removeFolder(account: String, folder: String) {
    generation += 1
    if let url = file(account, folder) { try? FileManager.default.removeItem(at: url) }
  }
  func update(_ identity: MessageIdentity, flags: [String]? = nil, removed: Bool = false) throws {
    generation += 1
    guard var value = snapshot(account: identity.account, folder: identity.folder),
      value.uidValidity == identity.uidValidity
    else { return }
    if removed {
      value.items.removeAll { $0.uid == identity.uid }
    } else if let flags, let position = value.items.firstIndex(where: { $0.uid == identity.uid }) {
      value.items[position].flags = flags
    }
    try save(value, ticket: generation)
  }
  func flags(_ identity: MessageIdentity) -> [String]? {
    guard let value = snapshot(account: identity.account, folder: identity.folder),
      value.uidValidity == identity.uidValidity
    else { return nil }
    return value.items.first { $0.uid == identity.uid }?.flags
  }
  func clear() {
    generation += 1
    scope = nil
    catalog = Catalog()
    try? FileManager.default.removeItem(at: root)
  }
  private func snapshots() -> [(URL, FolderSnapshot)] {
    guard let directory else { return [] }
    let files =
      (try? FileManager.default.contentsOfDirectory(
        at: directory,
        includingPropertiesForKeys: nil)) ?? []
    return files.filter { $0.lastPathComponent != "catalog.json" }.compactMap { url in
      read(FolderSnapshot.self, from: url).map { (url, $0) }
    }
  }
  private func trim() {
    var bytes = 0
    for (url, _) in snapshots().sorted(by: { $0.1.syncedAt > $1.1.syncedAt }) {
      bytes += (try? url.resourceValues(forKeys: [.fileSizeKey]).fileSize) ?? 0
      if bytes > capacity { try? FileManager.default.removeItem(at: url) }
    }
  }
}
