import SwiftUI
import UniformTypeIdentifiers

struct MessageDetailView: View {
  @EnvironmentObject private var store: MailStore
  @Environment(\.dismiss) private var dismiss
  @Environment(\.scenePhase) private var phase
  @StateObject private var reader: MessageReader
  @State private var showMove = false
  @State private var confirmTrash = false
  @State private var allowRemoteImages = false
  @State private var selectedLink: URL?
  @State private var htmlError: String?
  @State private var composing: MailDraft?
  @Environment(\.openURL) private var openURL

  init(identity: MessageIdentity) {
    _reader = StateObject(wrappedValue: MessageReader(identity: identity))
  }
  private var linked: Bool {
    store.accounts.contains { $0.id == reader.identity.account && $0.mode == "proxy" }
  }
  private var actionsDisabled: Bool {
    reader.metadata == nil || reader.mutating || reader.transfer != nil || reader.loading
      || !reader.canMutate || !linked
  }

  var body: some View {
    List {
      if !linked || reader.invalidated {
        Text(reader.error ?? "邮箱访问权限已改变。请返回列表刷新。").foregroundStyle(.red)
        Button("返回并刷新列表") {
          store.mailboxChanged(reader.identity.account)
          dismiss()
        }
      } else {
        if reader.loading && reader.metadata == nil { ProgressView("正在读取邮件…") }
        if let error = reader.error { Text(error).font(.footnote).foregroundStyle(.secondary) }
        if let metadata = reader.metadata {
          MessageHeader(metadata: metadata, cached: reader.cached, syncing: reader.loading)
          bodySection(metadata)
          attachmentsSection(metadata)
          transferSection
        }
      }
    }
    .listStyle(.plain)
    .navigationTitle("邮件").navigationBarTitleDisplayMode(.inline)
    .toolbar { mailToolbar }
    .task(id: phase) {
      if phase == .active && linked {
        allowRemoteImages = false
        htmlError = nil
        await reader.open(using: store)
      } else if phase == .background {
        reader.stop(clear: true)
      }
    }
    .onChange(of: linked) { _, value in if !value { reader.stop(clear: true) } }
    .onDisappear { reader.stop(clear: true) }
    .alert(
      "打开邮件中的链接",
      isPresented: Binding(
        get: { selectedLink != nil }, set: { if !$0 { selectedLink = nil } })
    ) {
      if let url = selectedLink {
        Button("在浏览器中打开") {
          openURL(url)
          selectedLink = nil
        }
        Button("取消", role: .cancel) { selectedLink = nil }
      }
    } message: {
      Text(selectedLink?.absoluteString ?? "")
    }
    .confirmationDialog("将邮件移到垃圾箱？", isPresented: $confirmTrash, titleVisibility: .visible) {
      Button("移到垃圾箱", role: .destructive) { perform("trash") }
    }
    .sheet(isPresented: $showMove) {
      NavigationStack {
        List(reader.destinations) { folder in
          Button(folder.name) {
            showMove = false
            perform("move", destination: folder.path)
          }
        }.navigationTitle("移动到").toolbar { Button("取消") { showMove = false } }
      }
    }
    .sheet(item: $composing) { ComposeView(draft: $0) }
    .sheet(
      isPresented: Binding(
        get: { reader.exportURL != nil }, set: { if !$0 { reader.finishExport() } })
    ) {
      if let url = reader.exportURL { AttachmentExporter(url: url) { reader.finishExport() } }
    }
  }

  private func bodySection(_ metadata: MessageMetadata) -> some View {
    Section {
      if let body = metadata.body {
        if let document = reader.htmlDocument, body.contentType == "text/html" {
          if document.hasRemoteImages {
            VStack(alignment: .leading, spacing: 8) {
              Text(allowRemoteImages ? "已允许此邮件加载远程图片。" : "远程图片已阻止，加载后发件人可能获知你已阅读。")
                .font(.caption).foregroundStyle(.secondary)
              Button(allowRemoteImages ? "隐藏远程图片" : "加载远程图片") { allowRemoteImages.toggle() }
                .accessibilityIdentifier("remoteImages")
            }
          }
          HTMLMessageView(
            document: document, allowRemoteImages: allowRemoteImages,
            loadInline: { try await reader.inlineImage($0, using: store) },
            openLink: { selectedLink = $0 }, reportError: { htmlError = $0 }
          )
          .frame(height: 480)
          .id(reader.canMutate)
          if let htmlError { Text(htmlError).font(.caption).foregroundStyle(.secondary) }
        } else if body.contentType == "text/html" && reader.pageCount > 0
          && reader.htmlNotice == nil
        {
          ProgressView("正在排版邮件…")
        } else if reader.pageCount > 0 || reader.receivingPreview {
          if let notice = reader.htmlNotice {
            Text(notice).font(.caption).foregroundStyle(.secondary)
          }
          PlainTextView(text: reader.text).frame(minHeight: 180, maxHeight: 700)
            .accessibilityIdentifier("bodyText")
          if reader.receivingPreview {
            Label("正在接收正文…", systemImage: "arrow.down.circle").font(.caption).foregroundStyle(
              .secondary)
          }
          if reader.pageCount > 1 { pageControls }
          if reader.text.contains("\u{FFFD}") {
            Text("正文含有无法按 UTF-8 解码的字符。").font(.caption).foregroundStyle(.secondary)
          }
        } else if reader.transfer == nil {
          Button("加载正文") { reader.download(attachment: nil, using: store) }
        }
      } else {
        Text("此邮件没有可显示的文本正文。")
      }
    }.listRowSeparator(.hidden)
  }

  private var pageControls: some View {
    VStack(spacing: 12) {
      HStack {
        Button("上一段") { reader.showPage(reader.page - 1) }.disabled(reader.page == 0)
        Spacer()
        Text("\(reader.page + 1) / \(reader.pageCount)").font(.caption).accessibilityIdentifier(
          "bodyPage")
        Spacer()
        Button("下一段") { reader.showPage(reader.page + 1) }.disabled(
          reader.page + 1 >= reader.pageCount)
      }.buttonStyle(.borderless)
      if reader.pageCount > 2 { Button("跳到末段") { reader.showPage(reader.pageCount - 1) } }
    }
  }

  @ViewBuilder
  private func attachmentsSection(_ metadata: MessageMetadata) -> some View {
    if !metadata.attachments.isEmpty {
      Section("附件") {
        ForEach(metadata.attachments) { attachment in
          Button {
            reader.download(attachment: attachment, using: store)
          } label: {
            Label {
              VStack(alignment: .leading, spacing: 4) {
                Text(attachment.filename)
                Text(
                  "约 \(ByteCountFormatter.string(fromByteCount: attachment.size, countStyle: .file))"
                )
                .font(.caption).foregroundStyle(.secondary)
              }
            } icon: {
              Image(systemName: "arrow.down.doc")
            }
          }
          .disabled(reader.transfer != nil || reader.mutating)
          .accessibilityIdentifier("attachment-\(attachment.id)")
        }
      }
    }
  }

  @ViewBuilder private var transferSection: some View {
    if let name = reader.transfer {
      Section {
        ProgressView(
          "正在下载\(name)：\(ByteCountFormatter.string(fromByteCount: reader.received, countStyle: .file))"
        )
        Button("取消下载", role: .cancel) { reader.cancelDownload() }.accessibilityIdentifier(
          "cancelDownload")
      }
    }
  }

  @ToolbarContentBuilder private var mailToolbar: some ToolbarContent {
    ToolbarItem(placement: .topBarTrailing) {
      Button {
        Task { await reader.open(using: store) }
      } label: {
        Image(systemName: "arrow.clockwise")
      }
      .accessibilityLabel("刷新").accessibilityIdentifier("refreshDetail")
      .disabled(reader.mutating || !linked || reader.invalidated)
    }
    ToolbarItemGroup(placement: .bottomBar) {
      Group {
        Button {
          confirmTrash = true
        } label: {
          Image(systemName: "trash")
        }.accessibilityLabel("移到垃圾箱")
        Spacer()
        Button {
          Task {
            await reader.folders(using: store)
            showMove = !reader.destinations.isEmpty
          }
        } label: {
          Image(systemName: "folder")
        }.accessibilityLabel("移动到文件夹")
        Spacer()
        Button {
          perform("archive")
        } label: {
          Image(systemName: "archivebox")
        }.accessibilityLabel("归档")
        Spacer()
        Menu {
          if let metadata = reader.metadata {
            Button("回复") { compose("reply") }.accessibilityIdentifier("replyMessage")
            Button("回复全部") { compose("replyAll") }.accessibilityIdentifier("replyAllMessage")
            Button("转发") { compose("forward") }.accessibilityIdentifier("forwardMessage")
            Divider()
            Button((metadata.flags ?? []).contains("\\Seen") ? "标为未读" : "标为已读") {
              perform((metadata.flags ?? []).contains("\\Seen") ? "unread" : "read")
            }.accessibilityIdentifier("toggleRead")
            Button((metadata.flags ?? []).contains("\\Flagged") ? "取消旗标" : "添加旗标") {
              perform((metadata.flags ?? []).contains("\\Flagged") ? "unflag" : "flag")
            }.accessibilityIdentifier("toggleFlag")
          }
        } label: {
          Image(systemName: "ellipsis.circle")
        }.accessibilityLabel("更多操作")
      }.disabled(actionsDisabled)
    }
  }

  private func perform(_ action: String, destination: String? = nil) {
    Task { if await reader.mutate(action, destination: destination, using: store) { dismiss() } }
  }
  private func compose(_ kind: String) {
    guard let metadata = reader.metadata else { return }
    composing = MailDraft.response(
      kind: kind, identity: reader.identity, metadata: metadata,
      quote: reader.quote(), ownAddresses: store.accounts.map(\.email))
  }
}

private struct MessageHeader: View {
  let metadata: MessageMetadata
  let cached: Bool
  let syncing: Bool
  var body: some View {
    Section {
      VStack(alignment: .leading, spacing: 14) {
        Text(metadata.subject.isEmpty ? "（无主题）" : metadata.subject)
          .font(.title2).fontWeight(.bold).textSelection(.enabled)
        HStack(alignment: .top, spacing: 12) {
          Image(systemName: "person.crop.circle.fill").font(.system(size: 38)).foregroundStyle(
            .gray.opacity(0.35))
          VStack(alignment: .leading, spacing: 4) {
            Text(metadata.from).font(.subheadline).fontWeight(.semibold).textSelection(.enabled)
            Text("收件人：\(metadata.to)").font(.caption).foregroundStyle(.secondary)
            if let date = MailDate.parse(metadata.date) {
              Text(date.formatted(date: .abbreviated, time: .shortened)).font(.caption)
                .foregroundStyle(.secondary)
            }
          }
        }
        HStack(spacing: 8) {
          if !(metadata.flags ?? []).contains("\\Seen") {
            Label("未读", systemImage: "circle.fill").foregroundStyle(.blue)
          }
          if (metadata.flags ?? []).contains("\\Flagged") {
            Label("已加旗标", systemImage: "flag.fill").foregroundStyle(.orange)
          }
          if cached { Text(syncing ? "本机副本 · 正在同步" : "已保存正文").foregroundStyle(.secondary) }
        }.font(.caption)
      }.padding(.vertical, 8)
    }
  }
}
/// Literal text only: no HTML parsing, link detection, remote resources or scripts.
struct PlainTextView: UIViewRepresentable {
  let text: String
  func makeUIView(context: Context) -> UITextView {
    let view = UITextView()
    view.isEditable = false
    view.isSelectable = true
    view.dataDetectorTypes = []
    view.font = UIFont.preferredFont(forTextStyle: .body)
    view.adjustsFontForContentSizeCategory = true
    view.backgroundColor = .clear
    view.accessibilityIdentifier = "bodyText"
    return view
  }
  func sizeThatFits(_ proposal: ProposedViewSize, uiView: UITextView, context: Context) -> CGSize? {
    let width = proposal.width ?? 340
    let height = uiView.sizeThatFits(CGSize(width: width, height: .greatestFiniteMagnitude)).height
    return CGSize(width: width, height: min(700, max(180, height)))
  }
  func updateUIView(_ view: UITextView, context: Context) {
    if view.text != text {
      view.text = text
      view.setContentOffset(.zero, animated: false)
    }
  }
}

struct AttachmentExporter: UIViewControllerRepresentable {
  let url: URL
  let done: () -> Void
  func makeCoordinator() -> Coordinator { Coordinator(done: done) }
  func makeUIViewController(context: Context) -> UIDocumentPickerViewController {
    let picker = UIDocumentPickerViewController(forExporting: [url], asCopy: true)
    picker.delegate = context.coordinator
    return picker
  }
  func updateUIViewController(_ controller: UIDocumentPickerViewController, context: Context) {}
  final class Coordinator: NSObject, UIDocumentPickerDelegate {
    let done: () -> Void
    init(done: @escaping () -> Void) { self.done = done }
    func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) { done() }
    func documentPicker(
      _ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]
    ) { done() }
  }
}
