# Mohua iOS

原生 SwiftUI 最小客户端，最低 iOS 17，使用系统 URLSession 和 Keychain，无第三方 Swift 依赖。打开 `Mohua.xcodeproj`，选择 `Mohua` scheme。

## 当前范围

- 服务器地址、邀请注册和用户账号密码登录；设备凭据与地址一起存入 Keychain，使用 `WhenUnlockedThisDeviceOnly`，不存入 UserDefaults 或日志。
- 展示当前用户拥有的全部邮箱；proxy 邮箱可打开文件夹和 UID 分页列表；direct 邮箱明确显示尚未支持。
- 前台恢复时刷新用户邮箱配置与当前列表；下拉或工具栏可手动刷新。
- 401 返回登录页并清理本地凭据；403 清除当前受限列表；409 丢弃旧 UIDVALIDITY 和分页位置，要求重新加载。
- 稀疏 UID 的空页只要有 nextBefore 就能继续翻页。列表仅保存在当前视图内存中，没有持久邮件索引，也没有提前确认邮箱同步版本。
- 邮件详情独立读取元数据与正文流。纯文本正文在首批约 4 KiB 到达后先显示，后续以 32 KiB 缓冲写入临时文件，完成后按约 64 KiB 分段，支持上一段、下一段、跳到末段；UTF-8 跨段字符保持完整，没有固定 2 MiB 截断。正文下载完成后再次校验访问权限，完整且授权有效的正文才保存到缓存。
- 纯文本使用原生控件；HTML 使用清理后的 WKWebView 排版，禁用网页脚本、表单和嵌入页面，支持受权限校验的 CID 内嵌图片。远程 HTTPS 图片逐封手动加载，链接先展示地址再交给外部浏览器。
- 附件按需下载、可取消，完成后通过系统文件选择器导出；原始文件名经过路径分隔符和控制字符清理。
- 支持已读／未读、旗标、移动到指定文件夹、归档、移到垃圾箱。操作后重读元数据与列表；失败不自动重试，不提供永久删除。
- 退入后台时遮挡内容；正文缓存使用系统完整文件保护。尚未实现 Face ID 应用锁，也未完成真机锁屏验收。

当前支持纯文本写信、回复／回复全部、转发和文件附件；已接入可配置的静默 APNs 与后台摘要同步；不提供 OAuth 或手机直连。HTML 支持常见排版与内联样式；真机锁屏保护仍需验收。

## 连接开发服务器

1. 在项目根目录运行 `node scripts/configure.mjs`、`docker compose up -d --build --wait`。
2. 浏览器打开 `/`，创建并登录服务器管理员，在“用户管理”生成注册邀请。
3. 模拟器 Debug 构建可填写 `http://localhost:3210`。真机使用可达的 HTTPS 地址，或 Debug 下的 Mac `.local` 主机名；真机 localhost 指手机自身。
4. App 选择“使用邀请注册”，创建个人用户账号后登录。在 App 添加邮箱，通过“管理”更新密码、测试连接、设置监听、删除配置或管理设备。
5. 真机运行前，在 Xcode Signing & Capabilities 中选择开发团队，将占位 Bundle ID `com.mohua.app` 改为自己的唯一标识。

Release 只接受 HTTPS，Debug 仅允许 localhost、127.0.0.1 和 `.local` 的 HTTP。ATS 只在 Debug 打开本地网络例外，没有全局 `NSAllowsArbitraryLoads`。HTTP 重定向被拒绝，避免令牌传往其他地址。

“退出登录”会撤销服务器上的当前设备会话，并清理本地凭据。也可以在 App“管理”页撤销其他设备；不影响其余设备。设备令牌有效期 30 天，到期需要重新登录。

## 构建与 UI 联调

无需签名的模拟器构建：

```sh
xcodebuild -project ios/Mohua.xcodeproj -scheme Mohua \
  -configuration Debug -sdk iphonesimulator \
  -destination 'generic/platform=iOS Simulator' \
  -derivedDataPath /tmp/mohua-derived CODE_SIGNING_ALLOWED=NO build
```

UI 测试使用真实 HTTP API 和模拟 IMAP 数据，专用服务只监听本机 43210，数据库使用 `TEST_DATABASE_URL` 指向的独立 PostgreSQL schema，主密钥生成在临时目录。不会使用项目 `data/`，不会连接真实邮箱。测试服务有不带认证的 `/__test/` 控制接口，仅供本机自动测试，不能部署。

```sh
# 终端 1，项目根目录；先启动独立测试数据库
docker compose -f compose.test.yaml up -d --wait database
TEST_DATABASE_URL=postgres://mohua_test:local-disposable-test-only@127.0.0.1:54329/mohua_test node test/ios-fixture.mjs

# 终端 2：先用 xcrun simctl list devices available 查看本机设备名称
xcodebuild -project ios/Mohua.xcodeproj -scheme Mohua \
  -configuration Debug -destination 'platform=iOS Simulator,name=iPhone 18 Pro,OS=27.0' \
  -derivedDataPath /tmp/mohua-derived test
```

运行 UI 测试请保留 Xcode 默认的模拟器本地签名；不要添加 `CODE_SIGNING_ALLOWED=NO`，否则模拟器 App 可能无法访问 Keychain。上面的无签名命令仅用于编译检查。

测试覆盖登录、邮箱添加和删除、退出登录、邮箱与文件夹导航、Keychain 重启恢复、稀疏 UID 分页、UIDVALIDITY 改变及设备撤销，以及超过 3 MiB 正文的末尾、UTF-8 跨段字符、附件取消、已读／旗标和归档。测试结束后 Ctrl+C 停止 fixture，会自动清理临时数据库。测试只验证合成数据；真实邮箱、真机与生产部署仍需单独验收。

## 临时文件和已知边界

正文和附件的工作文件使用随机目录，设置 `NSFileProtectionComplete` 并排除备份。退出详情、退入后台、设备失效时清理，启动时也清理上次遗留文件；取消／失败会删除未完成的文件。系统文件选择器导出的副本归用户管理，不在清理范围内。模拟器测试不能代替真机锁屏与文件保护验收。

本版接收纯文本正文时先显示首段，完整下载到临时文件后支持逐段阅读，并将符合容量限制的完整正文缓存到手机。下载没有固定字节上限，但仍受可用磁盘和 10 分钟传输时限约束；纯文本显示内存不会随整封正文大小增长；HTML 排版只处理不超过 2 MiB 的完整正文，超限明确回退为分段源码。HTTP 流中断后移除未完成预览，不将残缺正文保存为缓存，操作响应中断时需要刷新核对实际状态。服务端正文及附件仍不落磁盘。

元数据接口新增可选 `flags` 字段，供 App 在操作后读取真实已读与旗标状态；其余协议保持兼容。已有受限磁盘列表索引，但没有全邮箱离线下载、Face ID 或自动续期。

## 最近验证

本轮结果见项目交接说明文末验证记录。测试仍使用隔离模拟邮件数据；真实邮箱、真机锁屏保护及生产部署未验收。

2026-09-22 本轮：6 项模拟器测试通过（2 项核心、4 项 UI，分两次运行），Debug / Release 构建通过。覆盖用户登录、邀请注册、邮箱添加/删除、设备重命名和撤销、退出登录以及邮件阅读回归。结果文件为 `/tmp/mohua-accounts-tests-2.xcresult` 和 `/tmp/mohua-registration-tests-4.xcresult`。

服务器无法连接时可在“管理”中选择“仅清除本机登录”返回登录页；该操作明确不会撤销服务器会话。普通“退出登录”仍要求服务端撤销成功，或确认会话已失效。逻辑设备 ID 与会话令牌分开保存在 Keychain，按服务器和用户区分；到期重登可更新原设备会话，但设备 ID 本身不提供认证能力。


## 邮箱导航与缓存

首页为邮箱总览，包含所有收件箱、各账号收件箱及文件夹入口。统一收件箱按时间合并各 proxy 邮箱，分页仍分别保留每个邮箱的 UIDVALIDITY 与游标。搜索及未读／旗标筛选只作用于已加载邮件，界面明确标注范围。

BodyCache 按服务器、设备和完整 IMAP 身份隔离；只保存完整正文和必要元数据，最多 50 MiB / 200 封 / 7 天，单封不超过 5 MiB。文件使用完整保护并排除备份。阅读时从缓存复制工作文件，因此容量淘汰不会破坏当前阅读。退出或确认会话失效清除缓存；移走邮件、邮箱移除也使相应缓存失效。

缓存命中先显示本机副本并同步最新状态；断网重启可恢复邮箱、文件夹及已保存列表，并继续查看缓存正文。服务器无法在设备离线时立即删除已下载内容，恢复联网确认撤销后才清理。

前台列表最多预取 3 封小正文（128 KiB），不提前下载附件，前台阅读优先。实际显示和完整下载速度受网络、邮件大小及服务商响应影响；测试证明首段提前出现和再次打开不重复下载，不代表真实网络下的固定耗时保证。

本次页面与缓存改造后，分批回归共 9 个不同 iOS 测试通过（4 个核心、5 个 UI）；Debug / Release 模拟器构建通过。后续修正的阅读测试与缓存测试见 `/tmp/mohua-redesign-tests-2.xcresult`，最终双邮箱统一收件箱、首段显示及缓存复用测试见 `/tmp/mohua-unified-inbox-tests.xcresult`。最终页面截图位于 `../docs/screenshots/`。

## HTML 阅读边界

HTMLDocument.swift 使用系统 libxml2（HTMLBridge.h）解析并生成标签／属性／内联样式白名单；不是用正则表达式删除脚本。HTMLMessageView.swift 负责非持久 WebKit、禁用 JavaScript、CSP、内容拦截、链接拦截及串行 CID 图片加载。解析最多 2 MiB、30000 节点、100 层，超限保留完整源码分段阅读。纯文本首段显示不受影响。

CID 只允许当前元数据中唯一匹配的 Content-ID，自动显示 PNG/JPEG/GIF/WebP，每张最多 5 MiB、最多 12 张、重编码后合计 15 MiB。通过 ImageIO 校验像素并缩小、重新编码为 PNG，动画只显示首帧。下载遵循已有设备与邮箱权限、UIDVALIDITY、重定向拒绝和退出清理规则。内嵌图片不进入正文缓存，离线只显示已缓存的正文排版。

远程图片默认阻止；用户允许后仅开放 HTTPS 图片，不开放远程脚本、样式、框架或表单。外部图片由手机直接加载，界面提示阅读隐私影响；不代表 Apple Mail 的隐私代理。重新进入页面或恢复前台时重置许可。HTML 固定在可滚动阅读区域内，邮件样式不能覆盖原生工具栏。

最新验收：iOS 完整回归 12/12 通过（`/tmp/mohua-html-tests-2.xcresult`）；最终核心与 HTML UI 补验 7/7 通过（`/tmp/mohua-html-final.xcresult`）。Debug / Release 构建通过。覆盖恶意标签／属性清理、CID 匹配、超限回退、HTML 排版、内嵌图片、远程图片开关、链接地址确认、缓存复用与撤销后清理；截图见 `../docs/screenshots/html-message.png`。尚未进行真实邮箱与真机验收。

WebKit API 依据：[网页脚本控制](https://developer.apple.com/documentation/webkit/wkwebpagepreferences/allowscontentjavascript)、[自定义资源加载](https://developer.apple.com/documentation/webkit/wkurlschemehandler)。

## 写信与发送恢复

首页和邮件列表底部提供“写邮件”；阅读页“更多操作”提供回复、回复全部和转发。发件人可选当前用户的 proxy 邮箱；回复／转发绑定原邮箱，“改为新邮件”可解除原邮件关联。

Draft.swift 负责草稿、收件人去重、引用及协议；DraftStore.swift 负责本机文件与附件上传拼接；ComposeModel.swift 负责自动保存和发送状态；ComposeView.swift 提供编辑及记录列表。草稿每次编辑后延迟 400 ms 保存，关闭及退入后台时立即尝试保存，失败有提示。文件完整保护、排除备份、按服务器和设备隔离，最多 100 条记录、附件合计 250 MiB。退出或会话失效后清除，无 IMAP 草稿或跨设备同步；已删除记录和退出后的迟到回调不能重建草稿。

发送前先落盘唯一请求键，准备后保存服务端 ID，上传前记录开始标记。恢复只查询原记录；准备响应丢失时用原键恢复，不提交附件。unknown、partial、sending 不自动重发，failed、expired 可返回编辑。prepared 的用户主动继续发送也先查询并使用同一记录。

附件通过系统文件选择器复制到草稿目录，以 64 KiB 分块拼接受保护临时文件后使用 URLSession 文件上传。支持 20 个文件、合计 25 MiB；正文 256 KiB。转发原邮件为 original.eml，引用正文最多 16000 字。仅纯文本编辑，无富文本编辑或通讯录补全。已发送副本由用户选择服务商保存或 Mohua 追加，副本失败不会触发重发。

写信定向验收：新增 3 个核心测试及 2 个 UI 测试通过；服务端既有发送相关 6 项通过。UI 结果为 `/tmp/mohua-compose-ui-2.xcresult`，最后删除保护与发送恢复补验为 `/tmp/mohua-compose-final.xcresult`。Debug / Release 编译通过，最终日志 `/tmp/mohua-compose-release-final.log`。没有重复运行完整旧回归；真实邮箱只做读取及 SMTP 认证，没有实际发信。原生文件选择器的完整 UI 操作仍待真机验收。

## 列表持久化与增量同步

MailIndex.swift 持久化邮箱／文件夹目录和按完整 IMAP 身份隔离的摘要快照，文件完整保护并排除备份。每文件夹保存最新 1000 条已加载摘要，所有文件夹快照合计最多 50 MiB，按同步时间淘汰；超过单文件夹上限时恢复正确的历史分页游标，仍可联网加载更早邮件。它不下载整个邮箱，也不改变正文缓存的容量和期限。

MailListModel 先显示本机列表，再 POST 文件夹 sync；新 UID 拉取 envelope，已知 UID 只核对 flags／存在性。每批最多 500 个已知 UID、1000 个新增 UID 范围；一次前台刷新最多推进 5000 个 UID 范围，有积压时显示“继续同步新邮件”。刷新保留已保存历史，分页另行向前加载。网络失败保留原列表与游标；成功才原子保存，两者不分开提交。UIDVALIDITY 改变自动清理该文件夹旧摘要及正文，再取新列表。

已读／旗标／移动的确认结果更新本机索引；其他设备或其他邮件客户端的变化在刷新／恢复前台时核对。目录刷新会移除已删除文件夹的本机数据；邮箱删除或转为 direct、设备撤销、退出均清理相应索引和正文。generation 防止清理前发出的网络响应重建旧索引。账号 revision 不用于跳过 IMAP 核对，也不会对部分列表发送整个账号的 ack。可由配置后的 APNs 静默提示触发限时同步，不在后台持续运行。

定向验收：服务端 reader 13 项、同步路由权限 1 项通过；新增 iOS 核心 2 项及离线重启／远端更新／UID 重建／撤销清理 UI 1 项通过。核心结果见 `/tmp/mohua-index-tests.log`，最终 UI 为 `/tmp/mohua-index-ui-final.xcresult`。初次 UI 仅因正文控件断言类型错误失败，修正后只重跑该场景，没有重复整套旧回归。

最终 Debug／Release 模拟器编译通过（Release 日志 `/tmp/mohua-index-release.log`）。页面留档：`docs/screenshots/offline-inbox.png` 和 `docs/screenshots/incremental-sync.png`（从 iOS 目录查看需加 `../`）。仅有既存 AppIntents 无依赖提示，无编译错误。

## 静默推送与后台更新

PushAppDelegate 持有唯一 MailStore，启动时恢复登录，注册真机 APNs token；PushProtocol 验证逻辑设备作用域并保证后台完成回调只调用一次。后台 25 秒截止，进入前台取消；锁定时保持完整数据保护并跳过工作。每次同步最多三个收件箱，轮换游标存入 MailIndex，重启后继续；不预取正文，不发送账号级 ack。账号管理新增状态检查和手动同步入口。

真机签名才使用 Push.entitlements。默认 Debug 为 development/sandbox，Release 为 production/production；部署需保证签名环境、Info 配置及服务器 topic 一致。模拟器不向 APNs 注册；本轮 UI 验收仅通过手动入口执行相同同步逻辑，没有声称 Apple 实际唤醒了 App。配置和限制见 [APNs 配置说明](../APNS_SETUP_ZH.md)。

新增 4 项核心及 1 项 UI 定向测试通过，结果 `/tmp/mohua-push-tests.xcresult`、`/tmp/mohua-push-final.xcresult`。真实 APNs 送达、锁屏／解锁和真机系统调度仍待 Apple 凭据、签名配置与真机验证。

最终 Debug／Release 模拟器编译通过；Release 日志 `/tmp/mohua-push-release.log`。后台更新页截图保存在项目 `docs/screenshots/background-updates.png`。仅有既存的 AppIntents 无依赖提示，无编译错误。

## 当前网关接入（覆盖上文直连 APNs 配置）

Server 不再配置 Apple 私钥。客户端构建设置 `MOHUA_GATEWAY_URL` 指向真实 HTTPS 网关根地址，与 Server 选定地址匹配后才能登记。未确定正式域名时保持为空。官方 App 不向 Server 提供的任意第三方地址发送设备 token；自定义网关需要配套构建。

“管理 → 后台更新 → 允许本设备通知”可开关，偏好按 Server 和设备保存。关闭后本机不处理推送，注销凭证通过 Keychain 队列等待联网重试；手动收件箱同步不受影响。登记挑战由 APNs 发给设备，投递凭证及独立注销凭证存储在 Keychain，只有投递凭证交给 Server。退出登录也会注销。

当前仍是静默更新，没有可见新邮件横幅。真实域名、签名和真机送达待配置后验证。部署见 `APNS_SETUP_ZH.md`。

本轮定向验证：网关来源信任核心测试、通知开关跨重启与 Server 同步 UI 测试通过；最终 UI 结果 `/tmp/mohua-gateway-toggle.xcresult`。Debug 模拟器和 Release 真机目标（未签名）编译通过。截图 `../docs/screenshots/device-notifications.png`。

多应用网关：Info plist 的 `MohuaGatewayAppID` 为 `mohua`；请求、APNs 校验和同步提示均校验应用 ID。其他 App 复用网关时须使用自己的 ID 和对应业务 Server，不通过界面随意切换应用身份。
