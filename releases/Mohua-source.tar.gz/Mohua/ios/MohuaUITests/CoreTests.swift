import XCTest

final class CoreTests: XCTestCase {
  @MainActor
  func testBackgroundInboxRotationSurvivesRestartAndStaysScoped() throws {
    let root = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
    defer { try? FileManager.default.removeItem(at: root) }
    let session = DeviceSession(
      server: URL(string: "https://example.com")!, token: "t", deviceId: "one",
      expires: .greatestFiniteMagnitude)
    let index = MailIndex(root: root)
    index.activate(session)
    try index.advanceInboxes(to: 3)
    let restored = MailIndex(root: root)
    restored.activate(session)
    XCTAssertEqual(restored.inboxOffset, 3)
    restored.activate(
      DeviceSession(server: session.server, token: "u", deviceId: "two", expires: session.expires))
    XCTAssertEqual(restored.inboxOffset, 0)
    restored.clear()
    XCTAssertThrowsError(try restored.advanceInboxes(to: 5))
  }

  func testGatewayTrustRejectsServerSelectedThirdParties() {
    let trusted = "https://push.example.com"
    XCTAssertTrue(MailPush.trusts(URL(string: trusted + "/")!, configured: trusted))
    for url in [
      "https://other.example.com", "http://push.example.com", "https://push.example.com:444",
      "https://user@push.example.com", "https://push.example.com/path",
      "https://push.example.com?token=secret",
    ] {
      XCTAssertFalse(MailPush.trusts(URL(string: url)!, configured: trusted))
    }
    XCTAssertFalse(MailPush.trusts(URL(string: trusted)!, configured: ""))
  }

  func testPushHintsAreScopedToCurrentDevice() {
    XCTAssertEqual(MailPush.appID, "mohua")
    let payload: [AnyHashable: Any] = [
      "aps": ["content-available": 1],
      "mohua": ["version": 1, "deviceId": "current"],
    ]
    XCTAssertTrue(MailPush.accepts(payload, device: "current"))
    XCTAssertFalse(
      MailPush.accepts(
        [
          "aps": ["content-available": 1],
          "mohua": ["version": 1, "deviceId": "current", "appId": "another-app"],
        ], device: "current"))
    XCTAssertFalse(MailPush.accepts(payload, device: "old"))
    XCTAssertFalse(MailPush.accepts(payload, device: nil))
    XCTAssertFalse(MailPush.accepts(["aps": ["content-available": 1]], device: "current"))
    XCTAssertFalse(
      MailPush.accepts(
        [
          "aps": ["content-available": 1],
          "mohua": ["version": 2, "deviceId": "current"],
        ], device: "current"))
  }

  @MainActor
  func testBackgroundDeadlineCancelsAndCompletesOnlyOnce() async {
    let completed = expectation(description: "Timeout completes")
    let cancelled = expectation(description: "Network work cancelled")
    let run = BackgroundRun<String>()
    var results: [String] = []
    XCTAssertTrue(
      run.start(
        timeout: .milliseconds(20), timeoutResult: "timeout",
        operation: {
          do { try await Task.sleep(for: .seconds(60)) } catch { cancelled.fulfill() }
          return "late"
        },
        completion: { result in
          results.append(result)
          completed.fulfill()
        }))
    XCTAssertFalse(
      run.start(
        timeoutResult: "another", operation: { "duplicate" },
        completion: { _ in XCTFail("Duplicate started") }))
    await fulfillment(of: [completed, cancelled], timeout: 2)
    run.cancel(result: "foreground")
    XCTAssertEqual(results, ["timeout"])
  }

  @MainActor
  func testBackgroundForegroundCancellationAllowsNextRun() async {
    let run = BackgroundRun<String>()
    var results: [String] = []
    run.start(
      timeoutResult: "timeout",
      operation: {
        try? await Task.sleep(for: .seconds(60))
        return "late"
      }, completion: { results.append($0) })
    run.cancel(result: "foreground")
    let completed = expectation(description: "Next run")
    run.start(
      timeoutResult: "timeout", operation: { "updated" },
      completion: {
        results.append($0)
        completed.fulfill()
      })
    await fulfillment(of: [completed], timeout: 2)
    XCTAssertEqual(results, ["foreground", "updated"])
  }

  func testIncrementalMergePreservesHistoryAndRemovesOnlyCheckedUIDs() throws {
    let summary: (Int) -> MailSummary = {
      MailSummary(uid: $0, size: 10, subject: "Mail", from: [], date: nil, flags: [])
    }
    var value = FolderSnapshot(
      account: "a", folder: "INBOX", uidValidity: "7", highWater: 100,
      nextBefore: 1, items: [summary(100), summary(90), summary(5)], syncedAt: Date())
    let delta = MailDelta(
      uidValidity: "7", highWater: 110, hasMore: false,
      items: [summary(105)], existing: [.init(uid: 100, flags: ["\\Seen", "\\Flagged"])])
    let removed = try value.merge(delta, known: [100, 90])
    XCTAssertEqual(removed, [90])
    XCTAssertEqual(value.items.map(\.uid), [105, 100, 5])
    XCTAssertEqual(value.items[1].flags, ["\\Seen", "\\Flagged"])
    XCTAssertEqual(value.highWater, 110)
    XCTAssertEqual(value.nextBefore, 1)
    XCTAssertThrowsError(
      try value.merge(
        MailDelta(
          uidValidity: "8", highWater: 111,
          hasMore: false, items: [], existing: []), known: []))
    XCTAssertEqual(value.highWater, 110)
  }

  @MainActor
  func testMailIndexColdStartBoundariesAndLateWrites() throws {
    let root = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
    defer { try? FileManager.default.removeItem(at: root) }
    let session = DeviceSession(
      server: URL(string: "https://example.com")!, token: "t",
      deviceId: "one", expires: .greatestFiniteMagnitude)
    let mailbox = try JSONDecoder().decode(
      Mailbox.self,
      from: Data(#"{"id":"a","email":"a@example.com","mode":"proxy"}"#.utf8))
    let index = MailIndex(root: root, itemLimit: 2)
    index.activate(session)
    try index.saveAccounts([mailbox])
    _ = try index.saveFolders(
      [MailFolder(path: "INBOX", name: "Inbox", specialUse: nil)], account: "a")
    let value = FolderSnapshot(
      account: "a", folder: "INBOX", uidValidity: "7", highWater: 10,
      nextBefore: nil,
      items: [10, 7, 2].map {
        MailSummary(uid: $0, size: 10, subject: "Private", from: [], date: nil, flags: [])
      }, syncedAt: Date())
    try index.save(value, ticket: index.generation)
    let reopened = MailIndex(root: root, itemLimit: 2)
    reopened.activate(session)
    XCTAssertEqual(reopened.accounts.first?.id, "a")
    XCTAssertEqual(reopened.folders("a").count, 1)
    let restored = try XCTUnwrap(reopened.snapshot(account: "a", folder: "INBOX"))
    XCTAssertEqual(restored.items.map(\.uid), [10, 7])
    XCTAssertEqual(restored.nextBefore, 7)
    XCTAssertEqual(restored.highWater, 10)
    let oldTicket = reopened.generation
    try reopened.update(
      MessageIdentity(account: "a", folder: "INBOX", uidValidity: "7", uid: 10), removed: true)
    XCTAssertThrowsError(try reopened.save(value, ticket: oldTicket))
    XCTAssertEqual(reopened.snapshot(account: "a", folder: "INBOX")?.items.map(\.uid), [7])
    reopened.activate(
      DeviceSession(server: session.server, token: "u", deviceId: "two", expires: session.expires))
    XCTAssertTrue(reopened.accounts.isEmpty)
    XCTAssertNil(reopened.snapshot(account: "a", folder: "INBOX"))
    reopened.activate(session)
    let accountTicket = reopened.generation
    try reopened.saveAccounts([])
    XCTAssertNil(reopened.snapshot(account: "a", folder: "INBOX"))
    XCTAssertThrowsError(try reopened.save(value, ticket: accountTicket))
    try reopened.saveAccounts([mailbox])
    XCTAssertNil(reopened.snapshot(account: "a", folder: "INBOX"))
    let logoutTicket = reopened.generation
    reopened.clear()
    XCTAssertThrowsError(try reopened.save(value, ticket: logoutTicket))
  }

  func testComposeRecipientsReplyAllAndPayloadLimits() throws {
    XCTAssertEqual(
      try MailDraft.recipients("one@example.com, ONE@example.com；two@example.com"),
      ["one@example.com", "two@example.com"])
    XCTAssertThrowsError(try MailDraft.recipients("not-an-address"))
    XCTAssertThrowsError(try MailDraft.recipients("bad\0@example.com"))
    let identity = MessageIdentity(account: "mailbox", folder: "INBOX", uidValidity: "7", uid: 4)
    let meta = MessageMetadata(
      uid: 4, uidValidity: "7", subject: "Topic", from: "Sender", to: "Me", date: nil, flags: [],
      body: nil, attachments: [],
      replyTo: [.init(name: nil, address: "sender@example.com")],
      toAddresses: [
        .init(name: nil, address: "me@example.com"), .init(name: nil, address: "team@example.com"),
      ],
      ccAddresses: [
        .init(name: nil, address: "TEAM@example.com"), .init(name: nil, address: "cc@example.com"),
      ])
    let reply = MailDraft.response(
      kind: "replyAll", identity: identity, metadata: meta, quote: "Original",
      ownAddresses: ["me@example.com"])
    XCTAssertEqual(reply.to, "sender@example.com, team@example.com")
    XCTAssertEqual(reply.cc, "cc@example.com")
    XCTAssertEqual(reply.bcc, "")
    XCTAssertEqual(reply.source?.uidValidity, "7")
    XCTAssertTrue(reply.text.contains("> Original"))
    let forward = MailDraft.response(
      kind: "forward", identity: identity, metadata: meta, quote: "Original", ownAddresses: [])
    XCTAssertEqual(forward.to, "")
    XCTAssertEqual(forward.subject, "Fwd: Topic")
    var draft = reply
    draft.text = String(repeating: "邮", count: 90000)
    XCTAssertThrowsError(try draft.payload())
    draft.text = "Hello"
    draft.attachments = [.init(filename: "too-large", size: 26 * 1024 * 1024)]
    XCTAssertThrowsError(try draft.payload())
    XCTAssertTrue(SendStatus(id: "id", state: "unknown").explanation.contains("不会自动重发"))
  }

  @MainActor
  func testDraftPersistenceScopeAndLateWriteAfterLogout() throws {
    let root = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
    defer { try? FileManager.default.removeItem(at: root) }
    let session = DeviceSession(
      server: URL(string: "https://example.com")!, token: "t", deviceId: "one",
      expires: .greatestFiniteMagnitude)
    let other = DeviceSession(
      server: session.server, token: "u", deviceId: "two", expires: session.expires)
    let drafts = DraftStore(root: root)
    drafts.activate(session)
    var draft = MailDraft(accountID: "mailbox", to: "to@example.com", text: "Private draft")
    draft.attempt = SendAttempt(
      status: .init(id: "server-id", state: "prepared"), uploadStarted: true)
    try drafts.save(draft, session: session)
    let reopened = DraftStore(root: root)
    reopened.activate(session)
    let restored = try XCTUnwrap(reopened.list(session: session).first)
    XCTAssertEqual(restored.attempt?.key, draft.attempt?.key)
    XCTAssertEqual(restored.attempt?.status?.id, "server-id")
    XCTAssertFalse(restored.editable)
    XCTAssertTrue(restored.attempt?.uploadStarted == true)
    reopened.activate(other)
    XCTAssertTrue(try reopened.list(session: other).isEmpty)
    XCTAssertThrowsError(try reopened.save(draft, session: session))
    try drafts.remove(draft, session: session)
    XCTAssertThrowsError(try drafts.save(draft, session: session))
    drafts.clear()
    XCTAssertThrowsError(try drafts.save(draft, session: session))
    drafts.activate(session)
    XCTAssertTrue(try drafts.list(session: session).isEmpty)
  }

  @MainActor
  func testDraftAttachmentCopyAndUploadFraming() async throws {
    let root = try TransferFiles.createDirectory()
    defer { try? FileManager.default.removeItem(at: root) }
    let session = DeviceSession(
      server: URL(string: "https://example.com")!, token: "t", deviceId: "device",
      expires: .greatestFiniteMagnitude)
    let store = DraftStore(root: root.appendingPathComponent("drafts"))
    store.activate(session)
    var draft = MailDraft(accountID: "account")
    let bytes = Data([0, 255, 10, 20, 30])
    let source = root.appendingPathComponent("source")
    try bytes.write(to: source)
    let staged = root.appendingPathComponent("staged")
    XCTAssertEqual(try DraftStore.copyFile(source, to: staged, maximum: 5), 5)
    let attachment = DraftAttachment(filename: "test.bin", size: 5)
    try store.keepAttachment(staged, attachment: attachment, draft: draft, session: session)
    draft.attachments = [attachment]
    try store.save(draft, session: session)
    let file = try await store.uploadFile(draft, session: session, directory: root)
    XCTAssertEqual(try Data(contentsOf: file), bytes)
    let empty = MailDraft(accountID: "account")
    let emptyUpload = try await store.uploadFile(empty, session: session, directory: root)
    XCTAssertEqual(try Data(contentsOf: emptyUpload).count, 0)
    XCTAssertThrowsError(
      try DraftStore.copyFile(source, to: root.appendingPathComponent("too-small"), maximum: 4))
  }
  func testHTMLSanitizerKeepsLayoutAndBlocksActiveContent() throws {
    let image = MailAttachment(
      id: 3, filename: "logo.png", size: 100, contentType: "image/png", contentId: "<logo@example>")
    let document = try HTMLDocument.parse(
      """
      <html><head><base href="https://evil.test"><meta http-equiv="refresh" content="0;url=https://evil.test"></head><body>
      <h1 onclick="alert(1)">你好 &amp; Hello</h1><table><tr><td style="color:red;background-image:url(https://evil.test);position:fixed">内容</td></tr></table>
      <script>SECRET_SCRIPT</script><iframe src="https://evil.test">SECRET_FRAME</iframe>
      <form action="https://evil.test"><input name="password"></form><svg onload="alert(1)"><foreignObject>SECRET_SVG</foreignObject></svg>
      <a href="jav&#x61;script:alert(1)">坏链接</a><a href="https://example.com/path?a=1&amp;b=2">正常链接</a>
      <img src="cid:logo%40example" onerror="alert(1)"><img src="https://images.example.com/p.png">
      <img src="file:///etc/passwd"><img src="data:image/svg+xml,xxx"><img src="http://images.example.com/p.png">
      </body></html>
      """, attachments: [image])
    XCTAssertTrue(document.markup.contains("<h1>你好 &amp; Hello</h1>"))
    XCTAssertTrue(document.markup.contains("<table>"))
    XCTAssertTrue(document.markup.contains("style=\"color:red\""))
    XCTAssertEqual(document.inlineIDs, [3])
    XCTAssertTrue(document.hasRemoteImages)
    for forbidden in [
      "onclick", "onerror", "SECRET_", "<script", "<iframe", "<form", "<svg", "<meta", "<base",
      "javascript:", "file:", "data:", "background-image", "position:",
    ] {
      XCTAssertFalse(document.markup.contains(forbidden), forbidden)
    }
    XCTAssertTrue(document.page(allowRemoteImages: false).contains("img-src mohua-image:;"))
    XCTAssertTrue(document.page(allowRemoteImages: true).contains("img-src mohua-image: https:;"))
    XCTAssertTrue(document.page(allowRemoteImages: true).contains("script-src 'none'"))
  }

  func testHTMLRejectsOversizeAndAmbiguousImagesAndUnsafeLinks() throws {
    XCTAssertThrowsError(
      try HTMLDocument.parse(
        String(repeating: "a", count: HTMLDocument.maximumBytes + 1), attachments: []))
    let first = MailAttachment(
      id: 1, filename: "a.png", size: 1, contentType: "image/png", contentId: "<same>")
    let second = MailAttachment(
      id: 2, filename: "b.png", size: 1, contentType: "image/png", contentId: "same")
    let document = try HTMLDocument.parse(
      "<p>保留</p><img src='cid:same'><img src='mohua-image://inline/1'>",
      attachments: [first, second])
    XCTAssertTrue(document.inlineIDs.isEmpty)
    XCTAssertFalse(document.markup.contains("mohua-image:"))
    for value in [
      "javascript:alert(1)", "file:///tmp/a", "https://user:secret@example.com",
      "https://example.com\n", "//example.com", "mohua-image://inline/1",
    ] {
      XCTAssertNil(HTMLDocument.externalURL(value), value)
    }
    XCTAssertEqual(HTMLDocument.externalURL("https://example.com")?.host, "example.com")
  }
  func testBodyPagingPreservesUTF8AcrossBoundariesAndBeyondTwoMiB() throws {
    let directory = try TransferFiles.createDirectory()
    defer { try? FileManager.default.removeItem(at: directory) }
    let text =
      String(repeating: "a", count: 65535) + "邮📫件" + String(repeating: "正文。", count: 400000) + "末尾"
    let url = directory.appendingPathComponent("body.txt")
    try Data(text.utf8).write(to: url, options: .completeFileProtection)
    let pager = try BodyPager(url: url)
    XCTAssertGreaterThan(pager.byteCount, 2 * 1024 * 1024)
    let reconstructed = try (0..<pager.pageCount).map { try pager.text(at: $0) }.joined()
    XCTAssertEqual(reconstructed, text)
    let attributes = try FileManager.default.attributesOfItem(atPath: url.path)
    if let protection = attributes[.protectionKey] as? String {
      XCTAssertEqual(protection, FileProtectionType.complete.rawValue)
    } else {
      #if !targetEnvironment(simulator)
        XCTFail("The device did not report complete file protection")
      #endif
    }
    XCTAssertEqual(TransferFiles.safeFilename("../../unsafe\nname.txt"), ".._.._unsafe_name.txt")
  }
  func testServerAddressRejectsCredentialsPathsAndPublicHTTP() throws {
    for invalid in [
      "http://example.com", "https://user:password@example.com", "https://example.com/api",
      "https://example.com?x=1", "file:///tmp/a",
    ] {
      XCTAssertThrowsError(try MailAPI.serverURL(invalid))
    }
    XCTAssertEqual(try MailAPI.serverURL(" https://example.com/ ").host, "example.com")
    #if DEBUG
      XCTAssertEqual(try MailAPI.serverURL("http://localhost:43210").port, 43210)
    #endif
    let request = try MailAPI().makeRequest(
      server: URL(string: "https://example.com")!,
      path: ["api", "accounts", "id", "messages"], token: "test-only",
      query: [URLQueryItem(name: "folder", value: "客户/A+B & C")])
    XCTAssertTrue(request.url!.absoluteString.contains("%2B"))
    XCTAssertEqual(
      URLComponents(url: request.url!, resolvingAgainstBaseURL: false)?.queryItems?.first?.value,
      "客户/A+B & C")
  }
  func testBodyCacheIsolationEvictionAndPurge() async throws {
    let root = FileManager.default.temporaryDirectory.appendingPathComponent(UUID().uuidString)
    defer { try? FileManager.default.removeItem(at: root) }
    try FileManager.default.createDirectory(at: root, withIntermediateDirectories: true)
    let body = root.appendingPathComponent("source.txt")
    try Data("cached body".utf8).write(to: body, options: .completeFileProtection)
    let cache = BodyCache(root: root.appendingPathComponent("cache"), capacity: 15, itemLimit: 15)
    let session = DeviceSession(
      server: URL(string: "https://mail.example.com")!, token: "t", deviceId: "phone",
      expires: .greatestFiniteMagnitude)
    let other = DeviceSession(
      server: session.server, token: "other", deviceId: "other-phone", expires: session.expires)
    let id = MessageIdentity(account: "a", folder: "INBOX", uidValidity: "7", uid: 1)
    let metadata = MessageMetadata(
      uid: 1, uidValidity: "7", subject: "Subject", from: "From", to: "To", date: nil,
      flags: [], body: .init(contentType: "text/plain"), attachments: [])
    let ticket = await cache.ticket()
    try await cache.save(id, session: session, metadata: metadata, body: body, ticket: ticket)
    let present = await cache.contains(id, session: session)
    let differentDevice = await cache.contains(id, session: other)
    let differentFolder = await cache.contains(
      MessageIdentity(account: "a", folder: "Archive", uidValidity: "7", uid: 1), session: session)
    let differentValidity = await cache.contains(
      MessageIdentity(account: "a", folder: "INBOX", uidValidity: "8", uid: 1), session: session)
    XCTAssertTrue(present)
    XCTAssertFalse(differentDevice)
    XCTAssertFalse(differentFolder)
    XCTAssertFalse(differentValidity)
    let value = try await cache.snapshot(id, session: session)
    let snapshot = try XCTUnwrap(value)
    defer { try? FileManager.default.removeItem(at: snapshot.directory) }
    XCTAssertEqual(try String(contentsOf: snapshot.body, encoding: .utf8), "cached body")
    let second = MessageIdentity(account: "a", folder: "INBOX", uidValidity: "7", uid: 2)
    let secondMetadata = MessageMetadata(
      uid: 2, uidValidity: "7", subject: "Second", from: "From", to: "To", date: nil,
      flags: [], body: .init(contentType: "text/plain"), attachments: [])
    try await cache.save(
      second, session: session, metadata: secondMetadata, body: body, ticket: ticket)
    let evicted = await cache.contains(id, session: session)
    XCTAssertFalse(evicted)
    // A reader's working copy survives eviction of the cache entry.
    XCTAssertEqual(try String(contentsOf: snapshot.body, encoding: .utf8), "cached body")
    await cache.clear()
    try await cache.save(id, session: session, metadata: metadata, body: body, ticket: ticket)
    let staleWrite = await cache.contains(id, session: session)
    XCTAssertFalse(staleWrite)
    let newTicket = await cache.ticket()
    try await cache.save(id, session: session, metadata: metadata, body: body, ticket: newTicket)
    await cache.retainAccounts([], session: session)
    let removedAccount = await cache.contains(id, session: session)
    XCTAssertFalse(removedAccount)
  }

  func testIncrementalPreviewDoesNotBreakUTF8() {
    let bytes = Data("正文📫".utf8)
    XCTAssertEqual(TransferFiles.completeUTF8Prefix(bytes), "正文📫")
    for trailing in 1...3 {
      XCTAssertEqual(TransferFiles.completeUTF8Prefix(bytes.dropLast(trailing)), "正文")
    }
  }

}
