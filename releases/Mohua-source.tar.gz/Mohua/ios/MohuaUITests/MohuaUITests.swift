import XCTest

final class MohuaUITests: XCTestCase {
  @MainActor
  func testDeviceNotificationPreferenceSurvivesRestart() async throws {
    continueAfterFailure = false
    _ = try await control("reset")
    let app = XCUIApplication()
    try await login(app)
    app.buttons["管理"].tap()
    let toggle = app.switches["deviceNotifications"]
    reveal(toggle, in: app)
    if toggle.value as? String == "0" {
      toggle.coordinate(withNormalizedOffset: CGVector(dx: 0.93, dy: 0.5)).tap()
    }
    toggle.coordinate(withNormalizedOffset: CGVector(dx: 0.93, dy: 0.5)).tap()
    XCTAssertTrue(app.staticTexts["本设备通知已关闭"].waitForExistence(timeout: 10))
    var stats = try await control("stats")
    for _ in 0..<20 where stats["notificationsEnabled"] as? Bool != false {
      try await Task.sleep(for: .milliseconds(200))
      stats = try await control("stats")
    }
    XCTAssertEqual(stats["notificationsEnabled"] as? Bool, false)
    app.terminate()
    app.launch()
    XCTAssertTrue(app.buttons["管理"].waitForExistence(timeout: 10))
    app.buttons["管理"].tap()
    reveal(toggle, in: app)
    XCTAssertEqual(toggle.value as? String, "0")
    capture(app, name: "Device notifications disabled")
    toggle.coordinate(withNormalizedOffset: CGVector(dx: 0.93, dy: 0.5)).tap()
    for _ in 0..<20 {
      stats = try await control("stats")
      if stats["notificationsEnabled"] as? Bool == true { break }
      try await Task.sleep(for: .milliseconds(200))
    }
    XCTAssertEqual(stats["notificationsEnabled"] as? Bool, true)
    _ = try await control("revoke")
  }

  @MainActor
  func testBackgroundSyncWorkerPersistsHeadersWithoutBodies() async throws {
    continueAfterFailure = false
    _ = try await control("reset")
    let app = XCUIApplication()
    try await login(app)
    _ = try await control("remote-change")
    app.buttons["管理"].tap()
    let sync = app.buttons["syncInboxes"]
    reveal(sync, in: app)
    sync.tap()
    XCTAssertTrue(app.staticTexts["本轮收件箱同步完成。"].waitForExistence(timeout: 15))
    let stats = try await control("stats")
    XCTAssertTrue((stats["bodyDownloads"] as? [String: Any] ?? [:]).isEmpty)
    capture(app, name: "Background update settings")
    app.terminate()
    _ = try await control("offline")
    app.launch()
    XCTAssertTrue(app.buttons["inbox-fixture-proxy"].waitForExistence(timeout: 10))
    app.buttons["inbox-fixture-proxy"].tap()
    XCTAssertTrue(app.buttons["message-503"].waitForExistence(timeout: 5))
    XCTAssertTrue((app.buttons["message-499"].value as? String ?? "").contains("已加旗标"))
    _ = try await control("online")
    _ = try await control("revoke")
    app.buttons["refreshMessages"].tap()
    XCTAssertTrue(app.textFields["serverAddress"].waitForExistence(timeout: 10))
  }

  @MainActor
  func testOfflineColdStartAndIncrementalRemoteChanges() async throws {
    continueAfterFailure = false
    _ = try await control("reset")
    let app = XCUIApplication()
    try await login(app)
    app.buttons["proxy@example.com"].tap()
    XCTAssertTrue(app.buttons["收件箱"].waitForExistence(timeout: 10))
    app.buttons["收件箱"].tap()
    XCTAssertTrue(app.buttons["message-450"].waitForExistence(timeout: 10))
    app.buttons["message-450"].tap()
    XCTAssertTrue(app.textViews["bodyText"].waitForExistence(timeout: 10))
    await waitForDownload(in: app)
    app.terminate()
    _ = try await control("offline")
    app.launch()
    XCTAssertTrue(app.buttons["proxy@example.com"].waitForExistence(timeout: 10))
    app.buttons["proxy@example.com"].tap()
    XCTAssertTrue(app.buttons["收件箱"].waitForExistence(timeout: 5))
    app.buttons["收件箱"].tap()
    XCTAssertTrue(app.buttons["message-450"].waitForExistence(timeout: 5))
    XCTAssertTrue(
      app.staticTexts.matching(NSPredicate(format: "label CONTAINS %@", "本机保存的列表")).firstMatch
        .waitForExistence(timeout: 10))
    capture(app, name: "Offline persisted inbox")
    app.buttons["message-450"].tap()
    XCTAssertTrue(app.textViews["bodyText"].waitForExistence(timeout: 10))
    XCTAssertTrue(
      (app.textViews["bodyText"].value as? String)?.contains("你好，这是一封提前同步到本机的邮件") == true)
    app.navigationBars.buttons.element(boundBy: 0).tap()
    _ = try await control("online")
    _ = try await control("remote-change")
    app.buttons["refreshMessages"].tap()
    XCTAssertTrue(app.buttons["message-503"].waitForExistence(timeout: 10))
    XCTAssertFalse(app.buttons["message-450"].exists)
    XCTAssertTrue((app.buttons["message-499"].value as? String ?? "").contains("已读"))
    XCTAssertTrue((app.buttons["message-499"].value as? String ?? "").contains("已加旗标"))
    capture(app, name: "Incremental remote changes")
    _ = try await control("new-epoch")
    app.buttons["refreshMessages"].tap()
    XCTAssertTrue(app.buttons["message-12"].waitForExistence(timeout: 10))
    XCTAssertFalse(app.buttons["message-503"].exists)
    _ = try await control("revoke")
    app.buttons["refreshMessages"].tap()
    XCTAssertTrue(app.textFields["serverAddress"].waitForExistence(timeout: 10))
    app.terminate()
    app.launch()
    XCTAssertTrue(app.textFields["serverAddress"].waitForExistence(timeout: 5))
    XCTAssertFalse(app.buttons["proxy@example.com"].exists)
  }

  @MainActor
  func testComposeDraftRecoveryAndLostSendResponse() async throws {
    continueAfterFailure = false
    _ = try await control("reset")
    let app = XCUIApplication()
    try await login(app)
    app.buttons["composeNew"].tap()
    XCTAssertTrue(app.textFields["composeTo"].waitForExistence(timeout: 5))
    app.textFields["composeTo"].tap()
    app.textFields["composeTo"].typeText("to@example.com")
    app.textFields["composeBcc"].tap()
    app.textFields["composeBcc"].typeText("hidden@example.com")
    app.textFields["composeSubject"].tap()
    app.textFields["composeSubject"].typeText("Draft recovery test")
    app.textViews["composeBody"].tap()
    app.textViews["composeBody"].typeText("Hello from a saved draft.")
    app.buttons["closeCompose"].tap()
    app.buttons["保存草稿"].tap()
    app.terminate()
    app.launch()
    XCTAssertTrue(app.buttons["drafts"].waitForExistence(timeout: 10))
    app.buttons["drafts"].tap()
    app.buttons.containing(.staticText, identifier: "Draft recovery test").firstMatch.tap()
    XCTAssertEqual(app.textFields["composeTo"].value as? String, "to@example.com")
    XCTAssertTrue((app.textViews["composeBody"].value as? String)?.contains("saved draft") == true)
    capture(app, name: "Compose saved draft")
    _ = try await control("drop-send-response")
    app.buttons["sendCompose"].tap()
    app.alerts.buttons["confirmSend"].firstMatch.tap()
    XCTAssertTrue(app.buttons["refreshSendStatus"].waitForExistence(timeout: 15))
    let ready = XCTNSPredicateExpectation(
      predicate: NSPredicate(format: "enabled == true"), object: app.buttons["refreshSendStatus"])
    await fulfillment(of: [ready], timeout: 20)
    app.buttons["closeCompose"].tap()
    app.terminate()
    app.launch()
    XCTAssertTrue(app.buttons["drafts"].waitForExistence(timeout: 10))
    app.buttons["drafts"].tap()
    app.buttons.containing(.staticText, identifier: "Draft recovery test").firstMatch.tap()
    app.buttons["refreshSendStatus"].tap()
    XCTAssertTrue(app.staticTexts["邮件已发送。"].waitForExistence(timeout: 10))
    let stats = try await control("stats")
    let messages = try XCTUnwrap(stats["sentMessages"] as? [[String: Any]])
    XCTAssertEqual(messages.count, 1)
    XCTAssertEqual(
      Set(messages[0]["to"] as? [String] ?? []), Set(["to@example.com", "hidden@example.com"]))
    XCTAssertEqual(messages[0]["bccHeader"] as? Bool, false)
    capture(app, name: "Recovered send receipt")
    XCTAssertFalse(app.buttons["sendCompose"].exists)
    app.buttons["closeCompose"].tap()
    app.navigationBars.buttons.element(boundBy: 0).tap()
    _ = try await control("revoke")
    app.buttons["refreshAccounts"].tap()
    XCTAssertTrue(app.textFields["serverAddress"].waitForExistence(timeout: 10))
  }

  @MainActor
  func testReplyAllForwardAndUncertainSendNeverRetries() async throws {
    continueAfterFailure = false
    _ = try await control("reset")
    let app = XCUIApplication()
    try await login(app)
    app.buttons["inbox-fixture-proxy"].tap()
    XCTAssertTrue(app.buttons["message-450"].waitForExistence(timeout: 10))
    app.buttons["message-450"].tap()
    await waitForDownload(in: app)
    app.buttons["更多操作"].tap()
    app.buttons["replyAllMessage"].tap()
    XCTAssertTrue(app.textFields["composeTo"].waitForExistence(timeout: 5))
    XCTAssertEqual(app.textFields["composeTo"].value as? String, "reply@example.com")
    XCTAssertEqual(app.textFields["composeCc"].value as? String, "team@example.com")
    app.buttons["sendCompose"].tap()
    app.alerts.buttons["confirmSend"].firstMatch.tap()
    XCTAssertTrue(app.staticTexts["邮件已发送。"].waitForExistence(timeout: 15))
    app.buttons["closeCompose"].tap()
    XCTAssertTrue(app.buttons["更多操作"].waitForExistence(timeout: 5))
    app.buttons["更多操作"].tap()
    app.buttons["forwardMessage"].tap()
    app.textFields["composeTo"].tap()
    app.textFields["composeTo"].typeText("forward@example.com")
    _ = try await control("uncertain-send")
    app.buttons["sendCompose"].tap()
    app.alerts.buttons["confirmSend"].firstMatch.tap()
    XCTAssertTrue(
      app.staticTexts.matching(NSPredicate(format: "label CONTAINS %@", "发送结果不确定")).firstMatch
        .waitForExistence(timeout: 15))
    app.buttons["refreshSendStatus"].tap()
    XCTAssertFalse(app.buttons["sendCompose"].exists)
    let stats = try await control("stats")
    let messages = try XCTUnwrap(stats["sentMessages"] as? [[String: Any]])
    XCTAssertEqual(messages.count, 2)
    XCTAssertEqual(messages[0]["inReplyTo"] as? String, "<fixture-450@example.com>")
    let attachments = try XCTUnwrap(messages[1]["attachments"] as? [[String: Any]])
    XCTAssertEqual(attachments.first?["name"] as? String, "original.eml")
    XCTAssertTrue(
      (attachments.first?["text"] as? String)?.contains("Original message content") == true)
    app.buttons["closeCompose"].tap()
    _ = try await control("revoke")
    app.buttons["refreshDetail"].tap()
    XCTAssertTrue(app.textFields["serverAddress"].waitForExistence(timeout: 10))
  }
  @MainActor
  func testHTMLReadingInlineImagesAndExternalLinkControl() async throws {
    continueAfterFailure = false
    _ = try await control("reset")
    _ = try await control("html-mail")
    let app = XCUIApplication()
    try await login(app)
    app.buttons["inbox-fixture-proxy"].tap()
    XCTAssertTrue(app.buttons["message-450"].waitForExistence(timeout: 10))
    app.buttons["message-450"].tap()
    XCTAssertTrue(app.webViews["htmlBody"].waitForExistence(timeout: 15))
    XCTAssertTrue(app.webViews.staticTexts["欢迎阅读 HTML 邮件"].waitForExistence(timeout: 10))
    XCTAssertFalse(app.staticTexts["SCRIPT_EXECUTED"].exists)
    XCTAssertFalse(app.textFields["不应出现的表单"].exists)
    XCTAssertTrue(app.buttons["加载远程图片"].exists)
    let inlineLoaded = XCTNSPredicateExpectation(
      predicate: NSPredicate { _, _ in
        app.webViews.images["邮件内嵌图片"].exists
      }, object: nil)
    await fulfillment(of: [inlineLoaded], timeout: 10)
    let stats = try await control("stats")
    XCTAssertEqual(stats["inlineDownloads"] as? Int, 1)
    XCTAssertFalse(app.staticTexts["部分内嵌图片未能加载，可刷新重试或从附件查看。"].exists)
    capture(app, name: "HTML mail with private images")
    app.webViews.links["查看邮件详情"].tap()
    XCTAssertTrue(app.buttons["在浏览器中打开"].waitForExistence(timeout: 5))
    XCTAssertTrue(app.staticTexts["https://example.com/mail-details"].exists)
    app.buttons["取消"].tap()
    app.buttons["remoteImages"].tap()
    XCTAssertTrue(app.buttons["隐藏远程图片"].waitForExistence(timeout: 5))
    app.buttons["remoteImages"].tap()
    XCTAssertTrue(app.buttons["加载远程图片"].waitForExistence(timeout: 5))
    app.navigationBars.buttons.element(boundBy: 0).tap()
    app.buttons["message-450"].tap()
    XCTAssertTrue(app.buttons["加载远程图片"].waitForExistence(timeout: 10))
    XCTAssertTrue(app.webViews.staticTexts["欢迎阅读 HTML 邮件"].waitForExistence(timeout: 10))
    let reopened = try await control("stats")
    XCTAssertEqual(
      (reopened["bodyDownloads"] as? [String: Int])?["450"],
      (stats["bodyDownloads"] as? [String: Int])?["450"])
    _ = try await control("revoke")
    app.buttons["refreshDetail"].tap()
    XCTAssertTrue(app.textFields["serverAddress"].waitForExistence(timeout: 10))
    XCTAssertFalse(app.webViews["htmlBody"].exists)
  }
  @MainActor
  func testLoginPersistencePaginationAndRevocation() async throws {
    continueAfterFailure = false
    _ = try await control("reset")
    let app = XCUIApplication()
    try await login(app)
    XCTAssertTrue(app.buttons["proxy@example.com"].waitForExistence(timeout: 10))
    XCTAssertTrue(app.staticTexts["直连模式尚未支持"].exists)
    // Relaunch verifies the token survives in Keychain without entering a password again.
    app.terminate()
    app.launch()
    XCTAssertTrue(app.buttons["proxy@example.com"].waitForExistence(timeout: 10))
    app.buttons["proxy@example.com"].tap()
    XCTAssertTrue(app.buttons["收件箱"].waitForExistence(timeout: 10))
    app.buttons["收件箱"].tap()
    XCTAssertTrue(app.staticTexts["测试邮件 499"].waitForExistence(timeout: 10))
    app.buttons["加载下一页"].tap()
    XCTAssertTrue(app.buttons["加载下一页"].waitForExistence(timeout: 10))
    app.buttons["加载下一页"].tap()
    XCTAssertTrue(app.staticTexts["稀疏分页末尾"].waitForExistence(timeout: 10))
    // Refresh preserves loaded history; a new UID epoch rebuilds automatically.
    _ = try await control("uidvalidity")
    app.buttons["refreshMessages"].tap()
    XCTAssertTrue(app.buttons["加载下一页"].waitForExistence(timeout: 10))
    XCTAssertTrue(app.staticTexts["测试邮件 499"].exists)
    // 401 clears the local session and returns to login.
    _ = try await control("revoke")
    app.buttons["refreshMessages"].tap()
    XCTAssertTrue(app.textFields["serverAddress"].waitForExistence(timeout: 10))
    XCTAssertTrue(app.staticTexts["设备已失效或被撤销，请重新登录。"].exists)
  }

  @MainActor
  func testReadingLargeBodyAttachmentCancellationAndMailActions() async throws {
    continueAfterFailure = false
    _ = try await control("reset")
    let app = XCUIApplication()
    try await login(app)
    XCTAssertTrue(app.buttons["proxy@example.com"].waitForExistence(timeout: 10))
    app.buttons["proxy@example.com"].tap()
    XCTAssertTrue(app.buttons["收件箱"].waitForExistence(timeout: 10))
    app.buttons["收件箱"].tap()
    XCTAssertTrue(app.buttons["message-499"].waitForExistence(timeout: 10))
    app.buttons["message-499"].tap()
    XCTAssertTrue(app.textViews["bodyText"].waitForExistence(timeout: 60))
    XCTAssertTrue((app.textViews["bodyText"].value as? String)?.contains("正文开头验证") == true)
    await waitForDownload(in: app)
    reveal(app.buttons["跳到末段"], in: app)
    app.buttons["跳到末段"].tap()
    XCTAssertTrue((app.textViews["bodyText"].value as? String)?.contains("正文末尾验证") == true)
    // The server produces > 3 MiB; the last marker proves there is no old 2 MiB truncation.
    let shot = XCTAttachment(screenshot: app.screenshot())
    shot.name = "Large mail body"
    shot.lifetime = .keepAlways
    add(shot)
    reveal(app.buttons["attachment-0"], in: app)
    app.buttons["attachment-0"].tap()
    XCTAssertTrue(app.buttons["cancelDownload"].waitForExistence(timeout: 5))
    reveal(app.buttons["cancelDownload"], in: app)
    app.buttons["cancelDownload"].tap()
    XCTAssertFalse(app.buttons["cancelDownload"].exists)
    let stats = try await control("stats")
    XCTAssertGreaterThan(stats["cancelledDownloads"] as? Int ?? 0, 0)
    app.buttons["更多操作"].tap()
    app.buttons["toggleRead"].tap()
    app.buttons["更多操作"].tap()
    XCTAssertTrue(app.buttons["标为未读"].waitForExistence(timeout: 10))
    app.buttons["toggleFlag"].tap()
    app.buttons["更多操作"].tap()
    XCTAssertTrue(app.buttons["取消旗标"].waitForExistence(timeout: 10))
    app.tap()
    let flags = try await control("stats")
    XCTAssertEqual(Set(flags["flags"] as? [String] ?? []), Set(["\\Seen", "\\Flagged"]))
    app.buttons["归档"].tap()
    XCTAssertTrue(app.buttons["message-450"].waitForExistence(timeout: 10))
    XCTAssertFalse(app.buttons["message-499"].exists)
    let moved = try await control("stats")
    XCTAssertEqual(moved["archive"] as? [Int], [499])
    _ = try await control("revoke")
    app.buttons["refreshMessages"].tap()
    XCTAssertTrue(app.textFields["serverAddress"].waitForExistence(timeout: 10))
  }

  @MainActor
  func testMailboxManagementAndLogout() async throws {
    continueAfterFailure = false
    _ = try await control("reset")
    let app = XCUIApplication()
    try await login(app)
    XCTAssertTrue(app.buttons["管理"].waitForExistence(timeout: 10))
    app.buttons["管理"].tap()
    XCTAssertTrue(app.staticTexts["当前设备"].waitForExistence(timeout: 10))
    app.buttons["添加邮箱"].tap()
    for (field, value) in [
      ("mailboxEmail", "added@example.com"), ("imapHost", "imap.example.com"),
      ("smtpHost", "smtp.example.com"),
    ] {
      let input = app.textFields[field]
      input.tap()
      input.typeText(value)
    }
    let secret = app.secureTextFields["mailboxCredential"]
    secret.tap()
    secret.typeText("app-password")
    app.buttons["saveMailbox"].tap()
    XCTAssertTrue(app.buttons["added@example.com"].waitForExistence(timeout: 10))
    app.buttons["added@example.com"].tap()
    reveal(app.buttons["删除邮箱配置"], in: app)
    app.buttons["删除邮箱配置"].tap()
    app.sheets.buttons["删除邮箱配置"].tap()
    XCTAssertTrue(app.buttons["添加邮箱"].waitForExistence(timeout: 10))
    XCTAssertFalse(app.buttons["added@example.com"].exists)
    reveal(app.buttons["退出登录"], in: app)
    app.buttons["退出登录"].tap()
    app.sheets.buttons["退出登录"].tap()
    XCTAssertTrue(app.textFields["serverAddress"].waitForExistence(timeout: 10))
  }

  @MainActor
  func testRegistrationInvitation() async throws {
    continueAfterFailure = false
    _ = try await control("reset")
    let app = XCUIApplication()
    app.launch()
    XCTAssertTrue(app.textFields["serverAddress"].waitForExistence(timeout: 15))
    app.buttons["使用邀请注册"].tap()
    for (field, value) in [
      ("serverAddress", "http://localhost:43210"),
      ("loginEmail", "invited-\(UUID().uuidString.prefix(8))@example.com"),
      ("registrationInvite", "fixture-invitation"),
    ] {
      let input = app.textFields[field]
      input.tap()
      input.typeText(value)
    }
    let password = app.secureTextFields["loginPassword"]
    password.tap()
    // The simulator is not signed into Passwords; enter a test password manually.
    let closePasswordSuggestion = app.buttons["Close"]
    if closePasswordSuggestion.waitForExistence(timeout: 2) { closePasswordSuggestion.tap() }
    password.typeText("new-user-password-123")
    if closePasswordSuggestion.waitForExistence(timeout: 2) {
      closePasswordSuggestion.tap()
      password.typeText(String(repeating: XCUIKeyboardKey.delete.rawValue, count: 30))
      password.typeText("new-user-password-123")
    }
    XCTAssertTrue(app.buttons["submitLogin"].isEnabled)
    app.buttons["submitLogin"].tap()
    XCTAssertTrue(app.staticTexts["账号已创建，请登录。"].waitForExistence(timeout: 10))
    app.buttons["submitLogin"].tap()
    XCTAssertTrue(app.buttons["添加第一个邮箱"].waitForExistence(timeout: 10))
    app.buttons["管理"].tap()
    XCTAssertTrue(app.staticTexts["当前设备"].waitForExistence(timeout: 10))
    app.buttons["重命名"].tap()
    let name = app.alerts.textFields.firstMatch
    name.tap()
    name.typeText(" Registered")
    app.alerts.buttons["保存"].tap()
    XCTAssertTrue(
      app.staticTexts.matching(NSPredicate(format: "label ENDSWITH %@", "Registered")).firstMatch
        .waitForExistence(timeout: 10))
    app.buttons["退出登录"].tap()
    app.sheets.buttons["退出登录"].tap()
    XCTAssertTrue(app.textFields["serverAddress"].waitForExistence(timeout: 10))
  }

  @MainActor
  func testUnifiedInboxProgressiveBodyAndCache() async throws {
    continueAfterFailure = false
    _ = try await control("reset")
    _ = try await control("slow-body")
    _ = try await control("second-mailbox")
    let app = XCUIApplication()
    try await login(app)
    capture(app, name: "Mailboxes overview")
    app.buttons["allInboxes"].tap()
    XCTAssertTrue(app.buttons["message-fixture-proxy-499"].waitForExistence(timeout: 10))
    XCTAssertTrue(app.buttons["message-fixture-second-499"].waitForExistence(timeout: 10))
    capture(app, name: "All inboxes")
    app.buttons["message-fixture-proxy-499"].tap()
    XCTAssertTrue(app.textViews["bodyText"].waitForExistence(timeout: 5))
    XCTAssertTrue((app.textViews["bodyText"].value as? String)?.contains("正文开头验证") == true)
    let receiving = try await control("stats")
    XCTAssertNil((receiving["bodyCompleted"] as? [String: Bool])?["499"])
    await waitForDownload(in: app)
    capture(app, name: "Message reading")
    let before = try await control("stats")
    let downloads = (before["bodyDownloads"] as? [String: Int])?["499"]
    app.navigationBars.buttons.element(boundBy: 0).tap()
    XCTAssertTrue(app.buttons["message-fixture-proxy-499"].waitForExistence(timeout: 10))
    app.buttons["message-fixture-proxy-499"].tap()
    XCTAssertTrue(app.textViews["bodyText"].waitForExistence(timeout: 5))
    XCTAssertTrue(app.staticTexts["已保存正文"].waitForExistence(timeout: 10))
    let after = try await control("stats")
    XCTAssertEqual((after["bodyDownloads"] as? [String: Int])?["499"], downloads)
    app.navigationBars.buttons.element(boundBy: 0).tap()
    let small = app.buttons["message-fixture-proxy-450"]
    reveal(small, in: app)
    small.tap()
    XCTAssertTrue(app.textViews["bodyText"].waitForExistence(timeout: 10))
    capture(app, name: "Cached message reading")
    _ = try await control("revoke")
    app.buttons["refreshDetail"].tap()
    XCTAssertTrue(app.textFields["serverAddress"].waitForExistence(timeout: 10))
  }

  @MainActor
  private func waitForDownload(in app: XCUIApplication) async {
    let ready = XCTNSPredicateExpectation(
      predicate: NSPredicate(format: "enabled == true"),
      object: app.buttons["更多操作"])
    await fulfillment(of: [ready], timeout: 20)
  }

  @MainActor
  private func capture(_ app: XCUIApplication, name: String) {
    let attachment = XCTAttachment(screenshot: app.screenshot())
    attachment.name = name
    attachment.lifetime = .keepAlways
    add(attachment)
  }

  @MainActor
  private func login(_ app: XCUIApplication) async throws {
    app.launch()
    if app.buttons["管理"].waitForExistence(timeout: 3) {
      app.buttons["管理"].tap()
      let local = app.buttons["仅清除本机登录"]
      if !app.textFields["serverAddress"].waitForExistence(timeout: 2) {
        reveal(local, in: app)
        local.tap()
        app.sheets.buttons["清除本机登录"].tap()
      }
    }
    let server = app.textFields["serverAddress"]
    XCTAssertTrue(server.waitForExistence(timeout: 15))
    server.tap()
    server.typeText("http://localhost:43210")
    let email = app.textFields["loginEmail"]
    email.tap()
    email.typeText("owner@example.com")
    let password = app.secureTextFields["loginPassword"]
    password.tap()
    password.typeText("fixture-password-123")
    app.buttons["submitLogin"].tap()
    XCTAssertTrue(app.buttons["refreshAccounts"].waitForExistence(timeout: 10))
  }

  @MainActor
  private func reveal(_ element: XCUIElement, in app: XCUIApplication) {
    for _ in 0..<6 {
      if element.isHittable { return }
      app.coordinate(withNormalizedOffset: CGVector(dx: 0.97, dy: 0.8))
        .press(
          forDuration: 0.05,
          thenDragTo: app.coordinate(withNormalizedOffset: CGVector(dx: 0.97, dy: 0.25)))
    }
    XCTAssertTrue(element.isHittable)
  }

  private func control(_ action: String) async throws -> [String: Any] {
    var request = URLRequest(url: URL(string: "http://localhost:43210/__test/\(action)")!)
    request.httpMethod = "POST"
    let (data, response) = try await URLSession.shared.data(for: request)
    XCTAssertEqual((response as? HTTPURLResponse)?.statusCode, 200)
    return try XCTUnwrap(JSONSerialization.jsonObject(with: data) as? [String: Any])
  }
}
