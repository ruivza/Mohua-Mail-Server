let bearer = "",
  me,
  health,
  poll,
  busy = false,
  epoch = 0;
const $ = (id) => document.getElementById(id),
  message = (text) => {
    $("message").textContent = text;
  };
const labels = {
  ok: "正常",
  error: "失败",
  external_error: "外部连接异常",
  unknown: "未知",
  running: "进行中",
};
const stages = {
  account: "准备测试账号",
  smtp_connect: "连接 SMTP",
  smtp_submit: "提交测试邮件",
  imap_connect: "连接 IMAP",
  imap_read: "读取并核对",
  cleanup: "清理测试邮件",
  complete: "完成",
  interrupted: "服务重启中断",
};
const time = (t) => new Date(t).toLocaleString();
async function api(path, method = "GET", data) {
  const response = await fetch("/api" + path, {
    method,
    headers: {
      ...(bearer ? { Authorization: "Bearer " + bearer } : {}),
      ...(data ? { "Content-Type": "application/json" } : {}),
    },
    body: data ? JSON.stringify(data) : undefined,
  });
  const body = await response.json();
  if (!response.ok) {
    if (response.status === 401) lock();
    throw Error(body.error);
  }
  return body;
}
function lock() {
  epoch++;
  clearInterval(poll);
  bearer = "";
  me = null;
  health = null;
  pushConfig = null;
  $("push-settings").reset();
  $("push-result").textContent = "";
  $("auth-shell").hidden = false;
  $("connection-state").textContent = "等待登录";
  $("connection-state").classList.remove("connected");
  route();
  $("dashboard").hidden = true;
  $("logout").hidden = true;
  for (const id of [
    "cards",
    "latest-run",
    "status-bars",
    "runs",
    "user-list",
    "devices",
    "invitation",
  ])
    $(id).replaceChildren();
}
function row(container, title, subtitle, label, action) {
  const e = document.createElement("div");
  e.className = "row";
  const text = document.createElement("div");
  text.textContent = title;
  const hint = document.createElement("small");
  hint.textContent = subtitle;
  text.append(hint);
  e.append(text);
  if (action) {
    const b = document.createElement("button");
    b.textContent = label;
    b.onclick = async () => {
      b.disabled = true;
      try {
        await action();
      } catch (err) {
        message(err.message);
      } finally {
        b.disabled = false;
      }
    };
    e.append(b);
  }
  container.append(e);
}
function route() {
  let page = location.hash.slice(1) || "overview";
  if (!["overview", "status", "users", "settings"].includes(page))
    page = "overview";
  if (me && me.role !== "admin") page = "settings";
  document
    .querySelectorAll(".page")
    .forEach((el) => (el.hidden = el.id !== page));
  document.querySelectorAll("nav a").forEach((a) => {
    a.classList.toggle("active", a.hash === "#" + page);
    if (a.hash === "#" + page) a.setAttribute("aria-current", "page");
    else a.removeAttribute("aria-current");
    a.hidden = !!me && me.role !== "admin" && a.hash !== "#settings";
  });
  $("schedule-section").hidden = me?.role !== "admin";
  $("page-title").textContent = {
    overview: "服务概览",
    status: "运行状态",
    users: "用户管理",
    settings: "设置与会话",
  }[page];
  if (!me) $("page-title").textContent = "欢迎来到 Mohua";
}
window.addEventListener("hashchange", route);
function bars(target) {
  target.replaceChildren();
  for (const [key, name] of [
    ["api", "API 进程心跳"],
    ["db", "数据库读写"],
    ["worker", "后台调度心跳"],
    ["mail", "外部邮件链路"],
  ]) {
    const wrap = document.createElement("div");
    wrap.className = "service-bar";
    const title = document.createElement("strong");
    title.textContent = name;
    wrap.append(title);
    const bar = document.createElement("div");
    bar.className = "uptime";
    const width = 30 * 60000,
      end = Math.ceil(health.now / width) * width;
    for (let i = 0; i < 48; i++) {
      const from = end - (48 - i) * width,
        to = from + width;
      const records = (key === "mail" ? health.runs : health.samples).filter(
        (r) => (r.started ?? r.at) >= from && (r.started ?? r.at) < to,
      );
      let state = "unknown";
      if (records.length) {
        const states = records.map((r) => (key === "mail" ? r.status : r[key]));
        state = states.includes("error")
          ? "error"
          : states.includes("external_error")
            ? "external_error"
            : states.includes("running")
              ? "running"
              : states.every((s) => s === "ok")
                ? "ok"
                : "unknown";
      }
      const cell = document.createElement("button");
      cell.className = "cell " + state;
      cell.title =
        time(from) +
        " — " +
        time(to) +
        " · " +
        labels[state] +
        " · " +
        records.length +
        " 次采样";
      cell.setAttribute("aria-label", cell.title);
      cell.onclick = () => message(cell.title);
      bar.append(cell);
    }
    wrap.append(bar);
    target.append(wrap);
  }
}
function chart(id, field) {
  const target = $(id);
  target.replaceChildren();
  const points = health.samples;
  if (!points.length) {
    target.textContent = "等待采样";
    return;
  }
  const max = Math.max(1, ...points.map((p) => p[field]));
  const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  svg.setAttribute("viewBox", "0 0 500 110");
  svg.setAttribute("role", "img");
  svg.setAttribute("aria-label", field + " 最近24小时趋势，最高 " + max);
  let segment = [];
  const draw = () => {
    if (!segment.length) return;
    const line = document.createElementNS(svg.namespaceURI, "polyline");
    line.setAttribute("points", segment.join(" "));
    line.setAttribute("fill", "none");
    line.setAttribute("stroke", "#398767");
    line.setAttribute("stroke-width", "2");
    svg.append(line);
    segment = [];
  };
  points.forEach((p, i) => {
    if (i && p.at - points[i - 1].at > 150000) draw();
    const x = 5 + ((p.at - (health.now - 86400000)) / 86400000) * 490,
      y = 100 - (p[field] / max) * 90;
    segment.push(x + "," + y);
    const dot = document.createElementNS(svg.namespaceURI, "circle");
    dot.setAttribute("cx", x);
    dot.setAttribute("cy", y);
    dot.setAttribute("r", "2");
    dot.setAttribute("fill", "#398767");
    svg.append(dot);
  });
  draw();
  target.append(svg);
  const p = document.createElement("p");
  p.textContent =
    "当前 " + points.at(-1)[field] + " · 最高 " + max + " · 空缺表示无数据";
  target.append(p);
}
function renderHealth() {
  const latest = health.latest;
  $("updated-at").textContent = "更新于 " + new Date(health.now).toLocaleTimeString();
  $("cards").replaceChildren();
  for (const [title, value, sub] of [
    [
      "托管用户",
      health.counts.users + " 位",
      "启用 " + health.counts.activeUsers + " 位",
    ],
    [
      "托管邮箱",
      health.counts.mailboxes + " 个",
      "已添加的邮箱配置 · 不含自检账号",
    ],
    [
      "运行时间",
      Math.floor(health.uptimeSeconds / 60) + " 分钟",
      "当前进程 · Server v0.8.0",
    ],
    ["进程资源", latest.memory + " MB", "CPU " + latest.cpu + "%"],
  ]) {
    const card = document.createElement("section");
    const s = document.createElement("small");
    s.textContent = title;
    const h = document.createElement("h2");
    h.textContent = value;
    const p = document.createElement("p");
    p.textContent = sub;
    card.append(s, h, p);
    $("cards").append(card);
  }
  bars($("status-bars"));
  chart("memory-chart", "memory");
  chart("cpu-chart", "cpu");
  const last = health.runs[0];
  $("latest-run").textContent = last
    ? labels[last.status] +
      " · " +
      stages[last.stage] +
      " · " +
      time(last.started)
    : "尚未运行自检，首次点击会创建独立测试账号。";
  $("runs").replaceChildren();
  if (!health.runs.length) $("runs").textContent = "尚无自检记录";
  for (const r of health.runs)
    row(
      $("runs"),
      labels[r.status] + " · " + time(r.started),
      stages[r.stage] +
        " · " +
        (r.duration / 1000).toFixed(1) +
        " 秒 · " +
        r.detail,
    );
  document.querySelectorAll(".run-test").forEach((b) => {
    b.disabled = health.running;
    b.textContent = health.running ? "自检进行中…" : "立即自检";
  });
  $("account-status").textContent = health.settings.accountReady
    ? "独立测试账号已加密保存"
    : "尚未创建测试账号";
}
async function refreshHealth() {
  if (me?.role !== "admin" || busy) return;
  busy = true;
  const current = epoch;
  try {
    const value = await api("/admin/health");
    if (current !== epoch) return;
    health = value;
    renderHealth();
  } finally {
    busy = false;
  }
}
async function refreshSessions() {
  const devices = await api("/devices");
  $("devices").replaceChildren();
  for (const d of devices)
    row(
      $("devices"),
      d.name,
      d.id === me.sessionId ? "当前会话" : "到期 " + time(d.expires),
      "撤销",
      async () => {
        await api("/devices/" + d.id, "DELETE");
        if (d.id === me.sessionId) lock();
        else await refreshSessions();
      },
    );
}
async function refreshUsers() {
  const users = await api("/admin/users");
  $("user-list").replaceChildren();
  if (!users.length) {
    const empty = document.createElement("p");
    empty.className = "empty-state";
    empty.textContent = "还没有用户。生成邀请，让第一位用户加入你的 Mohua。";
    $("user-list").append(empty);
  }
  for (const u of users)
    row(
      $("user-list"),
      u.email,
      u.role + " · " + (u.active ? "已启用" : "已停用"),
      u.active ? "停用" : "启用",
      u.id === me.id
        ? null
        : async () => {
            await api("/admin/users/" + u.id, "PATCH", { active: !u.active });
            await refreshUsers();
          },
    );
}
async function enter() {
  me = await api("/me");
  $("auth-shell").hidden = true;
  $("connection-state").textContent = "已登录";
  $("connection-state").classList.add("connected");
  $("dashboard").hidden = false;
  $("logout").hidden = false;
  route();
  await refreshSessions();
  if (me.role === "admin") {
    await refreshUsers();
    await refreshHealth();
    renderPush(await api("/admin/push"));
    $("schedule").elements.enabled.checked = health.settings.enabled;
    $("schedule").elements.intervalMinutes.value = String(
      health.settings.intervalMinutes,
    );
    clearInterval(poll);
    poll = setInterval(
      () => refreshHealth().catch((e) => message("状态更新失败：" + e.message)),
      5000,
    );
  }
}
$("login").onsubmit = async (e) => {
  e.preventDefault();
  try {
    const r = await api(
      "/login",
      "POST",
      Object.fromEntries(new FormData(e.target)),
    );
    bearer = r.token;
    e.target.password.value = "";
    e.target.setupToken.value = "";
    message("");
    await enter();
  } catch (err) {
    message(err.message);
  }
};
$("setup").onclick = async () => {
  try {
    await api("/setup", "POST", Object.fromEntries(new FormData($("login"))));
    $("login").setupToken.value = "";
    message("管理员已创建，请登录。");
  } catch (e) {
    message(e.message);
  }
};
$("logout").onclick = async () => {
  try {
    await api("/logout", "POST", {});
  } finally {
    lock();
  }
};
$("invite").onclick = async () => {
  try {
    const r = await api("/admin/invites", "POST", {}, bearer);
    $("invitation").textContent = "一次性邀请码（24 小时有效）：" + r.invite;
  } catch (e) {
    message(e.message);
  }
};
document.querySelectorAll(".run-test").forEach(
  (b) =>
    (b.onclick = async () => {
      document
        .querySelectorAll(".run-test")
        .forEach((x) => (x.disabled = true));
      try {
        await api("/admin/health/run", "POST", {});
        message("自检已启动，结果会自动更新。");
      } catch (e) {
        message(e.message);
      } finally {
        await refreshHealth();
      }
    }),
);
$("schedule").onsubmit = async (e) => {
  e.preventDefault();
  try {
    await api("/admin/health/settings", "PATCH", {
      enabled: e.target.elements.enabled.checked,
      intervalMinutes: Number(e.target.elements.intervalMinutes.value),
    });
    message("自检计划已保存。");
    await refreshHealth();
  } catch (err) {
    message(err.message);
  }
};

let pushConfig;
function renderPush(value) {
  pushConfig = value;
  const form = $("push-settings");
  form.elements.mode.value = value.mode;
  form.elements.customUrl.value = value.customUrl;
  pushModeChanged();
}
function pushModeChanged() {
  const mode = $("push-mode").value;
  $("custom-gateway-field").hidden = mode !== "custom";
  $("push-settings").elements.customUrl.required = mode === "custom";
  $("push-description").textContent =
    mode === "disabled"
      ? "不联系推送网关，客户端仍可收发邮件和手动刷新。"
      : mode === "official"
        ? pushConfig?.officialUrl
          ? "官方网关：" + pushConfig.officialUrl
          : "官方网关地址尚未配置，保存后仍不会发送推送。"
        : "请填写兼容 Mohua Gateway v1 的 HTTPS 地址，并使用该网关对应的客户端。";
}
$("push-mode").onchange = pushModeChanged;
$("push-settings").onsubmit = async (event) => {
  event.preventDefault();
  const button = event.submitter;
  button.disabled = true;
  const current = epoch;
  try {
    const value = await api(
      "/admin/push",
      "PATCH",
      Object.fromEntries(new FormData(event.target)),
    );
    if (epoch !== current) return;
    renderPush(value);
    $("push-result").textContent =
      "已保存。切换配置后，客户端重新打开时登记推送。";
  } catch (error) {
    if (epoch === current) $("push-result").textContent = error.message;
  } finally {
    button.disabled = false;
  }
};
$("test-gateway").onclick = async (event) => {
  const button = event.target,
    current = epoch;
  button.disabled = true;
  try {
    const result = await api("/admin/push/test", "POST", {});
    if (epoch === current) $("push-result").textContent = result.reason;
  } catch (error) {
    if (epoch === current) $("push-result").textContent = error.message;
  } finally {
    button.disabled = false;
  }
};

route();
